# -*- coding: utf-8 -*-
__title__ = "Visit YouTube"
__author__ = "Ghasem Ariani"
__tooltip__ = (
    "📺 Visit Ghasem Ariani's official YouTube channel\n"
    "Explore high-quality BIM tutorials, workflows, and automation tips."
)

import webbrowser

webbrowser.open("https://www.youtube.com/@GHASEM.ARIYANI")
