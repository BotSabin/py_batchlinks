# -*- coding: utf-8 -*-
__title__ = "Visit Telegram"
__author__ = "Ghasem Ariani"
__tooltip__ = (
    "📡 Join our official Telegram channel for updates on BIM tools and resources."
)

import webbrowser

webbrowser.open("https://t.me/RevitAddOns")
