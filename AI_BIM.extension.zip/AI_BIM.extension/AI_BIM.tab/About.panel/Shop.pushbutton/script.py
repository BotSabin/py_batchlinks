# -*- coding: utf-8 -*-
__title__ = "Visit Shop"
__author__ = "Ghasem Ariani"
__tooltip__ = (
    "🛒 Visit our BIM Shop\n\n"
    "Click to open the official store of Iran-BIM\n"
    "Explore courses, templates, and professional BIM tools."
)

import webbrowser

webbrowser.open("https://www.iran-bim.com/shop")
