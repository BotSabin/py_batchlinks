# -*- coding: utf-8 -*-
__title__ = "Visit LinkedIn"
__author__ = "Ghasem Ariani"
__tooltip__ = (
    "🔗 Visit Ghasem Ariani's professional LinkedIn profile\n"
    "Connect and stay updated on BIM innovations and training."
)

import webbrowser

webbrowser.open("https://www.linkedin.com/in/ghasem-ariyani-99954180/")
