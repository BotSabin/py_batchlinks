# -*- coding: utf-8 -*-
import xml.etree.ElementTree as ET
import datetime
from pyrevit import DB, script, forms
from System import Int64

start_time = datetime.datetime.now()

doc = __revit__.ActiveUIDocument.Document
output = script.get_output()
output.set_title("Clash Viewer – Final Version Using Element ID Value")

# Prompt for XML file
xml_path = forms.pick_file(file_ext='xml', title='Select Clash XML Report')
if not xml_path:
    output.print_md("❌ No XML file selected.")
    script.exit()

# Parse XML
try:
    tree = ET.parse(xml_path)
    root = tree.getroot()
except Exception as e:
    output.print_md("❌ Error reading XML file: {}".format(str(e)))
    script.exit()

# Extract clash element IDs
clashes = []
for clashresult in root.findall('.//clashresult'):
    clashobjects = clashresult.findall('.//clashobject')
    if len(clashobjects) >= 2:
        ids = []
        for i in range(2):
            for attr in clashobjects[i].findall('.//objectattribute'):
                name = attr.find('name')
                value = attr.find('value')
                if name is not None and name.text.strip() == 'Element ID':
                    if value is not None and value.text.strip().isdigit():
                        try:
                            ids.append(Int64.Parse(value.text.strip()))
                        except:
                            continue
        if len(ids) == 2:
            clashes.append((ids[0], ids[1]))

if not clashes:
    output.print_md("⚠️ No valid clashes found.")
    script.exit()

output.print_md("✅ Total clashes detected: **{}**".format(len(clashes)))

# Get 3D view type
collector = DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType)
view_type = [v for v in collector if v.ViewFamily == DB.ViewFamily.ThreeDimensional][0]

# Check if view already exists
existing_views = DB.FilteredElementCollector(doc).OfClass(DB.View3D).ToElements()
new_view = None
for v in existing_views:
    if v.Name == "ClashDetectedView":
        new_view = v
        break

# Create new 3D view if it doesn't exist
if not new_view:
    t = DB.Transaction(doc, "Create Clash View")
    t.Start()
    new_view = DB.View3D.CreateIsometric(doc, view_type.Id)
    new_view.Name = "ClashDetectedView"
    t.Commit()

# Get solid fill pattern
collector = DB.FilteredElementCollector(doc).OfClass(DB.FillPatternElement)
solid_fill = [f for f in collector if f.GetFillPattern().IsSolidFill]
solid_pattern_id = solid_fill[0].Id if solid_fill else DB.ElementId.InvalidElementId

# Graphic Overrides
red = DB.OverrideGraphicSettings()
red.SetProjectionLineColor(DB.Color(255, 0, 0))
red.SetSurfaceForegroundPatternColor(DB.Color(255, 0, 0))
red.SetSurfaceForegroundPatternId(solid_pattern_id)
red.SetSurfaceTransparency(30)

green = DB.OverrideGraphicSettings()
green.SetProjectionLineColor(DB.Color(0, 200, 0))
green.SetSurfaceForegroundPatternColor(DB.Color(0, 200, 0))
green.SetSurfaceForegroundPatternId(solid_pattern_id)
green.SetSurfaceTransparency(30)

gray = DB.OverrideGraphicSettings()
gray.SetProjectionLineColor(DB.Color(144, 144, 144))
gray.SetSurfaceForegroundPatternColor(DB.Color(144, 144, 144))
gray.SetSurfaceForegroundPatternId(solid_pattern_id)
gray.SetSurfaceTransparency(85)

# Apply overrides to clash elements
not_found = []
red_count = 0
green_count = 0

t2 = DB.Transaction(doc, "Apply Clash Overrides")
t2.Start()
for eid1_raw, eid2_raw in clashes:
    eid1 = DB.ElementId(eid1_raw)
    eid2 = DB.ElementId(eid2_raw)

    el1 = doc.GetElement(eid1)
    el2 = doc.GetElement(eid2)

    if el1:
        new_view.SetElementOverrides(eid1, red)
        red_count += 1
    else:
        not_found.append(str(eid1_raw))

    try:
        if el2 and el2.Document.PathName == doc.PathName:
            new_view.SetElementOverrides(eid2, green)
            green_count += 1
        else:
            not_found.append(str(eid2_raw) + " (🔗 Linked or missing)")
    except:
        not_found.append(str(eid2_raw) + " (⛔ Error)")
t2.Commit()

# Set view settings: Detail Level = Fine, Visual Style = Shaded
t3 = DB.Transaction(doc, "Set View Graphics")
t3.Start()
new_view.DetailLevel = DB.ViewDetailLevel.Fine
new_view.DisplayStyle = DB.DisplayStyle.Shading
t3.Commit()

# Apply gray override to all other elements
clash_ids = set()
for id1, id2 in clashes:
    clash_ids.add(DB.ElementId(id1))
    clash_ids.add(DB.ElementId(id2))

all_elements = DB.FilteredElementCollector(doc, new_view.Id).WhereElementIsNotElementType().ToElementIds()

t4 = DB.Transaction(doc, "Fade Non-Clash Elements")
t4.Start()
for eid in all_elements:
    if eid not in clash_ids:
        new_view.SetElementOverrides(eid, gray)
t4.Commit()

# Activate the view
__revit__.ActiveUIDocument.ActiveView = new_view

# Final report
output.print_md("---")
output.print_md("### 📊 Clash Report Summary")
output.print_md("🔹 Total Clashes: **{}**".format(len(clashes)))
output.print_md("🔴 Red Elements (First): **{}**".format(red_count))
output.print_md("🟢 Green Elements (Second): **{}**".format(green_count))
output.print_md("⚠️ Not Found or Linked: **{}**".format(len(not_found)))
output.print_md("🖼️ View Used: `{}`".format(new_view.Name))
output.print_md("🕓 Duration: {:.2f} seconds".format((datetime.datetime.now() - start_time).total_seconds()))

if not_found:
    output.print_md("🗒️ Missing or Linked Elements:\n{}".format(', '.join(not_found)))
