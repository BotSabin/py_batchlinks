# -*- coding: utf-8 -*-
__title__ = "Color by Task Start (UI)"
__author__ = "Ghasem AriYani"

import clr
import random
from datetime import datetime
from collections import defaultdict

clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")

from Autodesk.Revit.DB import *
from RevitServices.Persistence import DocumentManager
from pyrevit import script, revit

import System.Windows.Forms as WinForms
from System.Drawing import Size, Point, Color as WinColor, Font, FontStyle, ContentAlignment
from System.Windows.Forms import AnchorStyles

# Initialize
output = script.get_output()

try:
    uidoc = __revit__.ActiveUIDocument
    if not uidoc:
        output.print_md("❌ No active UIDocument found.")
        script.exit()
    doc = uidoc.Document
except:
    output.print_md("❌ Failed to get Revit document.")
    script.exit()

# Constants
PARAM_NAME = "Task Start"
DEFAULT_COLOR = Color(255, 0, 0)  # Red for invalid/missing data
TARGET_CATEGORIES = [
    BuiltInCategory.OST_Floors,
    BuiltInCategory.OST_Stairs,
    BuiltInCategory.OST_Ceilings,
    BuiltInCategory.OST_Columns,
    BuiltInCategory.OST_StructuralColumns,
    BuiltInCategory.OST_StructuralFraming,
    BuiltInCategory.OST_StructuralFoundation,
    BuiltInCategory.OST_Walls
]

# Global variables for tracking
date_groups = {}
total_processed = 0
valid_elements = []
invalid_format = []
empty_value = []
no_parameter = []

def get_solid_fill_id():
    """Get solid fill pattern ID"""
    try:
        collector = FilteredElementCollector(doc).OfClass(FillPatternElement)
        for el in collector:
            try:
                fill_pattern = el.GetFillPattern()
                if fill_pattern and fill_pattern.IsSolidFill:
                    return el.Id
            except:
                continue
        return ElementId.InvalidElementId
    except:
        return ElementId.InvalidElementId

def parse_datetime_safe(val):
    """Parse datetime string safely"""
    if not val:
        return None
    
    try:
        val = str(val).strip()
        if not val:
            return None
            
        formats = [
            "%Y-%m-%d",
            "%Y-%m-%d %H:%M",
            "%Y/%m/%d",
            "%d/%m/%Y",
            "%m/%d/%Y",
            "%Y-%m-%d %H:%M:%S"
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(val, fmt)
            except ValueError:
                continue
        return None
    except:
        return None

def generate_distinct_color(existing_colors, min_distance=100):
    """Generate a visually distinct color"""
    max_attempts = 50
    for _ in range(max_attempts):
        r = random.randint(50, 255)
        g = random.randint(50, 255)
        b = random.randint(50, 255)
        
        is_distinct = True
        for existing_color in existing_colors:
            distance = ((r - existing_color.Red)**2 + 
                       (g - existing_color.Green)**2 + 
                       (b - existing_color.Blue)**2)**0.5
            if distance < min_distance:
                is_distinct = False
                break
        
        if is_distinct:
            return Color(r, g, b)
    
    return Color(random.randint(50, 255), random.randint(50, 255), random.randint(50, 255))

def collect_elements_by_date(view, status_label):
    """Collect elements grouped by Task Start date"""
    global total_processed, date_groups, valid_elements, invalid_format, empty_value, no_parameter
    
    # Reset counters
    total_processed = 0
    valid_elements = []
    invalid_format = []
    empty_value = []
    no_parameter = []
    
    status_label.Text = "🔄 Collecting elements..."
    
    # Create multi-category filter
    cat_filters = [ElementCategoryFilter(cat) for cat in TARGET_CATEGORIES]
    multi_cat_filter = LogicalOrFilter(cat_filters)
    
    # Collect elements
    collector = FilteredElementCollector(doc, view.Id).WhereElementIsNotElementType().WherePasses(multi_cat_filter)
    
    date_groups = defaultdict(list)
    
    for el in collector:
        total_processed += 1
        try:
            # Check if element can have graphics overrides
            try:
                if not el.Category or not el.Category.AllowsGraphicsOverrides():
                    continue
            except:
                if not el.Category:
                    continue
                
            # Look for the parameter
            param = el.LookupParameter(PARAM_NAME)
            if not param:
                no_parameter.append(el)
                continue
            
            # Get parameter value
            if param.StorageType == StorageType.String:
                val = param.AsString()
            else:
                val = param.AsValueString()
            
            if not val or str(val).strip() == "":
                empty_value.append(el)
                continue
            
            # Parse date
            dt = parse_datetime_safe(val)
            if dt:
                key = dt.strftime("%Y-%m-%d")
                date_groups[key].append(el)
                valid_elements.append(el)
            else:
                invalid_format.append(el)
                
        except Exception:
            continue
    
    status_label.Text = "✅ Ready to apply colors"
    return date_groups

def apply_colors(view, status_label, info_label):
    """Apply color overrides to elements"""
    global date_groups
    
    if not date_groups and not invalid_format and not empty_value and not no_parameter:
        status_label.Text = "❌ No elements found!"
        return
    
    status_label.Text = "🎨 Applying colors..."
    
    # Get solid fill pattern
    fill_id = get_solid_fill_id()
    
    # Generate colors for each date group
    used_colors = []
    date_color_map = {}
    
    for date_str in sorted(date_groups.keys()):
        color = generate_distinct_color(used_colors)
        used_colors.append(color)
        date_color_map[date_str] = color
    
    # Start transaction
    with Transaction(doc, "Apply Task Start Colors") as t:
        t.Start()
        
        try:
            success_count = 0
            
            # Apply colors to valid date groups
            for date_str, elements in date_groups.items():
                color = date_color_map[date_str]
                
                for el in elements:
                    try:
                        ogs = OverrideGraphicSettings()
                        
                        # Apply surface color with pattern
                        if fill_id != ElementId.InvalidElementId:
                            ogs.SetSurfaceForegroundPatternId(fill_id)
                            ogs.SetSurfaceForegroundPatternColor(color)
                        
                        # Apply line colors
                        ogs.SetProjectionLineColor(color)
                        ogs.SetProjectionLineWeight(3)
                        ogs.SetCutLineColor(color)
                        ogs.SetCutLineWeight(3)
                        
                        view.SetElementOverrides(el.Id, ogs)
                        success_count += 1
                    except Exception:
                        continue
            
            # Apply default color to invalid elements
            problem_elements = invalid_format + empty_value + no_parameter
            for el in problem_elements:
                try:
                    ogs = OverrideGraphicSettings()
                    
                    if fill_id != ElementId.InvalidElementId:
                        ogs.SetSurfaceForegroundPatternId(fill_id)
                        ogs.SetSurfaceForegroundPatternColor(DEFAULT_COLOR)
                    
                    ogs.SetProjectionLineColor(DEFAULT_COLOR)
                    ogs.SetProjectionLineWeight(5)
                    ogs.SetCutLineColor(DEFAULT_COLOR)
                    ogs.SetCutLineWeight(5)
                    
                    view.SetElementOverrides(el.Id, ogs)
                    success_count += 1
                except Exception:
                    continue
            
            t.Commit()
            status_label.Text = "✅ Colors applied successfully!"
            
            # Update info
            info_text = "📊 Report:\n"
            info_text += "• Total elements: {}\n".format(total_processed)
            info_text += "• Unique dates: {}\n".format(len(date_groups))
            info_text += "• Valid elements: {}\n".format(len(valid_elements))
            info_text += "• Invalid format: {}\n".format(len(invalid_format))
            info_text += "• Empty value: {}\n".format(len(empty_value))
            info_text += "• No parameter: {}\n".format(len(no_parameter))
            info_text += "• Successfully applied: {}\n".format(success_count)
            
            if date_groups:
                info_text += "\n🗓️ Date groups:\n"
                for date_str in sorted(date_groups.keys()):
                    info_text += "• {}: {} elements\n".format(date_str, len(date_groups[date_str]))
            
            info_label.Text = info_text
            
        except Exception as e:
            t.RollBack()
            status_label.Text = "❌ Error applying colors: {}".format(str(e))

def clear_colors(view, status_label, info_label):
    """Clear all color overrides"""
    status_label.Text = "🧹 Clearing colors..."
    
    # Get all elements in view
    collector = FilteredElementCollector(doc, view.Id).WhereElementIsNotElementType()
    
    with Transaction(doc, "Clear Task Start Colors") as t:
        t.Start()
        
        try:
            cleared_count = 0
            for el in collector:
                try:
                    # Clear overrides
                    view.SetElementOverrides(el.Id, OverrideGraphicSettings())
                    cleared_count += 1
                except:
                    continue
            
            t.Commit()
            status_label.Text = "✅ Colors cleared successfully!"
            info_label.Text = "🧹 Elements cleared: {}".format(cleared_count)
            
        except Exception as e:
            t.RollBack()
            status_label.Text = "❌ Error clearing colors: {}".format(str(e))

def create_ui():
    """Create the main UI window with modern graphics"""
    # Create form with modern styling
    form = WinForms.Form()
    form.Text = "🎨 Color by Task Start - Professional Edition"
    form.Size = Size(600, 500)
    form.StartPosition = WinForms.FormStartPosition.CenterScreen
    form.FormBorderStyle = WinForms.FormBorderStyle.FixedDialog
    form.MaximizeBox = False
    form.MinimizeBox = False
    form.BackColor = WinColor.FromArgb(240, 244, 248)  # Light gray-blue background
    
    # Get current view
    view = uidoc.ActiveView
    if not view:
        WinForms.MessageBox.Show("No active view found!", "Error", WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Error)
        return
    
    # Header panel with gradient effect
    header_panel = WinForms.Panel()
    header_panel.Location = Point(0, 0)
    header_panel.Size = Size(600, 80)
    header_panel.BackColor = WinColor.FromArgb(41, 128, 185)  # Professional blue
    form.Controls.Add(header_panel)
    
    # Title label with shadow effect
    title_label = WinForms.Label()
    title_label.Text = "COLOR BY TASK START"
    title_label.Font = Font("Segoe UI", 16, FontStyle.Bold)
    title_label.Location = Point(20, 15)
    title_label.Size = Size(560, 30)
    title_label.TextAlign = ContentAlignment.MiddleLeft
    title_label.ForeColor = WinColor.White
    title_label.BackColor = WinColor.Transparent
    header_panel.Controls.Add(title_label)
    
    # Subtitle
    subtitle_label = WinForms.Label()
    subtitle_label.Text = "Professional Revit Element Coloring Tool"
    subtitle_label.Font = Font("Segoe UI", 9, FontStyle.Italic)
    subtitle_label.Location = Point(20, 45)
    subtitle_label.Size = Size(400, 20)
    subtitle_label.TextAlign = ContentAlignment.MiddleLeft
    subtitle_label.ForeColor = WinColor.FromArgb(220, 220, 220)
    subtitle_label.BackColor = WinColor.Transparent
    header_panel.Controls.Add(subtitle_label)
    
    # View info panel
    view_panel = WinForms.Panel()
    view_panel.Location = Point(20, 100)
    view_panel.Size = Size(560, 35)
    view_panel.BackColor = WinColor.FromArgb(52, 152, 219)
    view_panel.ForeColor = WinColor.White
    form.Controls.Add(view_panel)
    
    view_label = WinForms.Label()
    view_label.Text = "📋 Active View: {}".format(view.Name)
    view_label.Font = Font("Segoe UI", 10, FontStyle.Bold)
    view_label.Location = Point(15, 8)
    view_label.Size = Size(530, 20)
    view_label.TextAlign = ContentAlignment.MiddleLeft
    view_label.ForeColor = WinColor.White
    view_label.BackColor = WinColor.Transparent
    view_panel.Controls.Add(view_label)
    
    # Status panel with rounded corners effect
    status_panel = WinForms.Panel()
    status_panel.Location = Point(20, 155)
    status_panel.Size = Size(560, 30)
    status_panel.BackColor = WinColor.FromArgb(46, 204, 113)
    form.Controls.Add(status_panel)
    
    status_label = WinForms.Label()
    status_label.Text = "✅ Ready to start..."
    status_label.Font = Font("Segoe UI", 9, FontStyle.Bold)
    status_label.Location = Point(15, 6)
    status_label.Size = Size(530, 20)
    status_label.TextAlign = ContentAlignment.MiddleLeft
    status_label.ForeColor = WinColor.White
    status_label.BackColor = WinColor.Transparent
    status_panel.Controls.Add(status_label)
    
    # Button panel with modern styling
    button_panel = WinForms.Panel()
    button_panel.Location = Point(20, 205)
    button_panel.Size = Size(560, 70)
    button_panel.BackColor = WinColor.FromArgb(248, 249, 250)
    form.Controls.Add(button_panel)
    
    # Scan button with modern styling
    scan_button = WinForms.Button()
    scan_button.Text = "🔍 SCAN\nELEMENTS"
    scan_button.Font = Font("Segoe UI", 9, FontStyle.Bold)
    scan_button.Location = Point(20, 15)
    scan_button.Size = Size(120, 45)
    scan_button.BackColor = WinColor.FromArgb(155, 89, 182)
    scan_button.ForeColor = WinColor.White
    scan_button.FlatStyle = WinForms.FlatStyle.Flat
    scan_button.FlatAppearance.BorderSize = 0
    scan_button.FlatAppearance.MouseOverBackColor = WinColor.FromArgb(142, 68, 173)
    scan_button.FlatAppearance.MouseDownBackColor = WinColor.FromArgb(125, 60, 152)
    
    def scan_click(sender, args):
        status_label.Text = "Scanning elements..."
        status_panel.BackColor = WinColor.FromArgb(241, 196, 15)
        form.Refresh()
        collect_elements_by_date(view, status_label)
        scan_button.Enabled = True
        apply_button.Enabled = True
        status_panel.BackColor = WinColor.FromArgb(46, 204, 113)
    
    scan_button.Click += scan_click
    button_panel.Controls.Add(scan_button)
    
    # Apply colors button
    apply_button = WinForms.Button()
    apply_button.Text = "🎨 APPLY\nCOLORS"
    apply_button.Font = Font("Segoe UI", 9, FontStyle.Bold)
    apply_button.Location = Point(160, 15)
    apply_button.Size = Size(120, 45)
    apply_button.BackColor = WinColor.FromArgb(231, 76, 60)
    apply_button.ForeColor = WinColor.White
    apply_button.FlatStyle = WinForms.FlatStyle.Flat
    apply_button.FlatAppearance.BorderSize = 0
    apply_button.FlatAppearance.MouseOverBackColor = WinColor.FromArgb(192, 57, 43)
    apply_button.FlatAppearance.MouseDownBackColor = WinColor.FromArgb(169, 50, 38)
    apply_button.Enabled = False
    
    def apply_click(sender, args):
        status_label.Text = "Applying colors..."
        status_panel.BackColor = WinColor.FromArgb(230, 126, 34)
        form.Refresh()
        apply_colors(view, status_label, info_label)
        clear_button.Enabled = True
        status_panel.BackColor = WinColor.FromArgb(46, 204, 113)
    
    apply_button.Click += apply_click
    button_panel.Controls.Add(apply_button)
    
    # Clear colors button
    clear_button = WinForms.Button()
    clear_button.Text = "🧹 CLEAR\nCOLORS"
    clear_button.Font = Font("Segoe UI", 9, FontStyle.Bold)
    clear_button.Location = Point(300, 15)
    clear_button.Size = Size(120, 45)
    clear_button.BackColor = WinColor.FromArgb(52, 73, 94)
    clear_button.ForeColor = WinColor.White
    clear_button.FlatStyle = WinForms.FlatStyle.Flat
    clear_button.FlatAppearance.BorderSize = 0
    clear_button.FlatAppearance.MouseOverBackColor = WinColor.FromArgb(44, 62, 80)
    clear_button.FlatAppearance.MouseDownBackColor = WinColor.FromArgb(39, 55, 70)
    clear_button.Enabled = False
    
    def clear_click(sender, args):
        status_label.Text = "Clearing colors..."
        status_panel.BackColor = WinColor.FromArgb(230, 126, 34)
        form.Refresh()
        clear_colors(view, status_label, info_label)
        status_panel.BackColor = WinColor.FromArgb(46, 204, 113)
    
    clear_button.Click += clear_click
    button_panel.Controls.Add(clear_button)
    
    # Help button
    help_button = WinForms.Button()
    help_button.Text = "❓ HELP"
    help_button.Font = Font("Segoe UI", 8, FontStyle.Bold)
    help_button.Location = Point(440, 15)
    help_button.Size = Size(80, 45)
    help_button.BackColor = WinColor.FromArgb(149, 165, 166)
    help_button.ForeColor = WinColor.White
    help_button.FlatStyle = WinForms.FlatStyle.Flat
    help_button.FlatAppearance.BorderSize = 0
    help_button.FlatAppearance.MouseOverBackColor = WinColor.FromArgb(127, 140, 141)
    help_button.FlatAppearance.MouseDownBackColor = WinColor.FromArgb(108, 122, 137)
    
    def help_click(sender, args):
        help_msg = "🎨 Color by Task Start Help:\n\n"
        help_msg += "1. Click 'SCAN ELEMENTS' to find all elements with Task Start parameter\n"
        help_msg += "2. Click 'APPLY COLORS' to color elements by their start dates\n"
        help_msg += "3. Click 'CLEAR COLORS' to remove all color overrides\n\n"
        help_msg += "Supported date formats:\n"
        help_msg += "• YYYY-MM-DD (2024-01-15)\n"
        help_msg += "• DD/MM/YYYY (15/01/2024)\n"
        help_msg += "• MM/DD/YYYY (01/15/2024)\n"
        help_msg += "• YYYY/MM/DD (2024/01/15)\n\n"
        help_msg += "Elements with invalid dates will be colored red."
        WinForms.MessageBox.Show(help_msg, "Help - Color by Task Start", WinForms.MessageBoxButtons.OK, WinForms.MessageBoxIcon.Information)
    
    help_button.Click += help_click
    button_panel.Controls.Add(help_button)
    
    # Info panel with modern styling
    info_panel = WinForms.Panel()
    info_panel.Location = Point(20, 295)
    info_panel.Size = Size(560, 150)
    info_panel.BackColor = WinColor.FromArgb(255, 255, 255)
    form.Controls.Add(info_panel)
    
    # Info header
    info_header = WinForms.Label()
    info_header.Text = "ANALYSIS REPORT"
    info_header.Font = Font("Segoe UI", 10, FontStyle.Bold)
    info_header.Location = Point(15, 10)
    info_header.Size = Size(530, 25)
    info_header.TextAlign = ContentAlignment.MiddleLeft
    info_header.ForeColor = WinColor.FromArgb(52, 73, 94)
    info_header.BackColor = WinColor.Transparent
    info_panel.Controls.Add(info_header)
    
    # Info text box with modern styling
    info_label = WinForms.TextBox()
    info_label.Text = "📋 Click 'SCAN ELEMENTS' to start the analysis.\n\n💡 This tool will help you visualize construction scheduling by coloring elements based on their Task Start dates."
    info_label.Font = Font("Segoe UI", 9)
    info_label.Location = Point(15, 35)
    info_label.Size = Size(530, 105)
    info_label.Multiline = True
    info_label.ScrollBars = WinForms.ScrollBars.Vertical
    info_label.ReadOnly = True
    info_label.BackColor = WinColor.FromArgb(248, 249, 250)
    info_label.ForeColor = WinColor.FromArgb(52, 73, 94)
    info_label.BorderStyle = WinForms.BorderStyle.None
    info_panel.Controls.Add(info_label)
    
    # Close button with modern styling
    close_button = WinForms.Button()
    close_button.Text = "✖ CLOSE"
    close_button.Font = Font("Segoe UI", 9, FontStyle.Bold)
    close_button.Location = Point(490, 460)
    close_button.Size = Size(90, 30)
    close_button.BackColor = WinColor.FromArgb(231, 76, 60)
    close_button.ForeColor = WinColor.White
    close_button.FlatStyle = WinForms.FlatStyle.Flat
    close_button.FlatAppearance.BorderSize = 0
    close_button.FlatAppearance.MouseOverBackColor = WinColor.FromArgb(192, 57, 43)
    close_button.FlatAppearance.MouseDownBackColor = WinColor.FromArgb(169, 50, 38)
    close_button.DialogResult = WinForms.DialogResult.OK
    form.Controls.Add(close_button)
    
    # Credits label
    credits_label = WinForms.Label()
    credits_label.Text = "Developed by Ghasem AriYani | Enhanced UI Version"
    credits_label.Font = Font("Segoe UI", 8, FontStyle.Italic)
    credits_label.Location = Point(20, 470)
    credits_label.Size = Size(400, 15)
    credits_label.TextAlign = ContentAlignment.MiddleLeft
    credits_label.ForeColor = WinColor.FromArgb(149, 165, 166)
    credits_label.BackColor = WinColor.Transparent
    form.Controls.Add(credits_label)
    
    # Show form
    form.ShowDialog()

# Main execution
if __name__ == "__main__":
    create_ui()