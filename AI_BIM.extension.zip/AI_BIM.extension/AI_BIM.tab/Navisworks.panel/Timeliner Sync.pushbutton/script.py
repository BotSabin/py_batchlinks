# -*- coding: utf-8 -*-
__title__ = "Timeliner Sync"
__author__ = "GHASEM ARIYANI"

import clr
clr.AddReference('RevitAPI')
clr.AddReference('System.Windows.Forms')

import csv
import codecs
from System.Windows.Forms import OpenFileDialog, DialogResult
from Autodesk.Revit.DB import ElementId, Transaction
from pyrevit import revit, script, output
from System import DateTime, Int64
import System

# Setup output
out = script.get_output()
out.set_title("🛡 Safe Timeliner Import (NAVtime-2.csv)")

doc = revit.doc
if doc is None:
    out.print_md("❌ No active Revit document.")
    script.exit()

# Select CSV file
dialog = OpenFileDialog()
dialog.Title = "Select NAVtime-2.csv"
dialog.Filter = "CSV files (*.csv)|*.csv"
dialog.Multiselect = False

if dialog.ShowDialog() != DialogResult.OK:
    out.print_md("⚠️ File selection canceled.")
    script.exit()

csv_path = dialog.FileName

# Counters
total_rows = 0
success_count = 0
fail_count = 0
row_report_list = []

# Start transaction
t = Transaction(doc, "Apply NAVtime-2 Dates")
t.Start()

try:
    with codecs.open(csv_path, "r", encoding="utf-8-sig") as file:
        reader = csv.DictReader(file)
        headers = reader.fieldnames
        out.print_md("📌 CSV Columns: `{}`".format(", ".join(headers)))

        for row in reader:
            total_rows += 1
            try:
                elem_id_str = row.get("Element ID", "").strip()
                start_str = row.get("Start", "").strip()
                end_str = row.get("Finish", "").strip()

                if not elem_id_str:
                    raise Exception("Missing Element ID.")

                elem_id = ElementId(Int64.Parse(elem_id_str))
                element = doc.GetElement(elem_id)
                if element is None:
                    raise Exception("Element not found.")

                try:
                    start_dt = DateTime.ParseExact(start_str, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture)
                    end_dt = DateTime.ParseExact(end_str, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture)
                except:
                    raise Exception("Invalid date format. Expected yyyy-MM-dd")

                # Safely set parameters
                applied = False
                p_start = element.LookupParameter("Task Start")
                if p_start and p_start.StorageType.ToString() == "String":
                    p_start.Set(start_dt.ToString("yyyy-MM-dd"))
                    applied = True
                else:
                    raise Exception("Missing or invalid 'Task Start' parameter.")

                p_end = element.LookupParameter("Task End")
                if p_end and p_end.StorageType.ToString() == "String":
                    p_end.Set(end_dt.ToString("yyyy-MM-dd"))
                    applied = True
                else:
                    raise Exception("Missing or invalid 'Task End' parameter.")

                success_count += 1
                row_report_list.append([elem_id_str, "✅ Success", "Updated successfully."])

            except Exception as ex:
                fail_count += 1
                row_report_list.append([elem_id_str or "N/A", "❌ Failed", str(ex)])

    doc.Regenerate()
    t.Commit()

except Exception as e:
    t.RollBack()
    out.print_md("🚫 Fatal error: {}".format(e))
    script.exit()

# Output summary
out.print_md("## ✅ Summary")
out.print_md("- Total Rows: **{}**".format(total_rows))
out.print_md("- 🟢 Success: **{}**".format(success_count))
out.print_md("- 🔴 Failed: **{}**".format(fail_count))

# Table output
out.print_md("## 📄 Row Status Table")
out.print_table(
    table_data=[["Element ID", "Status", "Message"]] + row_report_list,
    title="Timeliner Status Report",
    columns=["Element ID", "Status", "Message"]
)

out.print_md("✅ **NAVtime-2 import completed without crash.**")
