# -*- coding: utf-8 -*-
"""Working Element Manager Tool for Revit"""

__title__ = "Element\nManager"

import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')
clr.AddReference('System')

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from System.Windows.Forms import *
from System.Drawing import *
from pyrevit import revit
import System

class WorkingElementManager(Form):
    def __init__(self):
        # Initialize Revit objects
        self.doc = revit.doc
        self.uidoc = revit.uidoc
        self.view = self.doc.ActiveView
        self.selected_color = Color.Red  # Default color
        self.element_groups = {}
        
        # Toggle states
        self.is_isolated = False
        self.is_hidden = False
        
        # Setup form
        self.setup_form()
        self.setup_controls()
        self.load_categories()
    
    def setup_form(self):
        """Setup main form"""
        self.Text = "Element Manager"
        self.Size = Size(900, 700)  # Increased height
        self.StartPosition = FormStartPosition.CenterScreen
        self.FormBorderStyle = FormBorderStyle.Sizable
        self.MinimumSize = Size(800, 650)  # Increased minimum height
        self.BackColor = Color.FromArgb(240, 240, 240)
    
    def setup_controls(self):
        """Setup form controls"""
        
        # Categories Panel
        cat_panel = Panel()
        cat_panel.Location = Point(10, 10)
        cat_panel.Size = Size(250, 450)
        cat_panel.BorderStyle = BorderStyle.FixedSingle
        cat_panel.BackColor = Color.White
        
        cat_header = Label()
        cat_header.Text = "CATEGORIES"
        cat_header.Location = Point(5, 5)
        cat_header.Size = Size(240, 25)
        cat_header.BackColor = Color.FromArgb(211, 47, 47)
        cat_header.ForeColor = Color.White
        cat_header.TextAlign = ContentAlignment.MiddleCenter
        cat_header.Font = Font("Arial", 10, FontStyle.Bold)
        
        self.lst_categories = ListBox()
        self.lst_categories.Location = Point(5, 35)
        self.lst_categories.Size = Size(240, 410)
        self.lst_categories.Font = Font("Arial", 9)
        self.lst_categories.SelectedIndexChanged += self.on_category_changed
        
        cat_panel.Controls.Add(cat_header)
        cat_panel.Controls.Add(self.lst_categories)
        
        # Elements Panel
        elem_panel = Panel()
        elem_panel.Location = Point(280, 10)
        elem_panel.Size = Size(300, 450)
        elem_panel.BorderStyle = BorderStyle.FixedSingle
        elem_panel.BackColor = Color.White
        
        elem_header = Label()
        elem_header.Text = "ELEMENT TYPES"
        elem_header.Location = Point(5, 5)
        elem_header.Size = Size(290, 25)
        elem_header.BackColor = Color.FromArgb(211, 47, 47)
        elem_header.ForeColor = Color.White
        elem_header.TextAlign = ContentAlignment.MiddleCenter
        elem_header.Font = Font("Arial", 10, FontStyle.Bold)
        
        self.lst_elements = CheckedListBox()
        self.lst_elements.Location = Point(5, 35)
        self.lst_elements.Size = Size(290, 410)
        self.lst_elements.Font = Font("Arial", 9)
        self.lst_elements.CheckOnClick = True
        
        elem_panel.Controls.Add(elem_header)
        elem_panel.Controls.Add(self.lst_elements)
        
        # Controls Panel
        ctrl_panel = Panel()
        ctrl_panel.Location = Point(600, 10)
        ctrl_panel.Size = Size(280, 500)  # Increased height for reset button
        ctrl_panel.BorderStyle = BorderStyle.FixedSingle
        ctrl_panel.BackColor = Color.White
        
        ctrl_header = Label()
        ctrl_header.Text = "CONTROLS"
        ctrl_header.Location = Point(5, 5)
        ctrl_header.Size = Size(270, 25)
        ctrl_header.BackColor = Color.FromArgb(211, 47, 47)
        ctrl_header.ForeColor = Color.White
        ctrl_header.TextAlign = ContentAlignment.MiddleCenter
        ctrl_header.Font = Font("Arial", 10, FontStyle.Bold)
        
        # Control Buttons
        y_pos = 50
        btn_height = 35
        btn_spacing = 45
        
        self.btn_select = Button()
        self.btn_select.Text = "Select"
        self.btn_select.Location = Point(15, y_pos)
        self.btn_select.Size = Size(250, btn_height)
        self.btn_select.BackColor = Color.FromArgb(46, 125, 154)
        self.btn_select.ForeColor = Color.White
        self.btn_select.Font = Font("Arial", 10, FontStyle.Bold)
        self.btn_select.FlatStyle = FlatStyle.Flat
        self.btn_select.Click += self.select_elements
        
        y_pos += btn_spacing
        self.btn_isolate = Button()
        self.btn_isolate.Text = "Isolate"
        self.btn_isolate.Location = Point(15, y_pos)
        self.btn_isolate.Size = Size(250, btn_height)
        self.btn_isolate.BackColor = Color.FromArgb(46, 125, 154)
        self.btn_isolate.ForeColor = Color.White
        self.btn_isolate.Font = Font("Arial", 10, FontStyle.Bold)
        self.btn_isolate.FlatStyle = FlatStyle.Flat
        self.btn_isolate.Click += self.toggle_isolate
        
        y_pos += btn_spacing
        self.btn_hide = Button()
        self.btn_hide.Text = "Hide"
        self.btn_hide.Location = Point(15, y_pos)
        self.btn_hide.Size = Size(250, btn_height)
        self.btn_hide.BackColor = Color.FromArgb(46, 125, 154)
        self.btn_hide.ForeColor = Color.White
        self.btn_hide.Font = Font("Arial", 10, FontStyle.Bold)
        self.btn_hide.FlatStyle = FlatStyle.Flat
        self.btn_hide.Click += self.toggle_hide
        
        y_pos += btn_spacing
        self.btn_delete = Button()
        self.btn_delete.Text = "Delete"
        self.btn_delete.Location = Point(15, y_pos)
        self.btn_delete.Size = Size(250, btn_height)
        self.btn_delete.BackColor = Color.FromArgb(211, 47, 47)
        self.btn_delete.ForeColor = Color.White
        self.btn_delete.Font = Font("Arial", 10, FontStyle.Bold)
        self.btn_delete.FlatStyle = FlatStyle.Flat
        self.btn_delete.Click += self.delete_elements
        
        # Color Override Section
        y_pos += 60
        color_lbl = Label()
        color_lbl.Text = "Color Override"
        color_lbl.Location = Point(15, y_pos)
        color_lbl.Size = Size(150, 20)
        color_lbl.Font = Font("Arial", 10, FontStyle.Bold)
        
        y_pos += 25
        self.color_panel = Panel()
        self.color_panel.Location = Point(15, y_pos)
        self.color_panel.Size = Size(100, 30)
        self.color_panel.BackColor = self.selected_color
        self.color_panel.BorderStyle = BorderStyle.FixedSingle
        self.color_panel.Click += self.choose_color
        
        self.btn_choose_color = Button()
        self.btn_choose_color.Text = "Choose"
        self.btn_choose_color.Location = Point(125, y_pos)
        self.btn_choose_color.Size = Size(70, 30)
        self.btn_choose_color.Click += self.choose_color
        
        y_pos += 40
        self.btn_override = Button()
        self.btn_override.Text = "Override Color"
        self.btn_override.Location = Point(15, y_pos)
        self.btn_override.Size = Size(250, btn_height)
        self.btn_override.BackColor = Color.FromArgb(255, 107, 53)
        self.btn_override.ForeColor = Color.White
        self.btn_override.Font = Font("Arial", 10, FontStyle.Bold)
        self.btn_override.FlatStyle = FlatStyle.Flat
        self.btn_override.Click += self.override_color
        
        # Reset View Button
        y_pos += btn_spacing
        self.btn_reset = Button()
        self.btn_reset.Text = "Reset View"
        self.btn_reset.Location = Point(15, y_pos)
        self.btn_reset.Size = Size(250, btn_height)
        self.btn_reset.BackColor = Color.FromArgb(76, 175, 80)  # Green
        self.btn_reset.ForeColor = Color.White
        self.btn_reset.Font = Font("Arial", 10, FontStyle.Bold)
        self.btn_reset.FlatStyle = FlatStyle.Flat
        self.btn_reset.Click += self.reset_view
        
        # Add controls to panel
        ctrl_panel.Controls.Add(ctrl_header)
        ctrl_panel.Controls.Add(self.btn_select)
        ctrl_panel.Controls.Add(self.btn_isolate)
        ctrl_panel.Controls.Add(self.btn_hide)
        ctrl_panel.Controls.Add(self.btn_delete)
        ctrl_panel.Controls.Add(color_lbl)
        ctrl_panel.Controls.Add(self.color_panel)
        ctrl_panel.Controls.Add(self.btn_choose_color)
        ctrl_panel.Controls.Add(self.btn_override)
        ctrl_panel.Controls.Add(self.btn_reset)
        
        # Status Label
        self.status_label = Label()
        self.status_label.Text = "Ready - Select a category to see element types"
        self.status_label.Location = Point(10, 520)  # Moved down
        self.status_label.Size = Size(870, 50)
        self.status_label.Font = Font("Arial", 9)
        self.status_label.ForeColor = Color.Gray
        self.status_label.BackColor = Color.White
        self.status_label.BorderStyle = BorderStyle.FixedSingle
        self.status_label.Padding = Padding(5)
        
        # Add main panels to form
        self.Controls.Add(cat_panel)
        self.Controls.Add(elem_panel)
        self.Controls.Add(ctrl_panel)
        self.Controls.Add(self.status_label)
    
    def load_categories(self):
        """Load categories from current view"""
        try:
            categories = set()
            
            # Get all elements in view
            collector = FilteredElementCollector(self.doc, self.view.Id)
            elements = collector.WhereElementIsNotElementType().ToElements()
            
            for element in elements:
                if element.Category and element.Category.Name:
                    categories.add(element.Category.Name)
            
            # Add to listbox
            sorted_categories = sorted(list(categories))
            for cat_name in sorted_categories:
                self.lst_categories.Items.Add(cat_name)
            
            self.status_label.Text = "Loaded {} categories from current view".format(len(sorted_categories))
        except Exception as e:
            self.status_label.Text = "Error loading categories: {}".format(str(e))
    
    def on_category_changed(self, sender, args):
        """Handle category selection change"""
        if self.lst_categories.SelectedItem is None:
            return
        
        selected_category = str(self.lst_categories.SelectedItem)
        self.load_elements_by_category(selected_category)
    
    def load_elements_by_category(self, category_name):
        """Load elements of selected category"""
        try:
            self.lst_elements.Items.Clear()
            self.element_groups.clear()
            
            # Find category
            category = None
            for cat in self.doc.Settings.Categories:
                if cat.Name == category_name:
                    category = cat
                    break
            
            if not category:
                self.status_label.Text = "Category not found: {}".format(category_name)
                return
            
            # Get elements of this category
            collector = FilteredElementCollector(self.doc, self.view.Id)
            category_filter = ElementCategoryFilter(category.Id)
            elements = collector.WherePasses(category_filter).WhereElementIsNotElementType().ToElements()
            
            # Group by type
            type_groups = {}
            for element in elements:
                try:
                    type_param = element.get_Parameter(BuiltInParameter.ELEM_TYPE_PARAM)
                    if type_param and type_param.AsValueString():
                        type_name = type_param.AsValueString()
                    else:
                        # Fallback to element type name
                        elem_type = self.doc.GetElement(element.GetTypeId())
                        if elem_type and elem_type.Name:
                            type_name = elem_type.Name
                        else:
                            type_name = "Unknown Type"
                    
                    if type_name not in type_groups:
                        type_groups[type_name] = []
                    type_groups[type_name].append(element)
                except:
                    continue
            
            # Add to checked listbox
            for type_name, elements_list in type_groups.items():
                item_text = "{} ({} elements)".format(type_name, len(elements_list))
                self.lst_elements.Items.Add(item_text)
                self.element_groups[item_text] = elements_list
            
            self.status_label.Text = "Loaded {} element types for category: {}".format(len(type_groups), category_name)
            
        except Exception as e:
            self.status_label.Text = "Error loading elements: {}".format(str(e))
    
    def get_selected_elements(self):
        """Get all elements from checked items"""
        selected_elements = []
        try:
            for i in range(self.lst_elements.CheckedItems.Count):
                item_text = str(self.lst_elements.CheckedItems[i])
                if item_text in self.element_groups:
                    selected_elements.extend(self.element_groups[item_text])
        except Exception as e:
            self.status_label.Text = "Error getting selected elements: {}".format(str(e))
        return selected_elements
    
    def select_elements(self, sender, args):
        """Select elements in Revit"""
        try:
            elements = self.get_selected_elements()
            if not elements:
                self.status_label.Text = "No elements selected"
                return
            
            element_ids = System.Collections.Generic.List[ElementId]()
            for elem in elements:
                element_ids.Add(elem.Id)
            
            self.uidoc.Selection.SetElementIds(element_ids)
            self.status_label.Text = "{} elements selected in model".format(len(elements))
            
        except Exception as e:
            self.status_label.Text = "Error selecting elements: {}".format(str(e))
    
    def toggle_isolate(self, sender, args):
        """Toggle isolate/unisolate elements"""
        try:
            if not self.is_isolated:
                # Isolate elements
                elements = self.get_selected_elements()
                if not elements:
                    self.status_label.Text = "No elements selected"
                    return
                
                with revit.Transaction("Isolate Elements"):
                    element_ids = System.Collections.Generic.List[ElementId]()
                    for elem in elements:
                        element_ids.Add(elem.Id)
                    self.view.IsolateElementsTemporary(element_ids)
                
                self.is_isolated = True
                self.btn_isolate.Text = "Unisolate"
                self.btn_isolate.BackColor = Color.FromArgb(255, 152, 0)  # Orange
                self.status_label.Text = "{} elements isolated".format(len(elements))
            else:
                # Unisolate elements
                with revit.Transaction("Unisolate Elements"):
                    self.view.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate)
                
                self.is_isolated = False
                self.btn_isolate.Text = "Isolate"
                self.btn_isolate.BackColor = Color.FromArgb(46, 125, 154)  # Blue
                self.status_label.Text = "Elements unisolated"
                
        except Exception as e:
            self.status_label.Text = "Error toggling isolate: {}".format(str(e))
    
    def toggle_hide(self, sender, args):
        """Toggle hide/unhide elements"""
        try:
            if not self.is_hidden:
                # Hide elements
                elements = self.get_selected_elements()
                if not elements:
                    self.status_label.Text = "No elements selected"
                    return
                
                with revit.Transaction("Hide Elements"):
                    element_ids = System.Collections.Generic.List[ElementId]()
                    for elem in elements:
                        element_ids.Add(elem.Id)
                    self.view.HideElementsTemporary(element_ids)
                
                self.is_hidden = True
                self.btn_hide.Text = "Unhide"
                self.btn_hide.BackColor = Color.FromArgb(255, 152, 0)  # Orange
                self.status_label.Text = "{} elements hidden".format(len(elements))
            else:
                # Unhide elements (reset temporary hide)
                with revit.Transaction("Unhide Elements"):
                    self.view.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate)
                
                self.is_hidden = False
                self.btn_hide.Text = "Hide"
                self.btn_hide.BackColor = Color.FromArgb(46, 125, 154)  # Blue
                self.status_label.Text = "Elements unhidden"
                
        except Exception as e:
            self.status_label.Text = "Error toggling hide: {}".format(str(e))
    
    def delete_elements(self, sender, args):
        """Delete selected elements"""
        try:
            elements = self.get_selected_elements()
            if not elements:
                self.status_label.Text = "No elements selected"
                return
            
            # Confirm deletion
            result = MessageBox.Show(
                "Are you sure you want to delete {} elements?\n\nThis action cannot be undone!".format(len(elements)),
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            )
            
            if result == DialogResult.Yes:
                with revit.Transaction("Delete Elements"):
                    element_ids = System.Collections.Generic.List[ElementId]()
                    for elem in elements:
                        element_ids.Add(elem.Id)
                    self.doc.Delete(element_ids)
                
                self.status_label.Text = "{} elements deleted".format(len(elements))
                # Refresh the list
                self.on_category_changed(None, None)
            else:
                self.status_label.Text = "Delete operation cancelled"
                
        except Exception as e:
            self.status_label.Text = "Error deleting elements: {}".format(str(e))
    
    def choose_color(self, sender, args):
        """Choose color for override"""
        try:
            color_dialog = ColorDialog()
            color_dialog.Color = self.selected_color
            if color_dialog.ShowDialog() == DialogResult.OK:
                self.selected_color = color_dialog.Color
                self.color_panel.BackColor = self.selected_color
                self.status_label.Text = "Color selected: R={}, G={}, B={}".format(
                    self.selected_color.R, self.selected_color.G, self.selected_color.B)
        except Exception as e:
            self.status_label.Text = "Error choosing color: {}".format(str(e))
    
    def override_color(self, sender, args):
        """Override color of selected elements"""
        try:
            elements = self.get_selected_elements()
            if not elements:
                self.status_label.Text = "No elements selected"
                return
            
            # Create Revit Color using correct method
            from Autodesk.Revit.DB import Color as RevitColor
            revit_color = RevitColor(
                int(self.selected_color.R), 
                int(self.selected_color.G), 
                int(self.selected_color.B)
            )
            
            count = 0
            with revit.Transaction("Override Element Color"):
                # Create override settings with only working properties
                override_settings = OverrideGraphicSettings()
                
                # Set colors that work for most elements
                override_settings.SetProjectionLineColor(revit_color)
                override_settings.SetCutLineColor(revit_color)
                
                # Try to set surface colors if available
                try:
                    override_settings.SetSurfaceForegroundPatternColor(revit_color)
                except:
                    pass
                
                try:
                    override_settings.SetSurfaceBackgroundPatternColor(revit_color)
                except:
                    pass
                
                # Apply to each element
                for element in elements:
                    try:
                        self.view.SetElementOverrides(element.Id, override_settings)
                        count += 1
                    except Exception as elem_error:
                        # Skip elements that can't be overridden
                        continue
            
            if count > 0:
                self.status_label.Text = "Color override applied to {} of {} elements (RGB: {},{},{})".format(
                    count, len(elements), self.selected_color.R, self.selected_color.G, self.selected_color.B)
            else:
                self.status_label.Text = "Could not apply color override to any elements. Try selecting different element types."
            
        except Exception as e:
            self.status_label.Text = "Error overriding color: {}".format(str(e))
    
    def reset_view(self, sender, args):
        """Reset view to normal state"""
        try:
            with revit.Transaction("Reset View"):
                # Disable temporary view modes
                self.view.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate)
                
                # Clear all element overrides in view
                collector = FilteredElementCollector(self.doc, self.view.Id)
                elements = collector.WhereElementIsNotElementType().ToElements()
                
                reset_count = 0
                for element in elements:
                    try:
                        override_settings = self.view.GetElementOverrides(element.Id)
                        if override_settings.IsValidOverride:
                            # Clear overrides by setting to default
                            self.view.SetElementOverrides(element.Id, OverrideGraphicSettings())
                            reset_count += 1
                    except:
                        continue
            
            # Reset button states
            self.is_isolated = False
            self.is_hidden = False
            self.btn_isolate.Text = "Isolate"
            self.btn_isolate.BackColor = Color.FromArgb(46, 125, 154)
            self.btn_hide.Text = "Hide"
            self.btn_hide.BackColor = Color.FromArgb(46, 125, 154)
            
            self.status_label.Text = "View reset - {} element overrides cleared".format(reset_count)
            
        except Exception as e:
            self.status_label.Text = "Error resetting view: {}".format(str(e))

# Main execution
if __name__ == '__main__':
    try:
        form = WorkingElementManager()
        form.ShowDialog()
    except Exception as e:
        TaskDialog.Show("Error", "Failed to create Element Manager: {}".format(str(e)))