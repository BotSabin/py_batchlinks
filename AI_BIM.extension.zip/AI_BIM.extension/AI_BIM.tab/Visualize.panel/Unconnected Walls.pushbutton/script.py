# -*- coding: utf-8 -*-
__title__ = "Highlight Unconnected Walls"
__author__ = "GHASEM | AI.BIM"
__doc__ = "Creates or reuses a 3D view and highlights Unconnected Top Walls using solid red fill."

from Autodesk.Revit.DB import *
from pyrevit import revit, script
from Autodesk.Revit.DB import ViewFamily

doc = revit.doc
uidoc = revit.uidoc

view_name = "Highlight Unconnected Walls"

# --- Function: Get or create 3D view
def get_or_create_3d_view():
    for view in FilteredElementCollector(doc).OfClass(View3D):
        if not view.IsTemplate and view.Name == view_name:
            return view

    # Use ViewFamily.ThreeDimensional (✅ correct enum!)
    view_family_type = None
    for vft in FilteredElementCollector(doc).OfClass(ViewFamilyType):
        if vft.ViewFamily == ViewFamily.ThreeDimensional:
            view_family_type = vft
            break

    if not view_family_type:
        script.print_output("3D ViewFamilyType not found.")
        script.exit()

    new_view = View3D.CreateIsometric(doc, view_family_type.Id)
    new_view.Name = view_name
    new_view.DetailLevel = ViewDetailLevel.Fine
    new_view.DisplayStyle = DisplayStyle.Shading
    return new_view

# --- Step 1: Create or get 3D view
t0 = Transaction(doc, "Prepare 3D View")
t0.Start()
target_view = get_or_create_3d_view()
t0.Commit()

# --- Step 2: Activate the view
uidoc.ActiveView = target_view

# --- Step 3: Collect elements in view
collector = FilteredElementCollector(doc, target_view.Id).WhereElementIsNotElementType()

# --- Get solid fill pattern
def get_solid_fill_pattern_id():
    patterns = FilteredElementCollector(doc).OfClass(FillPatternElement)
    for pat in patterns:
        if pat.GetFillPattern().IsSolidFill:
            return pat.Id
    return None

solid_fill_id = get_solid_fill_pattern_id()
if not solid_fill_id:
    script.print_output("Solid fill pattern not found.")
    script.exit()

# --- Create graphic overrides
red_override = OverrideGraphicSettings()
red_override.SetSurfaceForegroundPatternId(solid_fill_id)
red_override.SetSurfaceForegroundPatternColor(Color(255, 0, 0))  # Red
red_override.SetSurfaceTransparency(30)

faded_override = OverrideGraphicSettings()
faded_override.SetSurfaceTransparency(70)

# --- Analyze elements
TOP_CONSTRAINT_PARAM = BuiltInParameter.WALL_HEIGHT_TYPE
unconnected_ids = []
other_ids = []

for elem in collector:
    if not elem.Category or not elem.Category.HasMaterialQuantities:
        continue

    if isinstance(elem, Wall):
        param = elem.get_Parameter(TOP_CONSTRAINT_PARAM)
        if param and param.AsElementId() == ElementId.InvalidElementId:
            unconnected_ids.append(elem.Id)
        else:
            other_ids.append(elem.Id)
    else:
        other_ids.append(elem.Id)

# --- Step 4: Apply overrides
t1 = Transaction(doc, "Apply Overrides")
t1.Start()

for eid in other_ids:
    target_view.SetElementOverrides(eid, faded_override)

for eid in unconnected_ids:
    target_view.SetElementOverrides(eid, red_override)

t1.Commit()
