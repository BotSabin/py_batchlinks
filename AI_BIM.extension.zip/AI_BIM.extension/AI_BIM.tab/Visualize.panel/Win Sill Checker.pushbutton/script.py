# -*- coding: utf-8 -*-
import os
import clr
import datetime
from pyrevit import revit, DB, script
from pyrevit.forms import ask_for_string, SelectFromList

clr.AddReference("System")
from System.IO import StreamWriter, File, FileMode
from System.Text import Encoding

doc = __revit__.ActiveUIDocument.Document
output = script.get_output()
output.print_md("### Window Sill Height Checker (Stable Version)")

# Get sill height threshold from user
threshold_input = ask_for_string(
    prompt="Window sill height threshold (mm):",
    title="Enter Threshold",
    default="900"
)

try:
    threshold_mm = float(threshold_input)
    threshold_ft = threshold_mm / 304.8
except:
    output.print_md("Error: Invalid input value.")
    raise SystemExit

threshold_title = int(threshold_mm)

# Color options
color_options = {
    "Red": DB.Color(255, 0, 0),
    "Green": DB.Color(0, 255, 0),
    "Blue": DB.Color(0, 0, 255),
    "Yellow": DB.Color(255, 255, 0),
}

color_choice = SelectFromList.show(
    color_options.keys(),
    title="Window Color Display",
    multiselect=False
)

if color_choice:
    selected_color = color_options[color_choice]
else:
    output.print_md("No color selected.")
    raise SystemExit

# Override graphic settings
ogs = DB.OverrideGraphicSettings()
ogs.SetProjectionLineColor(selected_color)
ogs.SetSurfaceForegroundPatternColor(selected_color)

# Find solid fill pattern
solid_fill_id = None
for elem in DB.FilteredElementCollector(doc).OfClass(DB.FillPatternElement):
    pattern = elem.GetFillPattern()
    if pattern and pattern.IsSolidFill:
        solid_fill_id = elem.Id
        break
if solid_fill_id:
    ogs.SetSurfaceForegroundPatternId(solid_fill_id)

# Collect windows in active view
windows = DB.FilteredElementCollector(doc, doc.ActiveView.Id)             .OfCategory(DB.BuiltInCategory.OST_Windows)             .WhereElementIsNotElementType()             .ToElements()

low_sill_windows = []
high_sill_windows = []

t = DB.Transaction(doc, "Mark Low Sill Windows")
t.Start()
for win in windows:
    param = win.LookupParameter("Sill Height")
    if param and param.StorageType == DB.StorageType.Double:
        sill_height = param.AsDouble()
        sill_mm = round(sill_height * 304.8, 1)
        win_name = win.Name
        win_id = str(win.Id)
        level = win.Document.GetElement(win.LevelId).Name if win.LevelId else "Unknown"

        if sill_height < threshold_ft:
            doc.ActiveView.SetElementOverrides(win.Id, ogs)
            low_sill_windows.append((win_name, sill_mm, win_id, level))
        else:
            high_sill_windows.append((win_name, sill_mm, win_id, level))
t.Commit()

# Summary in pyRevit output panel
output.print_md("Windows below threshold: {}".format(len(low_sill_windows)))
output.print_md("Windows at or above threshold: {}".format(len(high_sill_windows)))

# Create report folder on Desktop
today = datetime.datetime.now().strftime("%Y-%m-%d")
desktop = os.path.join(os.path.expanduser("~"), "Desktop")
report_dir = os.path.join(desktop, "LowSillReports_" + today)

if not os.path.exists(report_dir):
    os.makedirs(report_dir)

html_path = os.path.join(report_dir, "LowSillReport.html")

# Generate basic HTML report
html = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Window Sill Report</title>
<style>
body { font-family: Tahoma; direction: ltr; background: #f7f7f7; padding: 20px; }
h2 { color: #333; }
table { width: 100%%; border-collapse: collapse; background: #fff; margin-top: 20px; }
th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
th { background: #444; color: white; }
tr.low { background-color: #ffe6e6; }
tr.ok { background-color: #e6ffe6; }
</style>
</head>
<body>

<h2>Window Sill Height Report (Threshold: less than %d mm)</h2>
<p>Windows below threshold: %d</p>
<p>Windows at or above threshold: %d</p>

<h3>Windows Below Threshold</h3>
<table>
<tr><th>Name</th><th>Height (mm)</th><th>Element ID</th><th>Level</th></tr>
""" % (threshold_title, len(low_sill_windows), len(high_sill_windows))

for name, height, eid, level in low_sill_windows:
    html += "<tr class='low'><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (name, height, eid, level)

html += "</table><h3>Windows At or Above Threshold</h3><table><tr><th>Name</th><th>Height (mm)</th><th>Element ID</th><th>Level</th></tr>"

for name, height, eid, level in high_sill_windows:
    html += "<tr class='ok'><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (name, height, eid, level)

html += "</table></body></html>"

# Save HTML file
stream = File.Open(html_path, FileMode.Create)
writer = StreamWriter(stream, Encoding.UTF8)
writer.Write(html)
writer.Close()
stream.Close()

output.print_md("HTML file saved at:")
output.print_md("`{}`".format(html_path))
