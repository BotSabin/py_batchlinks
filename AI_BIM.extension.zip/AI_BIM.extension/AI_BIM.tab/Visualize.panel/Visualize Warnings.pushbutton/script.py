# -*- coding: utf-8 -*-
"""
Enhanced Revit Warnings Management Script
Visualizes and reports warnings with improved error handling and features
"""
import os
import sys
import datetime
import json
from collections import defaultdict
from Autodesk.Revit.DB import *
from pyrevit import revit, DB, forms, script
from System.Collections.Generic import List

# Constants
COLORS = {
    'green': Color(0, 200, 0),
    'red': Color(220, 50, 50),
    'yellow': Color(255, 200, 0),
    'orange': Color(255, 140, 0),
    'blue': Color(70, 130, 200),
    'gray': Color(160, 160, 160),
    'light_gray': Color(220, 220, 220)
}

TRANSPARENCY_LEVELS = {
    'single': 25,
    'multiple': 30,
    'background': 80
}

class WarningsManager:
    def __init__(self):
        self.doc = revit.doc
        self.uidoc = revit.uidoc
        self.output = script.get_output()
        self.solid_fill_id = None
        self.warnings_data = {}
        
    def get_solid_fill_pattern(self):
        """Get solid fill pattern ID with error handling"""
        try:
            fps = FilteredElementCollector(self.doc).OfClass(FillPatternElement)
            for fp in fps:
                if fp.GetFillPattern().IsSolidFill:
                    return fp.Id
            # Create solid fill if none exists
            return self.create_solid_fill_pattern()
        except Exception as e:
            self.output.print_md("Warning: Error getting fill pattern: " + str(e))
            return None
    
    def create_solid_fill_pattern(self):
        """Create a solid fill pattern if none exists"""
        try:
            with Transaction(self.doc, "Create Solid Fill") as t:
                t.Start()
                fill_pattern = FillPattern.CreateSolidFill()
                pattern_element = FillPatternElement.Create(self.doc, fill_pattern)
                t.Commit()
                return pattern_element.Id
        except:
            return None
    
    def collect_warnings(self):
        """Enhanced warnings collection with categorization"""
        failures = self.doc.GetWarnings()
        if not failures:
            forms.alert("No warnings found in the model.", title="Information", exitscript=True)
        
        warning_dict = defaultdict(list)
        warning_categories = defaultdict(int)
        
        for warning in failures:
            msg = warning.GetDescriptionText()
            elems = warning.GetFailingElements()
            severity = warning.GetSeverity().ToString()
            
            warning_dict[msg].extend(elems)
            warning_categories[severity] += 1
            
            # Store additional metadata
            if msg not in self.warnings_data:
                self.warnings_data[msg] = {
                    'severity': severity,
                    'count': 0,
                    'elements': []
                }
            self.warnings_data[msg]['count'] += len(elems)
            self.warnings_data[msg]['elements'].extend(elems)
        
        return warning_dict, warning_categories
    
    def select_warnings_dialog(self, warning_dict, warning_categories):
        """Enhanced warning selection dialog"""
        # Create formatted list with severity and count info
        formatted_warnings = []
        for msg in sorted(warning_dict.keys()):
            count = len(warning_dict[msg])
            severity = self.warnings_data[msg]['severity']
            severity_icon = "ERROR" if severity == "Error" else "WARN" if severity == "Warning" else "INFO"
            formatted_text = "[" + str(count) + "x] " + severity_icon + ": " + msg
            formatted_warnings.append(formatted_text)
        
        # Show statistics
        stats_msg = "Warning Statistics:\n"
        for sev, count in warning_categories.items():
            stats_msg += "• " + sev + ": " + str(count) + "\n"
        
        selected_formatted = forms.SelectFromList.show(
            formatted_warnings,
            title="Select Warnings to Display",
            message=stats_msg,
            multiselect=True,
            button_name='Display Warnings'
        )
        
        if not selected_formatted:
            script.exit("No warnings selected.")
        
        # Extract original messages
        selected_msgs = []
        for formatted in selected_formatted:
            # Extract original message from formatted string
            if ": " in formatted:
                original_msg = formatted.split(": ", 1)[1]
            else:
                original_msg = formatted
            selected_msgs.append(original_msg)
        
        return selected_msgs
    
    def create_or_get_view(self):
        """Create or get the warnings visualization view"""
        view = None
        view_name = "Warnings Analysis View"
        
        # Check if view exists
        for v in FilteredElementCollector(self.doc).OfClass(View3D).ToElements():
            if not v.IsTemplate and v.Name == view_name:
                view = v
                break
        
        with Transaction(self.doc, "Create/Update Warnings View") as t:
            t.Start()
            
            if not view:
                # Create new 3D view
                vftype = next(v for v in FilteredElementCollector(self.doc).OfClass(ViewFamilyType) 
                             if v.ViewFamily == ViewFamily.ThreeDimensional)
                view = View3D.CreateIsometric(self.doc, vftype.Id)
                view.Name = view_name
            
            # Configure view settings
            view.DisplayStyle = DisplayStyle.ShadingWithEdges
            view.DetailLevel = ViewDetailLevel.Fine
            
            # Hide annotation categories
            cats_to_hide = ["Grids", "Levels", "Sections", "Elevations", "Dimensions", "Text Notes"]
            cats = self.doc.Settings.Categories
            
            for cat_name in cats_to_hide:
                if cats.Contains(cat_name):
                    try:
                        view.SetCategoryHidden(cats.get_Item(cat_name).Id, True)
                    except:
                        pass
            
            t.Commit()
        
        return view
    
    def get_element_id_string(self, element_id):
        """Safely get element ID as string"""
        try:
            # Try different methods to get the ID value
            if hasattr(element_id, 'IntegerValue'):
                return str(element_id.IntegerValue)
            elif hasattr(element_id, 'Value'):
                return str(element_id.Value)
            else:
                return str(element_id)
        except:
            return str(element_id)
    
    def apply_visual_overrides(self, view, selected_msgs, warning_dict):
        """Enhanced visual override system with multiple colors"""
        selected_ids = set()
        warnings_log = []
        color_assignments = {}
        
        with Transaction(self.doc, "Apply Warning Visualization") as t:
            t.Start()
            
            # Reset all overrides first
            try:
                for eid in FilteredElementCollector(self.doc, view.Id).WhereElementIsNotElementType().ToElementIds():
                    view.SetElementOverrides(eid, OverrideGraphicSettings())
            except Exception as e:
                self.output.print_md("Warning: Error resetting overrides: " + str(e))
            
            # Assign colors to different warning types
            color_list = ['red', 'green', 'yellow', 'orange', 'blue']
            
            for i, msg in enumerate(selected_msgs):
                color_key = color_list[i % len(color_list)]
                color_assignments[msg] = color_key
                
                ids = list(set(warning_dict[msg]))
                severity = self.warnings_data[msg]['severity']
                
                # Log warning info - FIXED: Use safe method to get element ID strings
                element_ids_str = ', '.join([self.get_element_id_string(id) for id in ids[:5]])  # Show first 5 IDs
                if len(ids) > 5:
                    element_ids_str += " ... (+" + str(len(ids)-5) + " more)"
                
                warnings_log.append({
                    'message': msg,
                    'severity': severity,
                    'count': len(ids),
                    'element_ids': element_ids_str,
                    'color': color_key
                })
                
                # Apply overrides to elements
                for j, elem_id in enumerate(ids):
                    if elem_id in selected_ids:
                        continue
                    
                    try:
                        el = self.doc.GetElement(elem_id)
                        if el:
                            ogs = OverrideGraphicSettings()
                            color = COLORS[color_key]
                            
                            # Different visual treatment based on element index
                            if j == 0:  # First element - solid color
                                ogs.SetSurfaceForegroundPatternColor(color)
                                ogs.SetSurfaceForegroundPatternId(self.solid_fill_id)
                                ogs.SetSurfaceTransparency(TRANSPARENCY_LEVELS['single'])
                            else:  # Other elements - outline
                                ogs.SetProjectionLineColor(color)
                                ogs.SetProjectionLineWeight(5)
                                ogs.SetSurfaceTransparency(TRANSPARENCY_LEVELS['multiple'])
                            
                            view.SetElementOverrides(elem_id, ogs)
                            selected_ids.add(elem_id)
                    
                    except Exception as e:
                        continue
            
            # Apply gray background to other elements
            try:
                for elem in FilteredElementCollector(self.doc, view.Id).WhereElementIsNotElementType().ToElements():
                    if elem.Id not in selected_ids and elem.Category:
                        try:
                            gr = OverrideGraphicSettings()
                            gr.SetSurfaceForegroundPatternColor(COLORS['light_gray'])
                            gr.SetSurfaceForegroundPatternId(self.solid_fill_id)
                            gr.SetSurfaceTransparency(TRANSPARENCY_LEVELS['background'])
                            view.SetElementOverrides(elem.Id, gr)
                        except:
                            pass
            except Exception as e:
                self.output.print_md("Warning: Error applying background: " + str(e))
            
            t.Commit()
        
        return warnings_log, color_assignments
    
    def create_reports(self, warnings_log, color_assignments, view):
        """Create enhanced HTML and JSON reports"""
        now = datetime.datetime.now()
        timestamp = now.strftime("%Y-%m-%dT%H%M%S")
        report_date_str = now.strftime("%Y-%m-%d %H:%M:%S")
        
        # Create folder structure
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        base_folder = os.path.join(desktop, "Revit_Warning_Reports")
        project_name = self.doc.Title or "Unknown_Project"
        report_folder = os.path.join(base_folder, project_name, timestamp)
        
        try:
            if not os.path.exists(report_folder):
                os.makedirs(report_folder)
        except Exception as e:
            forms.alert("Error creating folder: " + str(e))
            return None
        
        # Export screenshot with higher quality
        img_file = os.path.join(report_folder, "warnings_visualization.png")
        self.export_screenshot(view, img_file)
        
        # Create HTML report
        html_file = os.path.join(report_folder, "warnings_report.html")
        self.create_html_report(html_file, warnings_log, color_assignments, report_date_str, img_file)
        
        # Create JSON data export
        json_file = os.path.join(report_folder, "warnings_data.json")
        self.create_json_report(json_file, warnings_log, report_date_str)
        
        return report_folder, html_file, img_file, json_file
    
    def export_screenshot(self, view, img_file):
        """Export high-quality screenshot"""
        try:
            img_opts = ImageExportOptions()
            img_opts.ExportRange = ExportRange.VisibleRegionOfCurrentView
            img_opts.FilePath = img_file.replace(".png", "")
            img_opts.HLRandWFViewsFileType = ImageFileType.PNG
            img_opts.ImageResolution = ImageResolution.DPI_300
            img_opts.ZoomType = ZoomFitType.FitToPage
            img_opts.PixelSize = 2560
            img_opts.ShadowViewsFileType = ImageFileType.PNG
            img_opts.ViewName = view.Name
            
            view_ids = List[ElementId]()
            view_ids.Add(view.Id)
            img_opts.SetViewsAndSheets(view_ids)
            
            self.doc.ExportImage(img_opts)
        except Exception as e:
            self.output.print_md("Warning: Error exporting image: " + str(e))
    
    def create_html_report(self, html_file, warnings_log, color_assignments, report_date, img_file):
        """Create enhanced HTML report"""
        # Generate color legend
        legend_html = ""
        for msg, color in color_assignments.items():
            color_hex = self.color_to_hex(COLORS[color])
            legend_html += '<div class="legend-item"><span class="color-box" style="background-color: ' + color_hex + ';"></span>' + msg[:60] + '...</div>\n'
        
        # Generate warnings table
        table_rows = ""
        for warning in warnings_log:
            severity_class = warning['severity'].lower()
            color_hex = self.color_to_hex(COLORS[warning['color']])
            table_rows += ('<tr class="' + severity_class + '">' +
                          '<td><span class="color-indicator" style="background-color: ' + color_hex + ';"></span></td>' +
                          '<td>' + warning['severity'] + '</td>' +
                          '<td>' + warning['message'] + '</td>' +
                          '<td>' + str(warning['count']) + '</td>' +
                          '<td class="element-ids">' + warning['element_ids'] + '</td>' +
                          '</tr>\n')
        
        # Create HTML content using string concatenation instead of f-strings
        html_parts = []
        html_parts.append('<!DOCTYPE html>')
        html_parts.append('<html lang="en">')
        html_parts.append('<head>')
        html_parts.append('<meta charset="UTF-8">')
        html_parts.append('<meta name="viewport" content="width=device-width, initial-scale=1.0">')
        html_parts.append('<title>Revit Warnings Report</title>')
        html_parts.append('<style>')
        html_parts.append('body { font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif; margin: 0; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }')
        html_parts.append('.container { max-width: 1200px; margin: 0 auto; background: white; min-height: 100vh; }')
        html_parts.append('.header { background: linear-gradient(135deg, #2c3e50, #3498db); color: white; padding: 30px; text-align: center; }')
        html_parts.append('.content { padding: 30px; }')
        html_parts.append('.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }')
        html_parts.append('.stat-card { background: #f8f9fa; padding: 20px; border-radius: 10px; border-left: 4px solid #3498db; }')
        html_parts.append('.legend { background: #f1f3f4; padding: 20px; border-radius: 10px; margin: 20px 0; }')
        html_parts.append('.legend-item { display: flex; align-items: center; margin: 10px 0; }')
        html_parts.append('.color-box { width: 20px; height: 20px; margin-right: 10px; border-radius: 3px; }')
        html_parts.append('.screenshot { text-align: center; margin: 30px 0; }')
        html_parts.append('.screenshot img { max-width: 100%; border-radius: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.3); }')
        html_parts.append('table { width: 100%; border-collapse: collapse; margin: 20px 0; background: white; border-radius: 10px; overflow: hidden; }')
        html_parts.append('th { background: #34495e; color: white; padding: 15px; font-weight: 600; }')
        html_parts.append('td { padding: 12px; border-bottom: 1px solid #eee; }')
        html_parts.append('.error { background-color: #ffebee; }')
        html_parts.append('.warning { background-color: #fff3e0; }')
        html_parts.append('.color-indicator { display: inline-block; width: 20px; height: 20px; border-radius: 50%; }')
        html_parts.append('.element-ids { font-family: monospace; font-size: 0.9em; }')
        html_parts.append('.footer { background: #2c3e50; color: white; text-align: center; padding: 20px; }')
        html_parts.append('</style>')
        html_parts.append('</head>')
        html_parts.append('<body>')
        html_parts.append('<div class="container">')
        html_parts.append('<div class="header">')
        html_parts.append('<h1>Revit Warnings Analysis Report</h1>')
        html_parts.append('<p>Report Date: ' + report_date + '</p>')
        html_parts.append('</div>')
        html_parts.append('<div class="content">')
        html_parts.append('<div class="stats">')
        html_parts.append('<div class="stat-card">')
        html_parts.append('<h3>Total Warnings</h3>')
        html_parts.append('<h2>' + str(len(warnings_log)) + '</h2>')
        html_parts.append('</div>')
        html_parts.append('<div class="stat-card">')
        html_parts.append('<h3>Project</h3>')
        html_parts.append('<h2>' + (self.doc.Title or 'Unknown') + '</h2>')
        html_parts.append('</div>')
        html_parts.append('<div class="stat-card">')
        html_parts.append('<h3>View Used</h3>')
        html_parts.append('<h2>Warnings Analysis View</h2>')
        html_parts.append('</div>')
        html_parts.append('</div>')
        html_parts.append('<div class="legend">')
        html_parts.append('<h3>Color Guide</h3>')
        html_parts.append(legend_html)
        html_parts.append('</div>')
        html_parts.append('<div class="screenshot">')
        html_parts.append('<h3>3D View Screenshot</h3>')
        html_parts.append('<img src="' + os.path.basename(img_file) + '" alt="Warnings Visualization" />')
        html_parts.append('</div>')
        html_parts.append('<h3>Warning Details</h3>')
        html_parts.append('<table>')
        html_parts.append('<tr>')
        html_parts.append('<th>Color</th>')
        html_parts.append('<th>Severity</th>')
        html_parts.append('<th>Warning Message</th>')
        html_parts.append('<th>Count</th>')
        html_parts.append('<th>Element IDs</th>')
        html_parts.append('</tr>')
        html_parts.append(table_rows)
        html_parts.append('</table>')
        html_parts.append('</div>')
        html_parts.append('<div class="footer">')
        html_parts.append('<p>Generated by Revit Warnings Management Script | 2024</p>')
        html_parts.append('</div>')
        html_parts.append('</div>')
        html_parts.append('</body>')
        html_parts.append('</html>')
        
        html_content = '\n'.join(html_parts)
        
        try:
            with open(html_file, 'w', encoding='utf-8') as f:
                f.write(html_content)
        except Exception as e:
            self.output.print_md("Warning: Error creating HTML report: " + str(e))
    
    def create_json_report(self, json_file, warnings_log, report_date):
        """Create JSON data export"""
        json_data = {
            'report_info': {
                'date': report_date,
                'project': self.doc.Title or 'Unknown',
                'total_warnings': len(warnings_log)
            },
            'warnings': warnings_log
        }
        
        try:
            with open(json_file, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            self.output.print_md("Warning: Error creating JSON report: " + str(e))
    
    def color_to_hex(self, color):
        """Convert Revit Color to hex string"""
        return "#{:02x}{:02x}{:02x}".format(color.Red, color.Green, color.Blue)
    
    def run(self):
        """Main execution method"""
        try:
            # Initialize
            self.solid_fill_id = self.get_solid_fill_pattern()
            if not self.solid_fill_id:
                forms.alert("Error getting fill pattern.")
                return
            
            # Collect and analyze warnings
            self.output.print_md("Collecting warnings...")
            warning_dict, warning_categories = self.collect_warnings()
            
            # User selection
            selected_msgs = self.select_warnings_dialog(warning_dict, warning_categories)
            
            # Create/get view
            self.output.print_md("Preparing display view...")
            view = self.create_or_get_view()
            
            # Apply visual overrides
            self.output.print_md("Applying visual settings...")
            warnings_log, color_assignments = self.apply_visual_overrides(view, selected_msgs, warning_dict)
            
            # Set active view
            self.uidoc.ActiveView = view
            
            # Create reports
            self.output.print_md("Creating reports...")
            report_results = self.create_reports(warnings_log, color_assignments, view)
            
            if report_results:
                report_folder, html_file, img_file, json_file = report_results
                
                # Success message
                success_msg = []
                success_msg.append("# Warnings Report Generated Successfully")
                success_msg.append("")
                success_msg.append("## Summary")
                success_msg.append("- **Displayed Warnings Count**: " + str(len(warnings_log)))
                success_msg.append("- **View Used**: Warnings Analysis View")
                success_msg.append("- **Creation Date**: " + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                success_msg.append("")
                success_msg.append("## Generated Files")
                success_msg.append("- **HTML Report**: `" + os.path.basename(html_file) + "`")
                success_msg.append("- **View Image**: `" + os.path.basename(img_file) + "`")
                success_msg.append("- **JSON Data**: `" + os.path.basename(json_file) + "`")
                success_msg.append("- **Folder Path**: `" + report_folder + "`")
                success_msg.append("")
                success_msg.append("## Color Guide")
                
                for msg, color in color_assignments.items():
                    success_msg.append("- **" + color.title() + "**: " + msg[:50] + "...")
                
                success_msg.append("")
                success_msg.append("## Usage Instructions")
                success_msg.append("1. Open the HTML file for complete report viewing")
                success_msg.append("2. Use the image for 3D view results review")
                success_msg.append("3. JSON file can be used for data processing in other applications")
                success_msg.append("4. Archive this folder as part of quality control process")
                success_msg.append("")
                success_msg.append("---")
                success_msg.append("**Revit Warnings Management Script - Enhanced Version**")
                
                self.output.print_md('\n'.join(success_msg))
            
        except Exception as e:
            self.output.print_md("Unexpected error: " + str(e))
            import traceback
            self.output.print_md("Error details:\n```\n" + traceback.format_exc() + "\n```")

# Run the enhanced warnings manager
if __name__ == "__main__":
    manager = WarningsManager()
    manager.run()