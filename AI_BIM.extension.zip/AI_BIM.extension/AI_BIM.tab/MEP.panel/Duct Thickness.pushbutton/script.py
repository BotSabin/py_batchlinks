# -*- coding: utf-8 -*-
__title__ = "Set Duct Thickness + Color View"
__author__ = "Ghasem Ariyani"

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")

from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Mechanical import Duct
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager
from pyrevit import script
import random
import colorsys
from collections import defaultdict

doc = __revit__.ActiveUIDocument.Document
output = script.get_output()

# 🟩 Collect and safely cast to Python list
ducts = list(FilteredElementCollector(doc).OfClass(Duct).WhereElementIsNotElementType().ToElements())
fittings = list(FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_DuctFitting).WhereElementIsNotElementType().ToElements())

# ✅ Combine both safely
elements = ducts + fittings if ducts or fittings else []

thickness_map = {}
group_by_thickness = defaultdict(list)

def generate_unique_colors(values):
    colors = {}
    num_values = len(values)
    for i, val in enumerate(sorted(values)):
        hue = i / float(num_values)
        lightness = 0.5 + random.uniform(-0.1, 0.1)
        saturation = 0.7 + random.uniform(-0.1, 0.1)
        r, g, b = colorsys.hls_to_rgb(hue, lightness, saturation)
        colors[val] = Color(int(r * 255), int(g * 255), int(b * 255))
    return colors

# Start transaction group
tg = TransactionGroup(doc, "Update Duct & Fitting Thickness and Visuals")
tg.Start()

updated_count = 0
thickness_list = []

try:
    for el in elements:
        width_param = el.LookupParameter("Width") or el.LookupParameter("W_Duct")
        thick_param = el.LookupParameter("Duct Thickness")

        if width_param and thick_param and not thick_param.IsReadOnly:
            try:
                width_ft = width_param.AsDouble()
                width_mm = width_ft * 304.8

                if width_mm <= 300:
                    thickness_mm = 0.5
                elif width_mm <= 750:
                    thickness_mm = 0.6
                elif width_mm <= 1370:
                    thickness_mm = 0.75
                elif width_mm <= 2130:
                    thickness_mm = 1.0
                else:
                    thickness_mm = 1.25

                thickness_ft = thickness_mm / 304.8

                t = Transaction(doc, "Set Thickness")
                t.Start()
                thick_param.Set(thickness_ft)
                t.Commit()

                updated_count += 1
                thickness_map[el.Id] = thickness_mm
                group_by_thickness[thickness_mm].append(el)
                thickness_list.append(thickness_mm)

            except:
                if t.HasStarted():
                    t.RollBack()

    # Step 2: Find or Create 3D View
    view3d = None
    for view in FilteredElementCollector(doc).OfClass(View3D).ToElements():
        if not view.IsTemplate and view.Name == "DuctThick":
            view3d = view
            break

    if not view3d:
        view_family_type = None
        for vft in FilteredElementCollector(doc).OfClass(ViewFamilyType):
            if vft.ViewFamily == ViewFamily.ThreeDimensional:
                view_family_type = vft
                break

        t2 = Transaction(doc, "Create 3D View")
        t2.Start()
        view3d = View3D.CreateIsometric(doc, view_family_type.Id)
        view3d.Name = "DuctThick"
        view3d.DetailLevel = ViewDetailLevel.Fine
        view3d.DisplayStyle = DisplayStyle.Shading
        t2.Commit()

    # Step 3: Apply Color Overrides
    color_map = generate_unique_colors(set(thickness_list))

    solid_fill = FilteredElementCollector(doc)\
        .OfClass(FillPatternElement)\
        .ToElements()
    solid_fill = [f for f in solid_fill if f.GetFillPattern().IsSolidFill][0]

    t3 = Transaction(doc, "Apply Color Overrides")
    t3.Start()
    for thickness, group in group_by_thickness.items():
        override = OverrideGraphicSettings()
        override.SetSurfaceTransparency(0)
        override.SetSurfaceForegroundPatternColor(color_map[thickness])
        override.SetSurfaceForegroundPatternId(solid_fill.Id)
        for el in group:
            view3d.SetElementOverrides(el.Id, override)
    t3.Commit()

    tg.Assimilate()

    # Output Summary
    output.print_md("### ✅ Updated `Duct Thickness` for **{}** elements.".format(updated_count))
    output.print_md("### 🧱 View `DuctThick` created or updated with colors:\n")
    for thickness, color in color_map.items():
        count = len(group_by_thickness[thickness])
        output.print_md("- **{} mm** → {} elements | RGB({}, {}, {})".format(
            thickness, count, color.Red, color.Green, color.Blue))

except Exception as e:
    tg.RollBack()
    output.print_md("❌ Operation failed: `{}`".format(str(e)))
