# -*- coding: utf-8 -*-
import clr
import os
import datetime
from pyrevit import revit, DB, script
from pyrevit.forms import ask_for_string

clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")
from RevitServices.Persistence import DocumentManager
from System.IO import File, FileMode, StreamWriter
from System.Text import Encoding

doc = __revit__.ActiveUIDocument.Document
output = script.get_output()
output.print_md("### Duct Bottom Elevation Checker")

# گرفتن آستانه از کاربر (بر حسب میلی‌متر)
threshold_input = ask_for_string(
    prompt="Enter Bottom Elevation Threshold (mm):",
    title="Bottom Elevation Threshold",
    default="2200"
)

try:
    threshold_mm = float(threshold_input)
    threshold_ft = threshold_mm / 304.8
except:
    output.print_md("❌ Invalid input. Please enter a number.")
    raise SystemExit

# تنظیم رنگ هشدار
red = DB.Color(255, 0, 0)
ogs = DB.OverrideGraphicSettings()
ogs.SetProjectionLineColor(red)
ogs.SetSurfaceForegroundPatternColor(red)

# یافتن Solid Fill
solid_fill_id = None
for pat in DB.FilteredElementCollector(doc).OfClass(DB.FillPatternElement):
    if pat.GetFillPattern().IsSolidFill:
        solid_fill_id = pat.Id
        break
if solid_fill_id:
    ogs.SetSurfaceForegroundPatternId(solid_fill_id)

# جمع‌آوری Ductها در نمای فعال
ducts = DB.FilteredElementCollector(doc, doc.ActiveView.Id)\
          .OfCategory(DB.BuiltInCategory.OST_DuctCurves)\
          .WhereElementIsNotElementType()\
          .ToElements()

low_ducts = []
ok_ducts = []

# بررسی پارامتر Bottom Elevation
t = DB.Transaction(doc, "Check Duct Bottom Elevation")
t.Start()
for duct in ducts:
    param = duct.LookupParameter("Lower End Bottom Elevation")
    if param and param.StorageType == DB.StorageType.Double:
        val = param.AsDouble()
        if val < threshold_ft:
            doc.ActiveView.SetElementOverrides(duct.Id, ogs)
            low_ducts.append((str(duct.Id), round(val * 304.8, 1), duct.Name))
        else:
            ok_ducts.append((str(duct.Id), round(val * 304.8, 1), duct.Name))
t.Commit()

output.print_md("✅ Checked {} ducts.".format(len(ducts)))
output.print_md("🔻 Below threshold: {}".format(len(low_ducts)))
output.print_md("✅ OK ducts: {}".format(len(ok_ducts)))

# تولید گزارش HTML
today = datetime.datetime.now().strftime("%Y-%m-%d")
desktop = os.path.join(os.path.expanduser("~"), "Desktop")
report_folder = os.path.join(desktop, "DuctReports_" + today)
if not os.path.exists(report_folder):
    os.makedirs(report_folder)

html_path = os.path.join(report_folder, "DuctBottomElevationReport.html")

html = """
<!DOCTYPE html>
<html lang="fa">
<head>
<meta charset="UTF-8">
<title>گزارش بررسی Bottom Elevation</title>
<style>
body { font-family: Tahoma; direction: rtl; background: #f4f4f4; padding: 20px; }
table { width: 100%%; border-collapse: collapse; background: white; margin-top: 20px; }
th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
th { background: #333; color: white; }
tr.low { background-color: #ffe6e6; }
tr.ok { background-color: #e6ffe6; }
</style>
</head>
<body>

<h2>گزارش بررسی Ductها با Bottom Elevation کمتر از %d میلی‌متر</h2>
<p>تعداد کل Ductها: %d</p>
<p>تعداد زیر آستانه: %d</p>
<p>تعداد مجاز: %d</p>

<h3>موارد زیر آستانه</h3>
<table>
<tr><th>ردیف</th><th>Element ID</th><th>مقدار (میلی‌متر)</th><th>نام</th></tr>
""" % (threshold_mm, len(ducts), len(low_ducts), len(ok_ducts))

for i, (eid, val, name) in enumerate(low_ducts, 1):
    html += "<tr class='low'><td>%d</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (i, eid, val, name)

html += """
</table>

<h3>موارد مجاز</h3>
<table>
<tr><th>ردیف</th><th>Element ID</th><th>مقدار (میلی‌متر)</th><th>نام</th></tr>
"""

for i, (eid, val, name) in enumerate(ok_ducts, 1):
    html += "<tr class='ok'><td>%d</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (i, eid, val, name)

html += """
</table>
</body>
</html>
"""

# ذخیره فایل HTML با StreamWriter (UTF-8 بدون خطای یونیکد)
stream = File.Open(html_path, FileMode.Create)
writer = StreamWriter(stream, Encoding.UTF8)
writer.Write(html)
writer.Close()
stream.Close()

output.print_md("📄 HTML report saved at:\n`{}`".format(html_path))
