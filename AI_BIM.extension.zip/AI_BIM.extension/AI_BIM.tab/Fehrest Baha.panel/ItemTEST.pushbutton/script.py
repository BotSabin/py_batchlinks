"""
Price Table 1404 Import Script for pyRevit
Imports Excel price data and automatically applies to Revit elements
"""

import clr
import sys
import os

# Add references for Revit API
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
clr.AddReference('System')

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from System.Collections.Generic import List
from pyrevit import forms, script, DB
import pandas as pd

class PriceTableImporter:
    def __init__(self):
        """Initialize the importer with current Revit document"""
        self.doc = __revit__.ActiveUIDocument.Document
        self.uidoc = __revit__.ActiveUIDocument
        self.output = script.get_output()
        
        # Define parameter names for price information
        self.price_params = {
            'unit_price': 'قیمت_واحد_1404',
            'total_price': 'قیمت_کل_1404', 
            'unit': 'واحد_قیمت_1404',
            'description': 'شرح_قیمت_1404',
            'code': 'کد_فهرست_بها_1404'
        }
        
    def load_excel_data(self, excel_path):
        """
        Load price data from Excel file
        Expected columns: Element_Type, Element_Name, Unit_Price, Unit, Description, Code
        """
        try:
            # Read Excel file with Persian support
            df = pd.read_excel(excel_path, engine='openpyxl')
            
            # Expected column mapping (can be customized)
            required_columns = ['Element_Type', 'Element_Name', 'Unit_Price', 'Unit', 'Description', 'Code']
            
            # Check if all required columns exist
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                forms.alert(f"ستون‌های زیر در فایل اکسل موجود نیستند: {missing_columns}")
                return None
                
            # Convert to dictionary for faster lookup
            price_data = {}
            for _, row in df.iterrows():
                element_type = str(row['Element_Type']).strip()
                element_name = str(row['Element_Name']).strip()
                
                key = f"{element_type}_{element_name}"
                price_data[key] = {
                    'unit_price': float(row['Unit_Price']) if pd.notna(row['Unit_Price']) else 0,
                    'unit': str(row['Unit']),
                    'description': str(row['Description']),
                    'code': str(row['Code'])
                }
            
            self.output.print_md(f"## تعداد {len(price_data)} آیتم قیمت از اکسل بارگذاری شد")
            return price_data
            
        except Exception as e:
            forms.alert(f"خطا در خواندن فایل اکسل: {str(e)}")
            return None
    
    def create_shared_parameters(self):
        """Create shared parameters for price information if they don't exist"""
        try:
            # Get the shared parameters file path
            app = self.doc.Application
            
            with Transaction(self.doc, "Create Price Parameters") as t:
                t.Start()
                
                # Create parameters in project if they don't exist
                for param_key, param_name in self.price_params.items():
                    if not self.parameter_exists_in_project(param_name):
                        self.create_project_parameter(param_name, param_key)
                
                t.Commit()
                return True
                
        except Exception as e:
            self.output.print_md(f"**خطا در ایجاد پارامترها**: {str(e)}")
            return False
    
    def parameter_exists_in_project(self, param_name):
        """Check if parameter exists in project"""
        try:
            # Get all project parameters
            binding_map = self.doc.ParameterBindings
            iterator = binding_map.ForwardIterator()
            
            while iterator.MoveNext():
                definition = iterator.Key
                if definition.Name == param_name:
                    return True
            return False
        except:
            return False
    
    def create_project_parameter(self, param_name, param_type_key):
        """Create a project parameter"""
        try:
            # Define parameter type based on key
            if param_type_key in ['unit_price', 'total_price']:
                param_type = ParameterType.Currency
                unit_type = UnitType.UT_Currency
            else:
                param_type = ParameterType.Text
                unit_type = UnitType.UT_Undefined
            
            # Create parameter definition
            param_group = BuiltInParameterGroup.PG_DATA
            
            # Get categories to bind parameter to
            categories = self.get_relevant_categories()
            category_set = app.Create.NewCategorySet()
            
            for cat in categories:
                category_set.Insert(cat)
            
            # Create external definition
            original_def = ExternalDefinitionCreationOptions(param_name, param_type)
            original_def.UserModifiable = True
            
            # Create binding
            binding = app.Create.NewInstanceBinding(category_set)
            
            # Bind parameter
            self.doc.ParameterBindings.Insert(original_def, binding, param_group)
            
        except Exception as e:
            self.output.print_md(f"خطا در ایجاد پارامتر {param_name}: {str(e)}")
    
    def get_relevant_categories(self):
        """Get categories that should have price parameters"""
        category_list = [
            BuiltInCategory.OST_Walls,
            BuiltInCategory.OST_Floors, 
            BuiltInCategory.OST_Roofs,
            BuiltInCategory.OST_Doors,
            BuiltInCategory.OST_Windows,
            BuiltInCategory.OST_Columns,
            BuiltInCategory.OST_StructuralFraming,
            BuiltInCategory.OST_Pipes,
            BuiltInCategory.OST_DuctCurves,
            BuiltInCategory.OST_ElectricalFixtures,
            BuiltInCategory.OST_LightingFixtures,
            BuiltInCategory.OST_PlumbingFixtures,
            BuiltInCategory.OST_MechanicalEquipment,
            BuiltInCategory.OST_ElectricalEquipment
        ]
        
        categories = []
        for cat_id in category_list:
            try:
                category = Category.GetCategory(self.doc, cat_id)
                if category:
                    categories.append(category)
            except:
                continue
                
        return categories
    
    def get_element_key(self, element):
        """Generate lookup key for element based on category and family name"""
        try:
            category_name = element.Category.Name if element.Category else "Unknown"
            
            # Get family name or type name
            family_name = ""
            if hasattr(element, 'Symbol') and element.Symbol:
                family_name = element.Symbol.FamilyName
            elif hasattr(element, 'Name'):
                family_name = element.Name
            else:
                family_name = "Unknown"
            
            # Clean and format the key
            key = f"{category_name}_{family_name}".replace(" ", "_")
            return key
            
        except Exception as e:
            return "Unknown_Unknown"
    
    def apply_price_data(self, price_data, selected_categories=None):
        """Apply price data to elements in the model"""
        if not price_data:
            forms.alert("داده‌های قیمت موجود نیست!")
            return
        
        # Get elements to process
        elements_to_process = self.get_elements_to_process(selected_categories)
        
        if not elements_to_process:
            forms.alert("هیچ المانی برای پردازش یافت نشد!")
            return
        
        # Start transaction
        with Transaction(self.doc, "Apply Price Data 1404") as t:
            t.Start()
            
            processed_count = 0
            matched_count = 0
            
            for element in elements_to_process:
                try:
                    # Generate lookup key
                    element_key = self.get_element_key(element)
                    
                    # Find matching price data
                    price_info = self.find_matching_price(element_key, price_data)
                    
                    if price_info:
                        # Apply price parameters
                        if self.set_element_price_parameters(element, price_info):
                            matched_count += 1
                    
                    processed_count += 1
                    
                except Exception as e:
                    self.output.print_md(f"خطا در پردازش المان {element.Id}: {str(e)}")
                    continue
            
            t.Commit()
            
            # Show results
            self.output.print_md(f"## نتایج اعمال قیمت‌ها")
            self.output.print_md(f"- تعداد المان‌های پردازش شده: **{processed_count}**")
            self.output.print_md(f"- تعداد المان‌های تطبیق یافته: **{matched_count}**")
            self.output.print_md(f"- درصد موفقیت: **{(matched_count/processed_count*100):.1f}%**")
    
    def find_matching_price(self, element_key, price_data):
        """Find matching price data for element"""
        # Direct match
        if element_key in price_data:
            return price_data[element_key]
        
        # Fuzzy matching - check partial matches
        for price_key in price_data.keys():
            if self.is_similar_key(element_key, price_key):
                return price_data[price_key]
        
        return None
    
    def is_similar_key(self, element_key, price_key):
        """Check if keys are similar enough for matching"""
        element_parts = element_key.lower().split('_')
        price_parts = price_key.lower().split('_')
        
        # Check if at least 50% of parts match
        matches = 0
        for part in element_parts:
            if any(part in price_part or price_part in part for price_part in price_parts):
                matches += 1
        
        similarity = matches / len(element_parts)
        return similarity >= 0.5
    
    def set_element_price_parameters(self, element, price_info):
        """Set price parameters for an element"""
        try:
            success = True
            
            # Set unit price
            unit_price_param = element.LookupParameter(self.price_params['unit_price'])
            if unit_price_param and not unit_price_param.IsReadOnly:
                unit_price_param.Set(price_info['unit_price'])
            
            # Calculate and set total price based on quantity
            quantity = self.calculate_element_quantity(element)
            total_price = price_info['unit_price'] * quantity
            
            total_price_param = element.LookupParameter(self.price_params['total_price'])
            if total_price_param and not total_price_param.IsReadOnly:
                total_price_param.Set(total_price)
            
            # Set text parameters
            unit_param = element.LookupParameter(self.price_params['unit'])
            if unit_param and not unit_param.IsReadOnly:
                unit_param.Set(price_info['unit'])
            
            desc_param = element.LookupParameter(self.price_params['description'])
            if desc_param and not desc_param.IsReadOnly:
                desc_param.Set(price_info['description'])
            
            code_param = element.LookupParameter(self.price_params['code'])
            if code_param and not code_param.IsReadOnly:
                code_param.Set(price_info['code'])
            
            return success
            
        except Exception as e:
            return False
    
    def calculate_element_quantity(self, element):
        """Calculate quantity for element based on its type"""
        try:
            category = element.Category.Name if element.Category else ""
            
            # For walls, floors, roofs - use area
            if any(cat in category.lower() for cat in ['wall', 'floor', 'roof', 'ceiling']):
                area_param = element.LookupParameter("Area")
                if area_param:
                    return area_param.AsDouble() * 0.092903  # Convert to square meters
            
            # For linear elements - use length
            elif any(cat in category.lower() for cat in ['beam', 'column', 'pipe', 'duct']):
                length_param = element.LookupParameter("Length")
                if length_param:
                    return length_param.AsDouble() * 0.3048  # Convert to meters
            
            # For other elements - count as 1
            return 1.0
            
        except:
            return 1.0
    
    def get_elements_to_process(self, selected_categories=None):
        """Get elements to process based on selected categories"""
        elements = []
        
        if selected_categories:
            # Process only selected categories
            for category in selected_categories:
                collector = FilteredElementCollector(self.doc)\
                    .OfCategory(category)\
                    .WhereElementIsNotElementType()
                elements.extend(collector.ToElements())
        else:
            # Process all relevant categories
            categories = self.get_relevant_categories()
            for category in categories:
                try:
                    collector = FilteredElementCollector(self.doc)\
                        .OfCategory(category.Id)\
                        .WhereElementIsNotElementType()
                    elements.extend(collector.ToElements())
                except:
                    continue
        
        return elements

def main():
    """Main function to run the price table import"""
    importer = PriceTableImporter()
    
    # Get Excel file path
    excel_path = forms.pick_file(file_ext='xlsx', 
                                title="انتخاب فایل فهرست بهای 1404",
                                multi_file=False)
    
    if not excel_path:
        forms.alert("فایل انتخاب نشد!")
        return
    
    # Load price data from Excel
    importer.output.print_md("# واردات فهرست بهای 1404")
    importer.output.print_md(f"**فایل انتخاب شده**: {os.path.basename(excel_path)}")
    
    price_data = importer.load_excel_data(excel_path)
    
    if not price_data:
