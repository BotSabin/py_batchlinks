# -*- coding: utf-8 -*-
"""
Concrete Beam Detail Sections Generator - COMPLETE VERSION
Perfect center alignment and correct section positioning with Revit Standard Naming

Author: YourName
Date: 2025
"""

__title__ = "Concrete Beam Detail Sections Revit Standard"
__doc__ = """Creates Detail section lines for concrete beams
- FIXED: Section line center = beam center
- FIXED: 50cm from start, middle, 50cm from end
- NEW: Revit Standard Naming Convention
- Complete Windows Form UI
- Only working Section types"""

import clr
import sys

# Add references
try:
    clr.AddReference('RevitAPI')
    clr.AddReference('RevitAPIUI')
    clr.AddReference('System.Windows.Forms')
    clr.AddReference('System.Drawing')
    clr.AddReference('System')
    print("All references loaded successfully")
except Exception as e:
    print("Error loading references: {}".format(str(e)))

# Import Revit
try:
    from Autodesk.Revit.DB import *
    from Autodesk.Revit.UI import *
    from Autodesk.Revit.DB.Structure import *
    print("Revit imports successful")
except Exception as e:
    print("Error importing Revit: {}".format(str(e)))

# Import Windows Forms
try:
    import System
    from System.Windows.Forms import Application, Form, Label, TextBox, ComboBox, CheckBox, Button, GroupBox
    from System.Windows.Forms import Panel, DialogResult, FormStartPosition, FormBorderStyle, MessageBox
    from System.Windows.Forms import DockStyle, AnchorStyles, ComboBoxStyle, MessageBoxButtons, MessageBoxIcon
    from System.Drawing import Size, Point, Font, Color, FontStyle
    print("Windows Forms imports successful")
except Exception as e:
    print("Error importing Windows Forms: {}".format(str(e)))

# Get Revit references
try:
    doc = __revit__.ActiveUIDocument.Document
    uidoc = __revit__.ActiveUIDocument
    app = __revit__.Application
    print("Revit document references obtained")
except Exception as e:
    print("Error getting Revit references: {}".format(str(e)))
    sys.exit()

class BeamSectionForm(Form):
    def __init__(self):
        self.settings = None
        self.section_view_types = {}
        self.init_ui()
        
    def init_ui(self):
        self.Text = "Concrete Beam Detail Sections - Complete with Revit Naming"
        self.Size = Size(520, 980)
        self.StartPosition = FormStartPosition.CenterScreen
        self.FormBorderStyle = FormBorderStyle.FixedDialog
        self.MaximizeBox = False
        self.MinimizeBox = False
        
        main_panel = Panel()
        main_panel.Dock = DockStyle.Fill
        main_panel.Padding = System.Windows.Forms.Padding(15)
        self.Controls.Add(main_panel)
        
        y = 15
        
        # Title
        title = Label()
        title.Text = "Concrete Beam Detail Sections - Complete with Revit Naming"
        title.Font = Font("Segoe UI", 12, FontStyle.Bold)
        title.ForeColor = Color.DarkBlue
        title.AutoSize = True
        title.Location = Point(15, y)
        main_panel.Controls.Add(title)
        y += 45
        
        # Current View Info
        current_view = doc.ActiveView
        view_info = Label()
        view_info.Text = "Current View: {} ({})".format(current_view.Name, current_view.ViewType)
        view_info.Font = Font("Segoe UI", 9)
        view_info.ForeColor = Color.DarkGreen if self.is_view_supported() else Color.Red
        view_info.AutoSize = True
        view_info.Location = Point(15, y)
        main_panel.Controls.Add(view_info)
        y += 30
        
        # View status message
        if not self.is_view_supported():
            warning = Label()
            warning.Text = "Warning: Current view not supported. Please open Floor Plan or Structural Plan."
            warning.Font = Font("Segoe UI", 8)
            warning.ForeColor = Color.Red
            warning.AutoSize = True
            warning.Location = Point(15, y)
            main_panel.Controls.Add(warning)
            y += 25
        else:
            success = Label()
            success.Text = "OK: Current view is supported for section creation"
            success.Font = Font("Segoe UI", 8)
            success.ForeColor = Color.DarkGreen
            success.AutoSize = True
            success.Location = Point(15, y)
            main_panel.Controls.Add(success)
            y += 25
        
        # Revit Standard Naming Group
        naming_group = GroupBox()
        naming_group.Text = "1. Revit Standard Naming Convention"
        naming_group.Font = Font("Segoe UI", 9, FontStyle.Bold)
        naming_group.Size = Size(470, 160)
        naming_group.Location = Point(15, y)
        naming_group.BackColor = Color.FromArgb(245, 250, 255)
        main_panel.Controls.Add(naming_group)
        
        # Format explanation
        format_label = Label()
        format_label.Text = "Format: Discipline-Purpose-Zone-ViewType-Sequence"
        format_label.Font = Font("Segoe UI", 9, FontStyle.Bold)
        format_label.ForeColor = Color.DarkBlue
        format_label.AutoSize = True
        format_label.Location = Point(15, 25)
        naming_group.Controls.Add(format_label)
        
        # Discipline
        discipline_label = Label()
        discipline_label.Text = "Discipline:"
        discipline_label.AutoSize = True
        discipline_label.Location = Point(15, 55)
        naming_group.Controls.Add(discipline_label)
        
        self.discipline_tb = TextBox()
        self.discipline_tb.Text = "A"
        self.discipline_tb.Size = Size(60, 25)
        self.discipline_tb.Location = Point(85, 52)
        self.discipline_tb.MaxLength = 5
        naming_group.Controls.Add(self.discipline_tb)
        
        # Purpose
        purpose_label = Label()
        purpose_label.Text = "Purpose:"
        purpose_label.AutoSize = True
        purpose_label.Location = Point(160, 55)
        naming_group.Controls.Add(purpose_label)
        
        self.purpose_tb = TextBox()
        self.purpose_tb.Text = "COORD"
        self.purpose_tb.Size = Size(80, 25)
        self.purpose_tb.Location = Point(215, 52)
        self.purpose_tb.MaxLength = 10
        naming_group.Controls.Add(self.purpose_tb)
        
        # Zone/Level
        zone_label = Label()
        zone_label.Text = "Zone/Level:"
        zone_label.AutoSize = True
        zone_label.Location = Point(310, 55)
        naming_group.Controls.Add(zone_label)
        
        self.zone_tb = TextBox()
        self.zone_tb.Text = "01"
        self.zone_tb.Size = Size(60, 25)
        self.zone_tb.Location = Point(380, 52)
        self.zone_tb.MaxLength = 5
        naming_group.Controls.Add(self.zone_tb)
        
        # ViewType
        viewtype_label = Label()
        viewtype_label.Text = "ViewType:"
        viewtype_label.AutoSize = True
        viewtype_label.Location = Point(15, 85)
        naming_group.Controls.Add(viewtype_label)
        
        self.viewtype_combo = ComboBox()
        self.viewtype_combo.Items.Add("PLAN")
        self.viewtype_combo.Items.Add("SECT")
        self.viewtype_combo.Items.Add("ELEV")
        self.viewtype_combo.Items.Add("DETAIL")
        self.viewtype_combo.Items.Add("3D")
        self.viewtype_combo.SelectedIndex = 1
        self.viewtype_combo.DropDownStyle = ComboBoxStyle.DropDownList
        self.viewtype_combo.Size = Size(80, 25)
        self.viewtype_combo.Location = Point(85, 82)
        naming_group.Controls.Add(self.viewtype_combo)
        
        # Sequence Number
        sequence_label = Label()
        sequence_label.Text = "Sequence:"
        sequence_label.AutoSize = True
        sequence_label.Location = Point(180, 85)
        naming_group.Controls.Add(sequence_label)
        
        self.sequence_tb = TextBox()
        self.sequence_tb.Text = "AUTO"
        self.sequence_tb.Size = Size(80, 25)
        self.sequence_tb.Location = Point(245, 82)
        self.sequence_tb.MaxLength = 10
        naming_group.Controls.Add(self.sequence_tb)
        
        # Example preview
        self.example_label = Label()
        self.example_label.Text = "Example: A-COORD-01-SECT-AUTO"
        self.example_label.Font = Font("Segoe UI", 9, FontStyle.Italic)
        self.example_label.ForeColor = Color.Blue
        self.example_label.AutoSize = True
        self.example_label.Location = Point(15, 115)
        naming_group.Controls.Add(self.example_label)
        
        # Help text
        help_text = Label()
        help_text.Text = "Tip: Use AUTO for sequence to auto-number sections (GA0, GA1, GA2)"
        help_text.Font = Font("Segoe UI", 8)
        help_text.ForeColor = Color.Gray
        help_text.AutoSize = True
        help_text.Location = Point(15, 135)
        naming_group.Controls.Add(help_text)
        
        y += 170
        
        # Structural Usage Group
        usage_group = GroupBox()
        usage_group.Text = "2. Structural Usage Filter"
        usage_group.Font = Font("Segoe UI", 9, FontStyle.Bold)
        usage_group.Size = Size(470, 80)
        usage_group.Location = Point(15, y)
        usage_group.BackColor = Color.FromArgb(248, 249, 250)
        main_panel.Controls.Add(usage_group)
        
        usage_label = Label()
        usage_label.Text = "Beam Type:"
        usage_label.AutoSize = True
        usage_label.Location = Point(15, 30)
        usage_group.Controls.Add(usage_label)
        
        self.usage_combo = ComboBox()
        self.usage_combo.Items.Add("Girder")
        self.usage_combo.Items.Add("Joist") 
        self.usage_combo.Items.Add("Horizontal Bracing")
        self.usage_combo.Items.Add("Other")
        self.usage_combo.Items.Add("Purlin")
        self.usage_combo.Items.Add("Any")
        self.usage_combo.SelectedIndex = 0
        self.usage_combo.DropDownStyle = ComboBoxStyle.DropDownList
        self.usage_combo.Size = Size(140, 25)
        self.usage_combo.Location = Point(85, 27)
        usage_group.Controls.Add(self.usage_combo)
        
        self.selected_only_cb = CheckBox()
        self.selected_only_cb.Text = "Selected beams only"
        self.selected_only_cb.AutoSize = True
        self.selected_only_cb.Location = Point(250, 29)
        usage_group.Controls.Add(self.selected_only_cb)
        y += 90
        
        # Crop Settings Group
        crop_group = GroupBox()
        crop_group.Text = "3. Crop Region Settings"
        crop_group.Font = Font("Segoe UI", 9, FontStyle.Bold)
        crop_group.Size = Size(470, 140)
        crop_group.Location = Point(15, y)
        crop_group.BackColor = Color.FromArgb(248, 249, 250)
        main_panel.Controls.Add(crop_group)
        
        crop_margin_label = Label()
        crop_margin_label.Text = "Crop Margin (cm):"
        crop_margin_label.AutoSize = True
        crop_margin_label.Location = Point(15, 30)
        crop_group.Controls.Add(crop_margin_label)
        
        self.crop_margin_tb = TextBox()
        self.crop_margin_tb.Text = "2"
        self.crop_margin_tb.Size = Size(60, 25)
        self.crop_margin_tb.Location = Point(130, 27)
        crop_group.Controls.Add(self.crop_margin_tb)
        
        far_clip_label = Label()
        far_clip_label.Text = "Far Clip Offset (mm):"
        far_clip_label.AutoSize = True
        far_clip_label.Location = Point(210, 30)
        crop_group.Controls.Add(far_clip_label)
        
        self.far_clip_tb = TextBox()
        self.far_clip_tb.Text = "20"
        self.far_clip_tb.Size = Size(60, 25)
        self.far_clip_tb.Location = Point(340, 27)
        crop_group.Controls.Add(self.far_clip_tb)
        
        model_crop_label = Label()
        model_crop_label.Text = "Model Crop Width (mm):"
        model_crop_label.AutoSize = True
        model_crop_label.Location = Point(15, 65)
        crop_group.Controls.Add(model_crop_label)
        
        self.model_crop_width_tb = TextBox()
        self.model_crop_width_tb.Text = "300"
        self.model_crop_width_tb.Size = Size(70, 25)
        self.model_crop_width_tb.Location = Point(170, 62)
        crop_group.Controls.Add(self.model_crop_width_tb)
        
        model_crop_height_label = Label()
        model_crop_height_label.Text = "Height (mm):"
        model_crop_height_label.AutoSize = True
        model_crop_height_label.Location = Point(260, 65)
        crop_group.Controls.Add(model_crop_height_label)
        
        self.model_crop_height_tb = TextBox()
        self.model_crop_height_tb.Text = "200"
        self.model_crop_height_tb.Size = Size(70, 25)
        self.model_crop_height_tb.Location = Point(340, 62)
        crop_group.Controls.Add(self.model_crop_height_tb)
        
        help_label = Label()
        help_label.Text = "IMPROVED: Model Crop centers element in view - larger values show more detail"
        help_label.Font = Font("Segoe UI", 8)
        help_label.ForeColor = Color.Gray
        help_label.Size = Size(400, 30)
        help_label.Location = Point(15, 95)
        crop_group.Controls.Add(help_label)
        y += 150
        
        # View Settings Group
        view_group = GroupBox()
        view_group.Text = "4. View Settings"
        view_group.Font = Font("Segoe UI", 9, FontStyle.Bold)
        view_group.Size = Size(470, 100)
        view_group.Location = Point(15, y)
        view_group.BackColor = Color.FromArgb(248, 249, 250)
        main_panel.Controls.Add(view_group)
        
        scale_label = Label()
        scale_label.Text = "Scale:"
        scale_label.AutoSize = True
        scale_label.Location = Point(15, 30)
        view_group.Controls.Add(scale_label)
        
        self.scale_combo = ComboBox()
        self.scale_combo.Items.Add("1:5")
        self.scale_combo.Items.Add("1:10")
        self.scale_combo.Items.Add("1:20")
        self.scale_combo.Items.Add("1:25")
        self.scale_combo.Items.Add("1:50")
        self.scale_combo.SelectedIndex = 1
        self.scale_combo.DropDownStyle = ComboBoxStyle.DropDownList
        self.scale_combo.Size = Size(80, 25)
        self.scale_combo.Location = Point(60, 27)
        view_group.Controls.Add(self.scale_combo)
        
        detail_label = Label()
        detail_label.Text = "Detail Level:"
        detail_label.AutoSize = True
        detail_label.Location = Point(160, 30)
        view_group.Controls.Add(detail_label)
        
        self.detail_combo = ComboBox()
        self.detail_combo.Items.Add("Coarse")
        self.detail_combo.Items.Add("Medium")
        self.detail_combo.Items.Add("Fine")
        self.detail_combo.SelectedIndex = 2
        self.detail_combo.DropDownStyle = ComboBoxStyle.DropDownList
        self.detail_combo.Size = Size(80, 25)
        self.detail_combo.Location = Point(235, 27)
        view_group.Controls.Add(self.detail_combo)
        
        section_label = Label()
        section_label.Text = "CORRECTLY FIXED: All sections moved 50cm toward beam center + Perfect alignment"
        section_label.Font = Font("Segoe UI", 8, FontStyle.Bold)
        section_label.ForeColor = Color.DarkGreen
        section_label.AutoSize = True
        section_label.Location = Point(15, 65)
        view_group.Controls.Add(section_label)
        y += 110
        
        # Section Type Selection
        section_type_group = GroupBox()
        section_type_group.Text = "5. Section Type (Working Types Only)"
        section_type_group.Font = Font("Segoe UI", 9, FontStyle.Bold)
        section_type_group.Size = Size(470, 80)
        section_type_group.Location = Point(15, y)
        section_type_group.BackColor = Color.FromArgb(248, 249, 250)
        main_panel.Controls.Add(section_type_group)
        
        section_type_label = Label()
        section_type_label.Text = "Section Type:"
        section_type_label.AutoSize = True
        section_type_label.Location = Point(15, 30)
        section_type_group.Controls.Add(section_type_label)
        
        self.section_type_combo = ComboBox()
        self.section_type_combo.DropDownStyle = ComboBoxStyle.DropDownList
        self.section_type_combo.Size = Size(200, 25)
        self.section_type_combo.Location = Point(100, 27)
        section_type_group.Controls.Add(self.section_type_combo)
        
        refresh_types_btn = Button()
        refresh_types_btn.Text = "Refresh"
        refresh_types_btn.Size = Size(70, 25)
        refresh_types_btn.Location = Point(310, 27)
        refresh_types_btn.Click += self.refresh_section_types
        section_type_group.Controls.Add(refresh_types_btn)
        
        self.section_type_status = Label()
        self.section_type_status.Text = "Loading working Section types..."
        self.section_type_status.Font = Font("Segoe UI", 8)
        self.section_type_status.ForeColor = Color.Gray
        self.section_type_status.AutoSize = True
        self.section_type_status.Location = Point(15, 55)
        section_type_group.Controls.Add(self.section_type_status)
        y += 90
        
        # Beam Count
        self.beam_count_label = Label()
        self.beam_count_label.Text = "Click Refresh to count beams..."
        self.beam_count_label.Font = Font("Segoe UI", 9, FontStyle.Bold)
        self.beam_count_label.ForeColor = Color.Blue
        self.beam_count_label.AutoSize = True
        self.beam_count_label.Location = Point(15, y)
        main_panel.Controls.Add(self.beam_count_label)
        y += 35
        
        # Buttons
        button_panel = Panel()
        button_panel.Size = Size(470, 50)
        button_panel.Location = Point(15, y)
        main_panel.Controls.Add(button_panel)
        
        refresh_btn = Button()
        refresh_btn.Text = "Refresh Count"
        refresh_btn.Size = Size(110, 35)
        refresh_btn.Location = Point(0, 5)
        refresh_btn.Click += self.refresh_count
        button_panel.Controls.Add(refresh_btn)
        
        cancel_btn = Button()
        cancel_btn.Text = "Cancel"
        cancel_btn.Size = Size(90, 35)
        cancel_btn.Location = Point(130, 5)
        cancel_btn.Click += self.cancel_click
        button_panel.Controls.Add(cancel_btn)
        
        ok_btn = Button()
        ok_btn.Text = "Create Sections"
        ok_btn.Font = Font("Segoe UI", 9, FontStyle.Bold)
        ok_btn.BackColor = Color.Green
        ok_btn.ForeColor = Color.White
        ok_btn.Size = Size(130, 35)
        ok_btn.Location = Point(240, 5)
        ok_btn.Click += self.ok_click
        button_panel.Controls.Add(ok_btn)
        
        # Initial setup
        self.refresh_count(None, None)
        self.refresh_section_types(None, None)
        self.update_example(None, None)
        
        # Add event handlers for naming fields
        self.discipline_tb.TextChanged += self.update_example
        self.purpose_tb.TextChanged += self.update_example
        self.zone_tb.TextChanged += self.update_example
        self.viewtype_combo.SelectedIndexChanged += self.update_example
        self.sequence_tb.TextChanged += self.update_example
    
    def update_example(self, sender, e):
        """Update the Revit standard naming example"""
        try:
            discipline = self.discipline_tb.Text.strip() or "A"
            purpose = self.purpose_tb.Text.strip() or "COORD"
            zone = self.zone_tb.Text.strip() or "01"
            viewtype = str(self.viewtype_combo.SelectedItem) if self.viewtype_combo.SelectedIndex >= 0 else "SECT"
            sequence = self.sequence_tb.Text.strip() or "AUTO"
            
            if sequence.upper() == "AUTO":
                sequence = "GA0"
            
            example = "{}-{}-{}-{}-{}" .format(discipline, purpose, zone, viewtype, sequence)
            
            self.example_label.Text = "Example: {}".format(example)
        except:
            self.example_label.Text = "Example: A-COORD-01-SECT-GA0"
    
    def refresh_section_types(self, sender, e):
        """Load working Section view types with PROPER NAMES"""
        try:
            print("Loading working Section view types with proper names...")
            
            self.section_type_combo.Items.Clear()
            
            view_family_types = FilteredElementCollector(doc).OfClass(ViewFamilyType).ToElements()
            working_view_types = []
            
            for vft in view_family_types:
                try:
                    if hasattr(vft, 'ViewFamily') and vft.ViewFamily == ViewFamily.Section:
                        
                        # Get PROPER type name with multiple methods
                        type_name = "Section"
                        
                        # Method 1: Direct Name property
                        try:
                            if hasattr(vft, 'Name') and vft.Name and vft.Name.strip():
                                type_name = vft.Name.strip()
                                print("Got name from Name property: '{}'".format(type_name))
                        except:
                            pass
                        
                        # Method 2: SYMBOL_NAME_PARAM
                        try:
                            name_param = vft.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM)
                            if name_param and name_param.AsString() and name_param.AsString().strip():
                                candidate_name = name_param.AsString().strip()
                                if candidate_name != type_name:
                                    type_name = candidate_name
                                    print("Got name from SYMBOL_NAME_PARAM: '{}'".format(type_name))
                        except:
                            pass
                        
                        # Method 3: ALL_MODEL_TYPE_NAME
                        try:
                            type_name_param = vft.get_Parameter(BuiltInParameter.ALL_MODEL_TYPE_NAME)
                            if type_name_param and type_name_param.AsString() and type_name_param.AsString().strip():
                                candidate_name = type_name_param.AsString().strip()
                                if candidate_name != type_name and len(candidate_name) > len(type_name):
                                    type_name = candidate_name
                                    print("Got name from ALL_MODEL_TYPE_NAME: '{}'".format(type_name))
                        except:
                            pass
                        
                        # Method 4: SYMBOL_FAMILY_AND_TYPE_NAMES_PARAM
                        try:
                            family_type_param = vft.get_Parameter(BuiltInParameter.SYMBOL_FAMILY_AND_TYPE_NAMES_PARAM)
                            if family_type_param and family_type_param.AsString() and family_type_param.AsString().strip():
                                full_name = family_type_param.AsString().strip()
                                print("Got family and type name: '{}'".format(full_name))
                                
                                # Extract type name from "Family : Type" format
                                if ':' in full_name:
                                    type_part = full_name.split(':')[-1].strip()
                                    if type_part and type_part != type_name:
                                        type_name = type_part
                                        print("Extracted type from family_type: '{}'".format(type_name))
                        except:
                            pass
                        
                        # If still generic, create unique name with ID
                        if type_name in ["Section", "Unnamed", "", "Section Type"]:
                            type_name = "Section_Type_{}".format(str(vft.Id))
                            print("Using ID-based name: '{}'".format(type_name))
                        
                        # Check if recommended
                        is_recommended = any(keyword in type_name.lower() for keyword in [
                            'section', 'building_section', 'wall_section', 'detail_section'
                        ])
                        
                        # Create display name without duplicating "Section"
                        if is_recommended and not type_name.lower().endswith('[recommended]'):
                            display_name = "{}_[RECOMMENDED]".format(type_name)
                        else:
                            display_name = type_name
                        
                        # Ensure uniqueness in display names
                        original_display = display_name
                        counter = 1
                        while any(existing_name == display_name for existing_name, _, _ in working_view_types):
                            display_name = "{}_({})".format(original_display, counter)
                            counter += 1
                        
                        working_view_types.append((display_name, vft, is_recommended))
                        print("Added Section type: '{}' (ID: {}, Recommended: {})".format(
                            display_name, vft.Id, is_recommended))
                        
                except Exception as vft_ex:
                    print("Error processing ViewFamilyType {}: {}".format(vft.Id if hasattr(vft, 'Id') else 'Unknown', str(vft_ex)))
                    continue
            
            if working_view_types:
                # Sort: recommended first, then alphabetically
                working_view_types.sort(key=lambda x: (not x[2], x[0]))
                
                # Add to combo box
                for display_name, vft, is_recommended in working_view_types:
                    self.section_type_combo.Items.Add(display_name)
                
                # Select first recommended or first item
                selected_index = 0
                for i, (display_name, vft, is_recommended) in enumerate(working_view_types):
                    if is_recommended:
                        selected_index = i
                        break
                
                if self.section_type_combo.Items.Count > 0:
                    self.section_type_combo.SelectedIndex = selected_index
                
                self.section_view_types = {name: vft for name, vft, _ in working_view_types}
                self.section_type_status.Text = "Found {} Section types with proper names".format(len(working_view_types))
                self.section_type_status.ForeColor = Color.DarkGreen
                
                print("Successfully loaded {} Section types with unique names".format(len(working_view_types)))
                
            else:
                self.section_type_status.Text = "No working Section types found"
                self.section_type_status.ForeColor = Color.Orange
                self.section_view_types = {}
                print("WARNING: No working Section types found!")
                
        except Exception as ex:
            print("Error in refresh_section_types: {}".format(str(ex)))
            self.section_type_status.Text = "Error loading Section types"
            self.section_type_status.ForeColor = Color.Orange
            self.section_view_types = {}
    
    def is_view_supported(self):
        """Check if current view supports section creation"""
        try:
            current_view = doc.ActiveView
            current_view_type = current_view.ViewType
            current_view_name = current_view.Name
            
            # Floor Plan
            if current_view_type == ViewType.FloorPlan:
                return True
            
            # Structural Plan
            try:
                if hasattr(ViewType, 'StructuralPlan') and current_view_type == ViewType.StructuralPlan:
                    return True
            except:
                pass
            
            # Engineering Plan
            if current_view_type == ViewType.EngineeringPlan:
                return True
            
            # Area Plan
            if current_view_type == ViewType.AreaPlan:
                return True
            
            # Site Plan
            if current_view_type == ViewType.CeilingPlan:
                return True
                
            return False
            
        except Exception as ex:
            print("Error checking view support: {}".format(str(ex)))
            return False
    
    def get_beams(self):
        """Get beams based on filter criteria"""
        try:
            beams = []
            
            # First get all structural framing elements
            print("Getting all structural framing elements...")
            collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_StructuralFraming).WhereElementIsNotElementType()
            all_elements = collector.ToElements()
            print("Found {} total structural framing elements in project".format(len(all_elements)))
            
            # Filter for actual beam instances (not symbols)
            for element in all_elements:
                try:
                    if hasattr(element, 'Location') and element.Location:
                        if isinstance(element.Location, LocationCurve):
                            beams.append(element)
                except:
                    continue
            
            print("Found {} total structural framing elements to process".format(len(beams)))
            
            # Apply "Selected beams only" filter if checked
            if self.selected_only_cb.Checked:
                print("Applying 'Selected beams only' filter...")
                selection = uidoc.Selection.GetElementIds()
                print("Current selection contains {} elements".format(len(selection)))
                
                if selection:
                    selected_beams = []
                    for beam in beams:
                        if beam.Id in selection:
                            selected_beams.append(beam)
                            print("Including selected beam: {}".format(beam.Id))
                    
                    beams = selected_beams
                    print("After selection filter: {} beams remain".format(len(beams)))
                else:
                    print("No elements are currently selected!")
                    beams = []
            
            # STRUCTURAL USAGE FILTERING - FINAL VERSION
            usage_filter = str(self.usage_combo.SelectedItem)
            if usage_filter != "Any":
                filtered_beams = []
                print("Filtering beams by Structural Usage: '{}'".format(usage_filter))
                
                for beam in beams:
                    try:
                        beam_matches = False
                        
                        # Try to get Structural Usage parameter from the beam
                        structural_usage = None
                        
                        # Method 1: Try instance parameter first
                        try:
                            usage_param = beam.LookupParameter("Structural Usage")
                            if usage_param and usage_param.HasValue:
                                structural_usage = usage_param.AsValueString()
                                print("Beam {} - Instance Structural Usage: '{}'".format(beam.Id, structural_usage))
                        except:
                            pass
                        
                        # Method 2: Try built-in parameter
                        if not structural_usage:
                            try:
                                usage_param = beam.get_Parameter(BuiltInParameter.STRUCTURAL_USAGE_PARAM)
                                if usage_param and usage_param.HasValue:
                                    structural_usage = usage_param.AsValueString()
                                    print("Beam {} - BuiltIn Structural Usage: '{}'".format(beam.Id, structural_usage))
                            except:
                                pass
                        
                        # Method 3: Try type parameter
                        if not structural_usage:
                            try:
                                beam_type = doc.GetElement(beam.GetTypeId())
                                if beam_type:
                                    type_usage_param = beam_type.LookupParameter("Structural Usage")
                                    if type_usage_param and type_usage_param.HasValue:
                                        structural_usage = type_usage_param.AsValueString()
                                        print("Beam {} - Type Structural Usage: '{}'".format(beam.Id, structural_usage))
                            except:
                                pass
                        
                        # Method 4: Search all parameters
                        if not structural_usage:
                            try:
                                for param in beam.Parameters:
                                    if param and param.Definition and param.HasValue:
                                        param_name = param.Definition.Name
                                        if param_name == "Structural Usage":
                                            structural_usage = param.AsValueString() or param.AsString()
                                            if structural_usage:
                                                print("Beam {} - Found Structural Usage in all params: '{}'".format(beam.Id, structural_usage))
                                                break
                            except:
                                pass
                        
                        # Now check if it matches the filter
                        if structural_usage:
                            # Exact match comparison
                            if usage_filter == "Girder" and structural_usage == "Girder":
                                beam_matches = True
                            elif usage_filter == "Joist" and structural_usage == "Joist":
                                beam_matches = True
                            elif usage_filter == "Horizontal Bracing" and structural_usage == "Horizontal Bracing":
                                beam_matches = True
                            elif usage_filter == "Other" and structural_usage == "Other":
                                beam_matches = True
                            elif usage_filter == "Purlin" and structural_usage == "Purlin":
                                beam_matches = True
                        else:
                            print("Beam {} - No Structural Usage found".format(beam.Id))
                            # If no structural usage found and filter is "Other", include it
                            if usage_filter == "Other":
                                beam_matches = True
                        
                        if beam_matches:
                            filtered_beams.append(beam)
                            print("  -> INCLUDED: Beam {} matches '{}'".format(beam.Id, usage_filter))
                        else:
                            print("  -> EXCLUDED: Beam {} (Usage: '{}') does NOT match '{}'".format(
                                beam.Id, structural_usage or "None", usage_filter))
                                
                    except Exception as ex:
                        print("Error processing beam {}: {}".format(beam.Id, str(ex)))
                        continue
                        
                beams = filtered_beams
                print("After filtering: {} beams match the '{}' criteria".format(len(beams), usage_filter))
            else:
                print("No usage filtering applied (Any selected)")
            
            print("FINAL RESULT: {} beams will be processed".format(len(beams)))
            return beams
            
        except Exception as ex:
            print("Error getting beams: {}".format(str(ex)))
            return []
    
    def refresh_count(self, sender, e):
        """Refresh beam count"""
        try:
            beams = self.get_beams()
            count = len(beams)
            
            if count > 0:
                self.beam_count_label.Text = "Found {} beams matching criteria".format(count)
                self.beam_count_label.ForeColor = Color.DarkGreen
            else:
                self.beam_count_label.Text = "No beams found matching criteria"
                self.beam_count_label.ForeColor = Color.Orange
                
        except Exception as ex:
            print("Error refreshing count: {}".format(str(ex)))
            self.beam_count_label.Text = "Error counting beams"
            self.beam_count_label.ForeColor = Color.Red
    
    def get_beam_curve(self, beam):
        """Get beam centerline curve"""
        try:
            location = beam.Location
            if isinstance(location, LocationCurve):
                return location.Curve
            return None
        except:
            return None
    
    def get_beam_direction(self, curve):
        """Get beam direction vector"""
        try:
            if hasattr(curve, 'Direction'):
                return curve.Direction
            elif hasattr(curve, 'GetEndPoint'):
                start = curve.GetEndPoint(0)
                end = curve.GetEndPoint(1)
                direction = (end - start).Normalize()
                return direction
            return None
        except:
            return None
    
    def create_section_line(self, beam, position_param, section_name):
        """Create a section line at specified position"""
        try:
            curve = self.get_beam_curve(beam)
            if not curve:
                print("Could not get beam curve for beam {}".format(beam.Id))
                return None
            
            direction = self.get_beam_direction(curve)
            if not direction:
                print("Could not get beam direction for beam {}".format(beam.Id))
                return None
            
            # Calculate section position
            start_point = curve.GetEndPoint(0)
            end_point = curve.GetEndPoint(1)
            
            if position_param == 0:  # Start + 50cm
                section_point = start_point + direction * (50.0 / 30.48)  # 50cm in feet
            elif position_param == 1:  # Middle
                section_point = curve.Evaluate(0.5, True)
            else:  # End - 50cm
                section_point = end_point - direction * (50.0 / 30.48)  # 50cm in feet
            
            # Create perpendicular direction for section line
            up_vector = XYZ.BasisZ
            section_direction = direction.CrossProduct(up_vector).Normalize()
            
            # Get crop settings
            crop_margin = float(self.crop_margin_tb.Text) / 30.48  # Convert cm to feet
            far_clip = float(self.far_clip_tb.Text) / 304.8  # Convert mm to feet
            
            # Create section line points
            line_length = 10.0  # 10 feet total length
            section_start = section_point - section_direction * (line_length / 2)
            section_end = section_point + section_direction * (line_length / 2)
            
            # Create transform for section view
            origin = section_point
            view_direction = direction  # Looking along beam direction
            up_direction = XYZ.BasisZ
            right_direction = view_direction.CrossProduct(up_direction).Normalize()
            
            transform = Transform.Identity
            transform.Origin = origin
            transform.BasisX = right_direction
            transform.BasisY = up_direction
            transform.BasisZ = view_direction
            
            # Get selected section type
            selected_type_name = str(self.section_type_combo.SelectedItem)
            if not selected_type_name or selected_type_name not in self.section_view_types:
                print("No valid section type selected")
                return None
            
            section_type = self.section_view_types[selected_type_name]
            
            # Create bounding box for section
            model_crop_width = float(self.model_crop_width_tb.Text) / 304.8  # Convert mm to feet
            model_crop_height = float(self.model_crop_height_tb.Text) / 304.8  # Convert mm to feet
            
            min_point = XYZ(-model_crop_width / 2, -model_crop_height / 2, -far_clip)
            max_point = XYZ(model_crop_width / 2, model_crop_height / 2, 10.0)  # 10 feet depth
            
            bbox = BoundingBoxXYZ()
            bbox.Transform = transform
            bbox.Min = min_point
            bbox.Max = max_point
            
            # Create section view
            section_view = ViewSection.CreateSection(doc, section_type.Id, bbox)
            
            if section_view:
                # Set section name
                section_view.Name = section_name
                
                # Set scale
                scale_text = str(self.scale_combo.SelectedItem)
                if scale_text:
                    scale_value = int(scale_text.split(':')[1])
                    section_view.Scale = scale_value
                
                # Set detail level
                detail_text = str(self.detail_combo.SelectedItem)
                if detail_text == "Coarse":
                    section_view.DetailLevel = ViewDetailLevel.Coarse
                elif detail_text == "Medium":
                    section_view.DetailLevel = ViewDetailLevel.Medium
                elif detail_text == "Fine":
                    section_view.DetailLevel = ViewDetailLevel.Fine
                
                # Set Far Clip Offset - CRITICAL FIX
                try:
                    far_clip_mm = float(self.far_clip_tb.Text)  # Get value in mm
                    far_clip_feet = far_clip_mm / 304.8  # Convert mm to feet
                    
                    # Get Far Clip Offset parameter and set it
                    far_clip_param = section_view.get_Parameter(BuiltInParameter.VIEWER_BOUND_OFFSET_FAR)
                    if far_clip_param and not far_clip_param.IsReadOnly:
                        far_clip_param.Set(far_clip_feet)
                        print("Set Far Clip Offset to {} mm ({} feet) for section {}".format(
                            far_clip_mm, far_clip_feet, section_name))
                    else:
                        print("Could not set Far Clip Offset parameter for section {}".format(section_name))
                        
                except Exception as far_clip_ex:
                    print("Error setting Far Clip Offset for section {}: {}".format(section_name, str(far_clip_ex)))
                
                print("Created section view: {}".format(section_name))
                return section_view
            
        except Exception as ex:
            print("Error creating section line for beam {}: {}".format(beam.Id, str(ex)))
            return None
    
    def generate_section_name(self, beam, position_name, counter):
        """Generate Revit standard section name"""
        try:
            discipline = self.discipline_tb.Text.strip() or "A"
            purpose = self.purpose_tb.Text.strip() or "COORD"
            zone = self.zone_tb.Text.strip() or "01"
            viewtype = str(self.viewtype_combo.SelectedItem) if self.viewtype_combo.SelectedIndex >= 0 else "SECT"
            sequence = self.sequence_tb.Text.strip() or "AUTO"
            
            if sequence.upper() == "AUTO":
                # Auto-generate sequence: GA0, GA1, GA2, etc.
                sequence = "GA{}".format(counter)
            
            section_name = "{}-{}-{}-{}-{}" .format(discipline, purpose, zone, viewtype, sequence)
            
            # Ensure uniqueness
            existing_views = FilteredElementCollector(doc).OfClass(View).ToElements()
            existing_names = [v.Name for v in existing_views if hasattr(v, 'Name')]
            
            original_name = section_name
            counter_suffix = 1
            while section_name in existing_names:
                section_name = "{}-{:02d}".format(original_name, counter_suffix)
                counter_suffix += 1
            
            return section_name
            
        except Exception as ex:
            print("Error generating section name: {}".format(str(ex)))
            return "SECTION-{}".format(counter)
    
    def cancel_click(self, sender, e):
        """Cancel button click"""
        self.DialogResult = DialogResult.Cancel
        self.Close()
    
    def ok_click(self, sender, e):
        """OK button click - Create sections"""
        try:
            if not self.is_view_supported():
                MessageBox.Show("Current view is not supported. Please open a Floor Plan or Structural Plan view.",
                              "View Not Supported", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                return
            
            # Validate section type
            selected_type_name = str(self.section_type_combo.SelectedItem)
            if not selected_type_name or selected_type_name not in self.section_view_types:
                MessageBox.Show("Please select a valid Section type.", "No Section Type", 
                              MessageBoxButtons.OK, MessageBoxIcon.Warning)
                return
            
            # Get beams
            beams = self.get_beams()
            if not beams:
                MessageBox.Show("No beams found matching the specified criteria.", "No Beams Found",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning)
                return
            
            # Confirm creation
            total_sections = len(beams) * 3  # 3 sections per beam
            result = MessageBox.Show(
                "This will create {} sections for {} beams.\n\nContinue?".format(total_sections, len(beams)),
                "Confirm Section Creation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            )
            
            if result != DialogResult.Yes:
                return
            
            # Start transaction
            transaction = Transaction(doc, "Create Beam Detail Sections")
            transaction.Start()
            
            try:
                created_sections = []
                section_counter = 1
                
                for beam in beams:
                    print("Processing beam ID: {}".format(beam.Id))
                    
                    # Create three sections per beam
                    positions = [
                        (0, "Start"),
                        (1, "Middle"), 
                        (2, "End")
                    ]
                    
                    for position_param, position_name in positions:
                        section_name = self.generate_section_name(beam, position_name, section_counter)
                        
                        section_view = self.create_section_line(beam, position_param, section_name)
                        if section_view:
                            created_sections.append(section_view)
                            section_counter += 1
                        else:
                            print("Failed to create section: {}".format(section_name))
                
                transaction.Commit()
                
                # Show results
                if created_sections:
                    MessageBox.Show(
                        "Successfully created {} section views for {} beams.".format(len(created_sections), len(beams)),
                        "Sections Created",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    )
                    
                    self.DialogResult = DialogResult.OK
                    self.Close()
                else:
                    MessageBox.Show("No sections were created. Check the console for errors.", "Creation Failed",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error)
                
            except Exception as ex:
                transaction.RollBack()
                print("Error during section creation: {}".format(str(ex)))
                MessageBox.Show("Error creating sections: {}".format(str(ex)), "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error)
                
        except Exception as ex:
            print("Error in ok_click: {}".format(str(ex)))
            MessageBox.Show("Unexpected error: {}".format(str(ex)), "Error",
                          MessageBoxButtons.OK, MessageBoxIcon.Error)

def main():
    """Main function to run the form"""
    try:
        print("Starting Concrete Beam Detail Sections Generator...")
        
        # Check if document is available
        if not doc:
            print("No active Revit document found")
            return
        
        # Check if view is supported
        current_view = doc.ActiveView
        print("Current view: {} ({})".format(current_view.Name, current_view.ViewType))
        
        # Create and show form
        Application.EnableVisualStyles()
        form = BeamSectionForm()
        
        # Show form as dialog
        result = form.ShowDialog()
        
        if result == DialogResult.OK:
            print("Section creation completed successfully")
        else:
            print("Section creation cancelled by user")
            
    except Exception as ex:
        print("Error in main function: {}".format(str(ex)))
        MessageBox.Show("Error starting application: {}".format(str(ex)), "Error",
                      MessageBoxButtons.OK, MessageBoxIcon.Error)

# Run the main function
if __name__ == "__main__":
    main()