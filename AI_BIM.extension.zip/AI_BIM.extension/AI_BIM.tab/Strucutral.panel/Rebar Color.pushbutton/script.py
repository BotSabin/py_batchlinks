# -*- coding: utf-8 -*-
from pyrevit import revit, DB, forms
from collections import defaultdict
import os

doc = revit.doc
uidoc = revit.uidoc
view = uidoc.ActiveView

# Collect Rebars in current view
rebars = DB.FilteredElementCollector(doc, view.Id)\
    .OfCategory(DB.BuiltInCategory.OST_Rebar)\
    .WhereElementIsNotElementType()\
    .ToElements()

if not rebars:
    forms.alert("No Rebar found in the current view.", exitscript=True)

# Allowed parameters for selection
ALLOWED_PARAMS = ["Bar Diameter", "Partition", "Type", "Length", "Style", "Host Category"]

selected_param = forms.SelectFromList.show(
    ALLOWED_PARAMS,
    multiselect=False,
    title="Select Rebar Parameter",
    instruction="Choose one parameter to color Rebars by:"
)

if not selected_param:
    forms.alert("No parameter selected.", exitscript=True)

# Get parameter value from Rebar
def get_param_value(rebar, param_name):
    try:
        if param_name == "Type":
            type_elem = doc.GetElement(rebar.GetTypeId())
            if type_elem:
                type_name = type_elem.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
                family_name = type_elem.get_Parameter(DB.BuiltInParameter.SYMBOL_FAMILY_NAME_PARAM).AsString()
                return "{} : {}".format(family_name, type_name)
            return "No Type"

        elif param_name == "Host Category":
            host_id = rebar.GetHostId()
            if host_id and host_id != DB.ElementId.InvalidElementId:
                host = doc.GetElement(host_id)
                return host.Category.Name if host and host.Category else "No Host"
            return "No Host"

        else:
            # Handle Length with special BuiltInParameter
            if param_name == "Length":
                param = rebar.get_Parameter(DB.BuiltInParameter.REBAR_ELEM_LENGTH)
            else:
                param = rebar.LookupParameter(param_name)

            if param and param.HasValue:
                if param.StorageType == DB.StorageType.Double:
                    val = round(param.AsDouble(), 4)
                    if param_name == "Bar Diameter":
                        return u"Ø{}".format(int(round(val * 304.8)))  # feet to mm
                    elif param_name == "Length":
                        return "L = {}M".format(round(val * 0.3048, 2))  # feet to meter
                    else:
                        return str(val)
                elif param.StorageType == DB.StorageType.Integer:
                    return str(param.AsInteger())
                elif param.StorageType == DB.StorageType.String:
                    return param.AsString()
    except:
        return "Undefined"

    return "Undefined"

# Solid fill pattern
def get_solid_fill_pattern_id():
    patterns = DB.FilteredElementCollector(doc).OfClass(DB.FillPatternElement)
    for pattern in patterns:
        if pattern.GetFillPattern().IsSolidFill:
            return pattern.Id
    return None

solid_fill_id = get_solid_fill_pattern_id()
if not solid_fill_id:
    forms.alert("Solid fill pattern not found in the project.", exitscript=True)

# Group by parameter
grouped_rebars = defaultdict(list)
for rebar in rebars:
    key = get_param_value(rebar, selected_param)
    grouped_rebars[key].append(rebar)

# Generate colors
def stable_color(index):
    base_colors = [
        (255, 0, 0), (0, 128, 0), (0, 0, 255),
        (255, 165, 0), (128, 0, 128), (0, 206, 209),
        (255, 20, 147), (160, 82, 45), (70, 130, 180),
        (220, 20, 60), (0, 255, 127), (218, 165, 32),
        (154, 205, 50), (0, 191, 255), (255, 105, 180),
        (100, 149, 237), (210, 105, 30), (0, 250, 154)
    ]
    r, g, b = base_colors[index % len(base_colors)]
    return DB.Color(r, g, b), (r, g, b)

# Apply overrides and collect report data
t = DB.Transaction(doc, "Color Rebars by Parameter")
t.Start()

report_data = []
for idx, (key, elements) in enumerate(grouped_rebars.items()):
    color, rgb = stable_color(idx)
    override = DB.OverrideGraphicSettings()
    override.SetProjectionLineColor(color)
    override.SetSurfaceForegroundPatternColor(color)
    override.SetSurfaceForegroundPatternId(solid_fill_id)

    for rebar in elements:
        view.SetElementOverrides(rebar.Id, override)

    report_data.append({
        "group": key,
        "rgb": rgb,
        "count": len(elements)
    })

t.Commit()

# HTML rows
html_rows = ""
for row in report_data:
    html_rows += "<tr style='color: black;'>"
    html_rows += "<td style='padding:6px'>{}</td>".format(row["group"])
    html_rows += "<td style='padding:6px'>{}</td>".format(row["count"])
    html_rows += "<td style='padding:6px; background-color: rgb({},{},{})'></td>".format(*row["rgb"])
    html_rows += "</tr>"

# HTML content
html_content = """
<html>
<head>
    <title>Rebar Color Report</title>
</head>
<body>
    <h2>Rebar Color Report - Grouped by: {}</h2>
    <table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse'>
        <tr style='background-color: #ddd;'>
            <th>{}</th>
            <th>Count</th>
            <th>Color</th>
        </tr>
        {}
    </table>
</body>
</html>
""".format(selected_param, selected_param, html_rows)

# Save to Desktop > Rebar_Color_Report
desktop = os.path.join(os.path.expanduser("~"), "Desktop")
report_folder = os.path.join(desktop, "Rebar_Color_Report")
if not os.path.exists(report_folder):
    os.makedirs(report_folder)

report_path = os.path.join(report_folder, "Rebar_Color_Report.html")
with open(report_path, "w") as f:
    f.write(html_content)

forms.alert("Rebars were colored by '{}'.\n\nHTML report saved to:\n{}".format(selected_param, report_path))
