# -*- coding: utf-8 -*-
__title__ = "Delete Unassociated\nAnalytical Elements"
__author__ = "Ghasem Ariani"

import clr
import datetime

clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")

from Autodesk.Revit.DB import (
    FilteredElementCollector, BuiltInCategory,
    Transaction, TransactionGroup
)
from RevitServices.Persistence import DocumentManager

doc = DocumentManager.Instance.CurrentDBDocument
start_time = datetime.datetime.now()

# Target analytical categories
categories = [
    BuiltInCategory.OST_AnalyticalMember,
    BuiltInCategory.OST_AnalyticalPanel
]

elements_to_delete = []
report_data = []
total_checked = 0

for cat in categories:
    elems = FilteredElementCollector(doc).OfCategory(cat).WhereElementIsNotElementType().ToElements()
    total_checked += len(elems)
    for elem in elems:
        try:
            param = elem.LookupParameter("Has Association")
            if param and not param.AsInteger():
                elements_to_delete.append(elem.Id)
                report_data.append({
                    "id": str(elem.Id.IntegerValue),
                    "category": elem.Category.Name if elem.Category else "N/A",
                    "type": elem.Name,
                    "level": elem.LookupParameter("Reference Level").AsString() if elem.LookupParameter("Reference Level") else "-",
                })
        except:
            continue

# Deletion using TransactionGroup
if elements_to_delete:
    tg = TransactionGroup(doc, "Delete Unassociated Analytical Elements")
    tg.Start()
    try:
        t = Transaction(doc, "Delete Elements")
        t.Start()
        for eid in elements_to_delete:
            try:
                doc.Delete(eid)
            except:
                continue
        t.Commit()
        tg.Assimilate()
    except Exception as e:
        tg.RollBack()

# Final graphical report
end_time = datetime.datetime.now()
duration = (end_time - start_time).total_seconds()

def format_row(index, eid, category, etype, level):
    return "│ {:<3} │ {:<10} │ {:<22} │ {:<26} │ {:<10} │".format(index, eid, category[:22], etype[:26], level)

header = "╔═════╦════════════╦════════════════════════════╦════════════════════════════════╦════════════╗"
columns = "║ #   ║ Element ID ║ Category                   ║ Type Name                      ║ Level      ║"
divider = "╠═════╬════════════╬════════════════════════════╬════════════════════════════════╬════════════╣"
footer = "╚═════╩════════════╩════════════════════════════╩════════════════════════════════╩════════════╝"

print("\n📋 Deletion Report – Unassociated Analytical Elements")
print("═════════════════════════════════════════════════════════════════════════════════════════════")
print("🔎 Total Checked: {}".format(total_checked))
print("🗑️  Deleted: {}".format(len(report_data)))
print("⏱️ Duration: {:.2f} seconds".format(duration))
print("═════════════════════════════════════════════════════════════════════════════════════════════\n")

if report_data:
    print(header)
    print(columns)
    print(divider)
    for i, item in enumerate(report_data, 1):
        print(format_row(i, item["id"], item["category"], item["type"], item["level"]))
    print(footer)
else:
    print("✅ No unassociated analytical elements found.")

print("\n✅ Done.")
