# -*- coding: utf-8 -*-
"""
Structural Framing Join Controller
Simple, Professional Tool for Allow/Disallow Join Operations
"""

__title__ = "Join Controller"
__author__ = "Professional"

import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')

from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Structure import StructuralFramingUtils
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import ObjectType
from System.Windows.Forms import *
from System.Drawing import *
import System

# Global variables
app = __revit__.Application
doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

class JoinControllerForm(Form):
    """Simple and Professional Join Controller Tool"""
    
    def __init__(self):
        self.selected_elements = []
        self.structural_framings = []
        self.InitializeComponent()
        
    def InitializeComponent(self):
        """Simple and clean UI with dual functionality"""
        
        # Form settings
        self.Text = "Structural Framing Join Controller"
        self.Size = Size(450, 380)
        self.StartPosition = FormStartPosition.CenterScreen
        self.FormBorderStyle = FormBorderStyle.FixedDialog
        self.MaximizeBox = False
        self.MinimizeBox = False
        self.ShowIcon = False
        self.BackColor = Color.FromArgb(240, 240, 240)
        self.Font = Font("Segoe UI", 8.25)
        
        # Title
        title = Label()
        title.Text = "Structural Framing Join Controller"
        title.Font = Font("Segoe UI", 10, FontStyle.Bold)
        title.Size = Size(410, 25)
        title.Location = Point(20, 20)
        title.ForeColor = Color.FromArgb(51, 51, 51)
        
        # Description
        desc = Label()
        desc.Text = "Enable or disable join connectors at both ends of selected structural framing elements."
        desc.Font = Font("Segoe UI", 8.25)
        desc.Size = Size(410, 30)
        desc.Location = Point(20, 45)
        desc.ForeColor = Color.FromArgb(102, 102, 102)
        
        # Operation selection
        operation_label = Label()
        operation_label.Text = "Operation:"
        operation_label.Font = Font("Segoe UI", 8.25, FontStyle.Bold)
        operation_label.Size = Size(70, 20)
        operation_label.Location = Point(20, 85)
        operation_label.ForeColor = Color.FromArgb(51, 51, 51)
        
        # Radio buttons for operation selection
        self.disallow_radio = RadioButton()
        self.disallow_radio.Text = "Disallow Join (Disable connectors)"
        self.disallow_radio.Font = Font("Segoe UI", 8.25)
        self.disallow_radio.Size = Size(200, 20)
        self.disallow_radio.Location = Point(100, 85)
        self.disallow_radio.Checked = True
        self.disallow_radio.ForeColor = Color.FromArgb(51, 51, 51)
        self.disallow_radio.CheckedChanged += self.on_operation_changed
        
        self.allow_radio = RadioButton()
        self.allow_radio.Text = "Allow Join (Enable connectors)"
        self.allow_radio.Font = Font("Segoe UI", 8.25)
        self.allow_radio.Size = Size(200, 20)
        self.allow_radio.Location = Point(100, 105)
        self.allow_radio.ForeColor = Color.FromArgb(51, 51, 51)
        self.allow_radio.CheckedChanged += self.on_operation_changed
        
        # Selection buttons
        self.current_btn = Button()
        self.current_btn.Text = "Use Current Selection"
        self.current_btn.Font = Font("Segoe UI", 8.25)
        self.current_btn.Size = Size(130, 26)
        self.current_btn.Location = Point(20, 140)
        self.current_btn.BackColor = Color.FromArgb(0, 120, 212)
        self.current_btn.ForeColor = Color.White
        self.current_btn.FlatStyle = FlatStyle.Flat
        self.current_btn.FlatAppearance.BorderSize = 0
        self.current_btn.Click += self.get_current_selection
        
        self.select_btn = Button()
        self.select_btn.Text = "Select Elements..."
        self.select_btn.Font = Font("Segoe UI", 8.25)
        self.select_btn.Size = Size(110, 26)
        self.select_btn.Location = Point(160, 140)
        self.select_btn.BackColor = Color.FromArgb(225, 225, 225)
        self.select_btn.ForeColor = Color.FromArgb(51, 51, 51)
        self.select_btn.FlatStyle = FlatStyle.Flat
        self.select_btn.FlatAppearance.BorderSize = 1
        self.select_btn.FlatAppearance.BorderColor = Color.FromArgb(173, 173, 173)
        self.select_btn.Click += self.select_new_elements
        
        # Status
        self.status_label = Label()
        self.status_label.Text = "No elements selected"
        self.status_label.Font = Font("Segoe UI", 8.25)
        self.status_label.Size = Size(410, 22)
        self.status_label.Location = Point(20, 175)
        self.status_label.BackColor = Color.White
        self.status_label.BorderStyle = BorderStyle.FixedSingle
        self.status_label.TextAlign = ContentAlignment.MiddleLeft
        self.status_label.Padding = Padding(8, 0, 8, 0)
        self.status_label.ForeColor = Color.FromArgb(102, 102, 102)
        
        # Results
        self.results_text = TextBox()
        self.results_text.Multiline = True
        self.results_text.ReadOnly = True
        self.results_text.ScrollBars = ScrollBars.Vertical
        self.results_text.Size = Size(410, 80)
        self.results_text.Location = Point(20, 210)
        self.results_text.BackColor = Color.White
        self.results_text.BorderStyle = BorderStyle.FixedSingle
        self.results_text.Font = Font("Consolas", 8)
        self.results_text.Text = "Ready to process structural framing elements..."
        
        # Action buttons
        self.apply_btn = Button()
        self.apply_btn.Text = "Disallow Join"
        self.apply_btn.Font = Font("Segoe UI", 8.25, FontStyle.Bold)
        self.apply_btn.Size = Size(100, 28)
        self.apply_btn.Location = Point(250, 305)
        self.apply_btn.BackColor = Color.FromArgb(220, 53, 69)  # Red for disallow
        self.apply_btn.ForeColor = Color.White
        self.apply_btn.FlatStyle = FlatStyle.Flat
        self.apply_btn.FlatAppearance.BorderSize = 0
        self.apply_btn.Enabled = False
        self.apply_btn.Click += self.apply_operation
        
        cancel_btn = Button()
        cancel_btn.Text = "Cancel"
        cancel_btn.Font = Font("Segoe UI", 8.25)
        cancel_btn.Size = Size(75, 28)
        cancel_btn.Location = Point(355, 305)
        cancel_btn.BackColor = Color.FromArgb(225, 225, 225)
        cancel_btn.ForeColor = Color.FromArgb(51, 51, 51)
        cancel_btn.FlatStyle = FlatStyle.Flat
        cancel_btn.FlatAppearance.BorderSize = 1
        cancel_btn.FlatAppearance.BorderColor = Color.FromArgb(173, 173, 173)
        cancel_btn.Click += self.close_form
        
        # Add controls
        self.Controls.Add(title)
        self.Controls.Add(desc)
        self.Controls.Add(operation_label)
        self.Controls.Add(self.disallow_radio)
        self.Controls.Add(self.allow_radio)
        self.Controls.Add(self.current_btn)
        self.Controls.Add(self.select_btn)
        self.Controls.Add(self.status_label)
        self.Controls.Add(self.results_text)
        self.Controls.Add(self.apply_btn)
        self.Controls.Add(cancel_btn)
        
        # Auto check
        self.check_current_selection()
    
    def on_operation_changed(self, sender, e):
        """Update UI based on selected operation"""
        if self.disallow_radio.Checked:
            self.apply_btn.Text = "Disallow Join"
            self.apply_btn.BackColor = Color.FromArgb(220, 53, 69)  # Red
        else:
            self.apply_btn.Text = "Allow Join"
            self.apply_btn.BackColor = Color.FromArgb(40, 167, 69)  # Green
        
        # Update analysis if elements are selected
        if len(self.structural_framings) > 0:
            self.update_status()
    
    def check_current_selection(self):
        """Check current selection"""
        try:
            current_selection = uidoc.Selection.GetElementIds()
            if len(current_selection) > 0:
                self.get_current_selection(None, None)
        except:
            pass
    
    def get_current_selection(self, sender, e):
        """Get current selection"""
        try:
            current_selection = uidoc.Selection.GetElementIds()
            self.selected_elements = []
            self.structural_framings = []
            
            for element_id in current_selection:
                element = doc.GetElement(element_id)
                if element and element.Category:
                    self.selected_elements.append(element)
                    if element.Category.Name == "Structural Framing":
                        self.structural_framings.append(element)
            
            self.update_status()
            
        except Exception as ex:
            self.results_text.Text = "Error: {}".format(str(ex))
    
    def select_new_elements(self, sender, e):
        """Select new elements"""
        try:
            self.Hide()
            
            selection = uidoc.Selection.PickObjects(
                ObjectType.Element,
                "Select structural framing elements"
            )
            
            self.selected_elements = []
            self.structural_framings = []
            
            for ref in selection:
                element = doc.GetElement(ref.ElementId)
                if element and element.Category:
                    self.selected_elements.append(element)
                    if element.Category.Name == "Structural Framing":
                        self.structural_framings.append(element)
            
            self.Show()
            self.BringToFront()
            self.update_status()
            
        except:
            self.Show()
            self.BringToFront()
    
    def update_status(self):
        """Update status based on selection and operation"""
        structural = len(self.structural_framings)
        
        if structural > 0:
            self.status_label.Text = "  {} structural framing elements selected".format(structural)
            self.status_label.BackColor = Color.FromArgb(223, 240, 216)
            self.status_label.ForeColor = Color.FromArgb(60, 118, 61)
            
            self.apply_btn.Enabled = True
            
            # Analysis based on current operation
            with_joins = 0
            without_joins = 0
            
            for element in self.structural_framings:
                try:
                    joined = JoinGeometryUtils.GetJoinedElements(doc, element)
                    if len(joined) > 0:
                        with_joins += 1
                    else:
                        without_joins += 1
                except:
                    pass
            
            # Operation-specific analysis
            if self.disallow_radio.Checked:
                operation_text = "DISALLOW JOIN ANALYSIS"
                action_text = "disable join connectors"
                target_elements = with_joins
            else:
                operation_text = "ALLOW JOIN ANALYSIS"
                action_text = "enable join connectors"
                target_elements = without_joins
            
            self.results_text.Text = "{}:\n".format(operation_text)
            self.results_text.Text += "• {} structural framing elements selected\n".format(structural)
            self.results_text.Text += "• {} elements currently have active joins\n".format(with_joins)
            self.results_text.Text += "• {} elements currently have no joins\n".format(without_joins)
            self.results_text.Text += "\nOperation will {} at both ends of all selected elements.".format(action_text)
            
        else:
            self.status_label.Text = "  No structural framing elements selected"
            self.status_label.BackColor = Color.White
            self.status_label.ForeColor = Color.FromArgb(102, 102, 102)
            
            self.apply_btn.Enabled = False
            
            self.results_text.Text = "Please select structural framing elements."
    
    def apply_operation(self, sender, e):
        """Apply selected operation (Allow or Disallow Join)"""
        if len(self.structural_framings) == 0:
            return
        
        operation_name = "Disallow Join" if self.disallow_radio.Checked else "Allow Join"
        action_verb = "disable" if self.disallow_radio.Checked else "enable"
        
        result = MessageBox.Show(
            "{} connectors at both ends of {} structural framing elements?".format(
                action_verb.capitalize(), len(self.structural_framings)
            ),
            "Confirm {}".format(operation_name),
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question
        )
        
        if result == DialogResult.No:
            return
        
        try:
            transaction = Transaction(doc, operation_name)
            transaction.Start()
            
            success = 0
            errors = 0
            
            for element in self.structural_framings:
                try:
                    if self.disallow_radio.Checked:
                        # Disallow join at both ends
                        StructuralFramingUtils.DisallowJoinAtEnd(element, 0)
                        StructuralFramingUtils.DisallowJoinAtEnd(element, 1)
                    else:
                        # Allow join at both ends
                        StructuralFramingUtils.AllowJoinAtEnd(element, 0)
                        StructuralFramingUtils.AllowJoinAtEnd(element, 1)
                    
                    success += 1
                except:
                    errors += 1
            
            transaction.Commit()
            
            # Results
            self.results_text.Text = "Operation completed:\n"
            self.results_text.Text += "• {} elements processed successfully\n".format(success)
            if errors > 0:
                self.results_text.Text += "• {} elements had errors\n".format(errors)
            self.results_text.Text += "\nJoin connectors {} at both ends.".format(
                "disabled" if self.disallow_radio.Checked else "enabled"
            )
            
            if success > 0:
                MessageBox.Show(
                    "Success! {} elements processed.\nJoin connectors {} at both ends.".format(
                        success, "disabled" if self.disallow_radio.Checked else "enabled"
                    ),
                    "Operation Complete",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                )
                
                # Reset selection for next operation
                self.selected_elements = []
                self.structural_framings = []
                self.update_status()
            
        except Exception as ex:
            MessageBox.Show("Error: {}".format(str(ex)), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    
    def close_form(self, sender, e):
        """Close form"""
        self.Close()

def main():
    """Main function"""
    try:
        if not doc:
            MessageBox.Show("No Revit document found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            return
        
        form = JoinControllerForm()
        Application.Run(form)
        
    except Exception as ex:
        MessageBox.Show("Error: {}".format(str(ex)), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

if __name__ == "__main__":
    main()