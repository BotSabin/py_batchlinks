# -*- coding: utf-8 -*-
"""Pattern Export Tool for Revit
Professional tool to export and convert Revit patterns
"""

__title__ = "Pattern\nExport Tool"
__author__ = "AI Assistant"
__doc__ = "Export Revit patterns with Model/Drafting conversion"

import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
import System.Windows.Forms as WinForms
import System.Drawing as Drawing

# Get current document
doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

class PatternExportWindow(WinForms.Form):
    def __init__(self):
        self.model_patterns = []
        self.drafting_patterns = []
        self.InitializeForm()
        self.CreateComponents()
        self.LoadPatterns()
    
    def InitializeForm(self):
        self.Text = "Pattern Export Pro - Advanced Pattern Manager"
        self.Size = Drawing.Size(1100, 800)
        self.StartPosition = WinForms.FormStartPosition.CenterScreen
        self.FormBorderStyle = WinForms.FormBorderStyle.Sizable
        self.BackColor = Drawing.Color.FromArgb(245, 245, 245)
        self.MinimumSize = Drawing.Size(900, 600)
    
    def CreateComponents(self):
        # Header Panel
        self.header_panel = WinForms.Panel()
        self.header_panel.Height = 80
        self.header_panel.Dock = WinForms.DockStyle.Top
        self.header_panel.BackColor = Drawing.Color.FromArgb(41, 128, 185)
        
        title_label = WinForms.Label()
        title_label.Text = "Pattern Export Pro"
        title_label.Font = Drawing.Font("Segoe UI", 18, Drawing.FontStyle.Bold)
        title_label.ForeColor = Drawing.Color.White
        title_label.Location = Drawing.Point(20, 15)
        title_label.AutoSize = True
        
        subtitle_label = WinForms.Label()
        subtitle_label.Text = "Advanced Pattern Management & Export Tool"
        subtitle_label.Font = Drawing.Font("Segoe UI", 12, Drawing.FontStyle.Bold)
        subtitle_label.ForeColor = Drawing.Color.White
        subtitle_label.Location = Drawing.Point(20, 45)
        subtitle_label.AutoSize = True
        
        self.stats_label = WinForms.Label()
        self.stats_label.Text = "Loading patterns..."
        self.stats_label.Font = Drawing.Font("Segoe UI", 10)
        self.stats_label.ForeColor = Drawing.Color.White
        self.stats_label.Location = Drawing.Point(650, 15)
        self.stats_label.Size = Drawing.Size(220, 20)
        self.stats_label.TextAlign = Drawing.ContentAlignment.TopRight
        
        # Color legend
        legend_label = WinForms.Label()
        legend_label.Text = "🔵 Model   🟢 Drafting"
        legend_label.Font = Drawing.Font("Segoe UI", 9, Drawing.FontStyle.Bold)
        legend_label.ForeColor = Drawing.Color.White
        legend_label.Location = Drawing.Point(650, 40)
        legend_label.Size = Drawing.Size(150, 20)
        legend_label.TextAlign = Drawing.ContentAlignment.TopRight
        
        self.header_panel.Controls.Add(title_label)
        self.header_panel.Controls.Add(subtitle_label)
        self.header_panel.Controls.Add(self.stats_label)
        self.header_panel.Controls.Add(legend_label)
        
        # Options Panel
        self.options_panel = WinForms.GroupBox()
        self.options_panel.Text = "Export Configuration"
        self.options_panel.Font = Drawing.Font("Segoe UI", 11, Drawing.FontStyle.Bold)
        self.options_panel.Height = 120
        self.options_panel.Dock = WinForms.DockStyle.Top
        self.options_panel.BackColor = Drawing.Color.White
        
        # Filter buttons
        filter_label = WinForms.Label()
        filter_label.Text = "Filter:"
        filter_label.Location = Drawing.Point(20, 25)
        filter_label.Size = Drawing.Size(50, 20)
        filter_label.Font = Drawing.Font("Segoe UI", 10, Drawing.FontStyle.Bold)
        
        self.btn_all = self.CreateFilterButton("All", Drawing.Point(70, 22), True)
        self.btn_model = self.CreateFilterButton("Model", Drawing.Point(150, 22), False)
        self.btn_drafting = self.CreateFilterButton("Drafting", Drawing.Point(230, 22), False)
        
        # Search
        search_label = WinForms.Label()
        search_label.Text = "Search:"
        search_label.Location = Drawing.Point(330, 25)
        search_label.Size = Drawing.Size(50, 20)
        search_label.Font = Drawing.Font("Segoe UI", 10, Drawing.FontStyle.Bold)
        
        self.search_textbox = WinForms.TextBox()
        self.search_textbox.Location = Drawing.Point(385, 22)
        self.search_textbox.Size = Drawing.Size(150, 25)
        self.search_textbox.TextChanged += self.OnSearchChanged
        
        # Export options
        export_label = WinForms.Label()
        export_label.Text = "Export As:"
        export_label.Location = Drawing.Point(20, 60)
        export_label.Size = Drawing.Size(70, 20)
        export_label.Font = Drawing.Font("Segoe UI", 10, Drawing.FontStyle.Bold)
        
        self.rb_keep = WinForms.RadioButton()
        self.rb_keep.Text = "Keep Original"
        self.rb_keep.Location = Drawing.Point(95, 60)
        self.rb_keep.Size = Drawing.Size(100, 20)
        self.rb_keep.Checked = True
        self.rb_keep.CheckedChanged += self.OnExportOptionChanged
        
        self.rb_force_model = WinForms.RadioButton()
        self.rb_force_model.Text = "Force Model"
        self.rb_force_model.Location = Drawing.Point(200, 60)
        self.rb_force_model.Size = Drawing.Size(100, 20)
        self.rb_force_model.CheckedChanged += self.OnExportOptionChanged
        
        self.rb_force_drafting = WinForms.RadioButton()
        self.rb_force_drafting.Text = "Force Drafting"
        self.rb_force_drafting.Location = Drawing.Point(305, 60)
        self.rb_force_drafting.Size = Drawing.Size(110, 20)
        self.rb_force_drafting.CheckedChanged += self.OnExportOptionChanged
        
        # Advanced options with tooltips
        self.chk_comments = WinForms.CheckBox()
        self.chk_comments.Text = "Include Enhanced"
        self.chk_comments.Location = Drawing.Point(20, 85)
        self.chk_comments.Size = Drawing.Size(180, 20)
        self.chk_comments.Checked = True
        
        self.chk_backup = WinForms.CheckBox()
        self.chk_backup.Text = "Create Backup"
        self.chk_backup.Location = Drawing.Point(210, 85)
        self.chk_backup.Size = Drawing.Size(140, 20)
        self.chk_backup.Checked = True
        
        self.chk_optimize = WinForms.CheckBox()
        self.chk_optimize.Text = "Optimize File"
        self.chk_optimize.Location = Drawing.Point(360, 85)
        self.chk_optimize.Size = Drawing.Size(130, 20)
        
        # Add controls to options panel
        self.options_panel.Controls.Add(filter_label)
        self.options_panel.Controls.Add(self.btn_all)
        self.options_panel.Controls.Add(self.btn_model)
        self.options_panel.Controls.Add(self.btn_drafting)
        self.options_panel.Controls.Add(search_label)
        self.options_panel.Controls.Add(self.search_textbox)
        self.options_panel.Controls.Add(export_label)
        self.options_panel.Controls.Add(self.rb_keep)
        self.options_panel.Controls.Add(self.rb_force_model)
        self.options_panel.Controls.Add(self.rb_force_drafting)
        self.options_panel.Controls.Add(self.chk_comments)
        self.options_panel.Controls.Add(self.chk_backup)
        self.options_panel.Controls.Add(self.chk_optimize)
        
        # Main content splitter
        main_splitter = WinForms.SplitContainer()
        main_splitter.Dock = WinForms.DockStyle.Fill
        main_splitter.Orientation = WinForms.Orientation.Vertical
        main_splitter.SplitterDistance = 700
        
        # Pattern List Panel
        self.list_panel = WinForms.GroupBox()
        self.list_panel.Text = "Pattern Library"
        self.list_panel.Font = Drawing.Font("Segoe UI", 11, Drawing.FontStyle.Bold)
        self.list_panel.Dock = WinForms.DockStyle.Fill
        self.list_panel.BackColor = Drawing.Color.White
        
        self.pattern_listview = WinForms.ListView()
        self.pattern_listview.View = WinForms.View.Details
        self.pattern_listview.FullRowSelect = True
        self.pattern_listview.GridLines = True
        self.pattern_listview.CheckBoxes = True
        self.pattern_listview.Dock = WinForms.DockStyle.Fill
        self.pattern_listview.Font = Drawing.Font("Segoe UI", 9)
        self.pattern_listview.ItemCheck += self.OnPatternCheck
        self.pattern_listview.SelectedIndexChanged += self.OnPatternSelected
        
        # Add columns
        self.pattern_listview.Columns.Add("Pattern Name", 220)
        self.pattern_listview.Columns.Add("Type", 80)
        self.pattern_listview.Columns.Add("Category", 100)
        self.pattern_listview.Columns.Add("Grids", 60)
        self.pattern_listview.Columns.Add("Export As", 90)
        self.pattern_listview.Columns.Add("Status", 120)
        self.pattern_listview.Columns.Add("Size KB", 70)
        
        self.list_panel.Controls.Add(self.pattern_listview)
        
        # Preview Panel
        self.preview_panel = WinForms.GroupBox()
        self.preview_panel.Text = "Pattern Details & Export Preview"
        self.preview_panel.Font = Drawing.Font("Segoe UI", 11, Drawing.FontStyle.Bold)
        self.preview_panel.Dock = WinForms.DockStyle.Fill
        self.preview_panel.BackColor = Drawing.Color.White
        
        preview_tabs = WinForms.TabControl()
        preview_tabs.Dock = WinForms.DockStyle.Fill
        
        # Details tab
        details_tab = WinForms.TabPage("Pattern Details")
        self.details_text = WinForms.TextBox()
        self.details_text.Multiline = True
        self.details_text.ReadOnly = True
        self.details_text.Dock = WinForms.DockStyle.Fill
        self.details_text.Font = Drawing.Font("Consolas", 9)
        self.details_text.BackColor = Drawing.Color.FromArgb(248, 249, 250)
        self.details_text.ScrollBars = WinForms.ScrollBars.Vertical
        details_tab.Controls.Add(self.details_text)
        
        # Export preview tab
        export_tab = WinForms.TabPage("Export Preview")
        self.export_text = WinForms.TextBox()
        self.export_text.Multiline = True
        self.export_text.ReadOnly = True
        self.export_text.Dock = WinForms.DockStyle.Fill
        self.export_text.Font = Drawing.Font("Consolas", 9)
        self.export_text.BackColor = Drawing.Color.FromArgb(248, 249, 250)
        self.export_text.ScrollBars = WinForms.ScrollBars.Vertical
        export_tab.Controls.Add(self.export_text)
        
        preview_tabs.TabPages.Add(details_tab)
        preview_tabs.TabPages.Add(export_tab)
        self.preview_panel.Controls.Add(preview_tabs)
        
        main_splitter.Panel1.Controls.Add(self.list_panel)
        main_splitter.Panel2.Controls.Add(self.preview_panel)
        
        # Action Panel
        self.action_panel = WinForms.Panel()
        self.action_panel.Height = 70
        self.action_panel.Dock = WinForms.DockStyle.Bottom
        self.action_panel.BackColor = Drawing.Color.FromArgb(236, 240, 241)
        
        # Progress bar
        self.progress_bar = WinForms.ProgressBar()
        self.progress_bar.Location = Drawing.Point(20, 15)
        self.progress_bar.Size = Drawing.Size(300, 20)
        self.progress_bar.Visible = False
        
        # Action buttons
        self.btn_select_all = self.CreateActionButton("Select All", Drawing.Point(350, 15))
        self.btn_select_all.Click += self.OnSelectAll
        
        self.btn_export = self.CreateActionButton("Export Selected", Drawing.Point(470, 15))
        self.btn_export.BackColor = Drawing.Color.FromArgb(39, 174, 96)
        self.btn_export.Click += self.OnExport
        
        self.btn_refresh = self.CreateActionButton("Refresh", Drawing.Point(610, 15))
        self.btn_refresh.BackColor = Drawing.Color.FromArgb(52, 152, 219)
        self.btn_refresh.Click += self.OnRefresh
        
        self.btn_close = self.CreateActionButton("Close", Drawing.Point(730, 15))
        self.btn_close.BackColor = Drawing.Color.FromArgb(231, 76, 60)
        self.btn_close.Click += self.OnClose
        
        # Status
        self.status_label = WinForms.Label()
        self.status_label.Text = "Ready"
        self.status_label.Location = Drawing.Point(20, 45)
        self.status_label.Size = Drawing.Size(600, 20)
        self.status_label.Font = Drawing.Font("Segoe UI", 9)
        self.status_label.ForeColor = Drawing.Color.FromArgb(39, 174, 96)
        
        self.action_panel.Controls.Add(self.progress_bar)
        self.action_panel.Controls.Add(self.btn_select_all)
        self.action_panel.Controls.Add(self.btn_export)
        self.action_panel.Controls.Add(self.btn_refresh)
        self.action_panel.Controls.Add(self.btn_close)
        self.action_panel.Controls.Add(self.status_label)
        
        # Add all panels to form
        self.Controls.Add(main_splitter)
        self.Controls.Add(self.action_panel)
        self.Controls.Add(self.options_panel)
        self.Controls.Add(self.header_panel)
    
    def CreateFilterButton(self, text, location, checked):
        btn = WinForms.Button()
        btn.Text = text
        btn.Size = Drawing.Size(70, 25)
        btn.Location = location
        btn.FlatStyle = WinForms.FlatStyle.Flat
        btn.Font = Drawing.Font("Segoe UI", 9, Drawing.FontStyle.Bold)
        
        if checked:
            btn.BackColor = Drawing.Color.FromArgb(52, 152, 219)
            btn.ForeColor = Drawing.Color.White
        else:
            btn.BackColor = Drawing.Color.FromArgb(236, 240, 241)
            btn.ForeColor = Drawing.Color.FromArgb(52, 73, 94)
        
        btn.Click += self.OnFilterButtonClick
        return btn
    
    def CreateActionButton(self, text, location):
        btn = WinForms.Button()
        btn.Text = text
        btn.Size = Drawing.Size(110, 25)
        btn.Location = location
        btn.BackColor = Drawing.Color.FromArgb(149, 165, 166)
        btn.ForeColor = Drawing.Color.White
        btn.Font = Drawing.Font("Segoe UI", 9, Drawing.FontStyle.Bold)
        btn.FlatStyle = WinForms.FlatStyle.Flat
        btn.FlatAppearance.BorderSize = 0
        return btn
    
    def LoadPatterns(self):
        try:
            self.ShowProgress("Loading patterns...")
            self.model_patterns = []
            self.drafting_patterns = []
            
            collector = FilteredElementCollector(doc)
            fill_pattern_elements = collector.OfClass(FillPatternElement)
            
            for pattern_element in fill_pattern_elements:
                try:
                    if pattern_element and pattern_element.IsValidObject:
                        fill_pattern = pattern_element.GetFillPattern()
                        if fill_pattern:
                            pattern_info = self.AnalyzePattern(pattern_element, fill_pattern)
                            
                            if pattern_info['is_model']:
                                self.model_patterns.append(pattern_info)
                            else:
                                self.drafting_patterns.append(pattern_info)
                                
                except Exception:
                    continue
            
            self.UpdatePatternList()
            self.UpdateStatistics()
            self.HideProgress()
            
        except Exception as e:
            self.HideProgress()
            self.UpdateStatus("Error loading patterns: " + str(e), True)
    
    def AnalyzePattern(self, pattern_element, fill_pattern):
        try:
            element_id = pattern_element.Id.IntegerValue
        except:
            element_id = str(pattern_element.Id)
        
        try:
            grids = list(fill_pattern.GetFillGrids())
            grid_count = len(grids)
        except:
            grids = []
            grid_count = 0
        
        estimated_size = round((len(pattern_element.Name) * 2 + grid_count * 50 + 100) / 1024.0, 2)
        category = self.DetermineCategory(pattern_element.Name, grids)
        
        return {
            'element': pattern_element,
            'fill_pattern': fill_pattern,
            'name': pattern_element.Name or "Unnamed Pattern",
            'id': element_id,
            'target': fill_pattern.Target,
            'is_model': fill_pattern.Target == FillPatternTarget.Model,
            'grid_count': grid_count,
            'grids': grids,
            'estimated_size': estimated_size,
            'host_orientation': fill_pattern.HostOrientation,
            'category': category
        }
    
    def DetermineCategory(self, name, grids):
        name_lower = name.lower()
        
        if any(material in name_lower for material in ['brick', 'stone', 'concrete', 'block']):
            return "Masonry"
        elif any(material in name_lower for material in ['wood', 'timber', 'plank']):
            return "Wood"
        elif any(material in name_lower for material in ['steel', 'metal', 'iron']):
            return "Metal"
        elif any(material in name_lower for material in ['tile', 'ceramic', 'marble']):
            return "Finishes"
        elif any(pattern in name_lower for pattern in ['diagonal', 'crosshatch', 'hatch']):
            return "Hatching"
        elif any(pattern in name_lower for pattern in ['grid', 'square', 'rectangle']):
            return "Geometric"
        elif len(grids) == 0:
            return "Solid"
        else:
            return "Other"
    
    def UpdateStatistics(self):
        model_count = len(self.model_patterns)
        drafting_count = len(self.drafting_patterns)
        total_count = model_count + drafting_count
        
        stats_text = "Total: " + str(total_count) + " patterns\n"
        stats_text += "Model: " + str(model_count) + " | Drafting: " + str(drafting_count)
        self.stats_label.Text = stats_text
        
        if total_count > 0:
            status_text = "Loaded " + str(total_count) + " patterns (" + str(model_count) + " Model, " + str(drafting_count) + " Drafting)"
            self.UpdateStatus(status_text, False)
        else:
            self.UpdateStatus("No patterns found in document", True)
    
    def UpdatePatternList(self):
        self.pattern_listview.Items.Clear()
        
        patterns_to_show = self.GetFilteredPatterns()
        
        for pattern in patterns_to_show:
            self.AddPatternToList(pattern)
        
        self.UpdateExportPreview()
    
    def GetFilteredPatterns(self):
        if self.btn_model.BackColor == Drawing.Color.FromArgb(52, 152, 219):
            patterns = self.model_patterns
        elif self.btn_drafting.BackColor == Drawing.Color.FromArgb(52, 152, 219):
            patterns = self.drafting_patterns
        else:
            patterns = self.model_patterns + self.drafting_patterns
        
        search_text = self.search_textbox.Text.lower()
        if search_text:
            filtered_patterns = []
            for pattern in patterns:
                if search_text in pattern['name'].lower():
                    filtered_patterns.append(pattern)
            return filtered_patterns
        
        return patterns
    
    def AddPatternToList(self, pattern):
        current_type = "Model" if pattern['is_model'] else "Drafting"
        
        if self.rb_keep.Checked:
            export_as = current_type
        elif self.rb_force_model.Checked:
            export_as = "Model"
        else:
            export_as = "Drafting"
        
        if export_as == current_type:
            status = "Ready"
        else:
            status = "Convert " + current_type + " to " + export_as
        
        item = WinForms.ListViewItem(pattern['name'])
        item.SubItems.Add(current_type)
        item.SubItems.Add(pattern['category'])
        item.SubItems.Add(str(pattern['grid_count']))
        item.SubItems.Add(export_as)
        item.SubItems.Add(status)
        item.SubItems.Add(str(pattern['estimated_size']))
        item.Tag = pattern
        
        # Color coding based on pattern type and conversion status
        if pattern['is_model']:
            # Model patterns - Blue tones
            if export_as != current_type:
                item.BackColor = Drawing.Color.FromArgb(207, 226, 255)  # Light blue for conversion
                item.ForeColor = Drawing.Color.FromArgb(21, 67, 96)     # Dark blue text
            else:
                item.BackColor = Drawing.Color.FromArgb(187, 222, 251)  # Soft blue for model
                item.ForeColor = Drawing.Color.FromArgb(21, 67, 96)     # Dark blue text
        else:
            # Drafting patterns - Green tones
            if export_as != current_type:
                item.BackColor = Drawing.Color.FromArgb(255, 243, 205)  # Light orange for conversion
                item.ForeColor = Drawing.Color.FromArgb(133, 100, 4)    # Dark orange text
            else:
                item.BackColor = Drawing.Color.FromArgb(212, 237, 218)  # Light green for drafting
                item.ForeColor = Drawing.Color.FromArgb(22, 78, 30)     # Dark green text
        
        self.pattern_listview.Items.Add(item)
    
    def ShowProgress(self, message):
        self.status_label.Text = message
        self.progress_bar.Visible = True
        self.progress_bar.Style = WinForms.ProgressBarStyle.Marquee
    
    def HideProgress(self):
        self.progress_bar.Visible = False
    
    def UpdateStatus(self, message, is_error=False):
        self.status_label.Text = message
        if is_error:
            self.status_label.ForeColor = Drawing.Color.FromArgb(231, 76, 60)
        else:
            self.status_label.ForeColor = Drawing.Color.FromArgb(39, 174, 96)
    
    def UpdateExportPreview(self):
        selected = self.GetSelectedPatterns()
        
        if len(selected) == 0:
            preview_text = "No patterns selected for export.\n\n"
            preview_text += "Select patterns using checkboxes to see export preview."
            self.export_text.Text = preview_text
            return
        
        model_count = 0
        drafting_count = 0
        convert_count = 0
        
        for pattern in selected:
            current_type = "Model" if pattern['is_model'] else "Drafting"
            
            if self.rb_keep.Checked:
                final_type = current_type
            elif self.rb_force_model.Checked:
                final_type = "Model"
            else:
                final_type = "Drafting"
            
            if final_type != current_type:
                convert_count += 1
            
            if final_type == "Model":
                model_count += 1
            else:
                drafting_count += 1
        
        total_size = sum(p['estimated_size'] for p in selected)
        
        # Status and count info
        selected_count = len(selected)
        self.status_label.Text = "Ready - " + str(selected_count) + " patterns selected for export"
        
        preview = "EXPORT PREVIEW - BATCH EXPORT\n"
        preview += "=" * 50 + "\n\n"
        preview += "Selected Patterns: " + str(selected_count) + "\n"
        preview += "Total File Size: ~" + str(round(total_size, 1)) + " KB\n\n"
        
        if self.rb_keep.Checked:
            export_mode = "Keep Original Types"
        elif self.rb_force_model.Checked:
            export_mode = "Force All as MODEL"
        else:
            export_mode = "Force All as DRAFTING"
        
        preview += "Export Mode: " + export_mode + "\n\n"
        preview += "Output Distribution:\n"
        preview += "  Model Patterns: " + str(model_count) + "\n"
        preview += "  Drafting Patterns: " + str(drafting_count) + "\n"
        
        if convert_count > 0:
            preview += "  Type Conversions: " + str(convert_count) + "\n"
        
        preview += "\nAdvanced Options Explained:\n"
        preview += "  Enhanced Comments: " + ("Yes" if self.chk_comments.Checked else "No") + "\n"
        preview += "    - Adds detailed pattern info, category, grid count\n"
        preview += "  Create Backup: " + ("Yes" if self.chk_backup.Checked else "No") + "\n" 
        preview += "    - Backs up existing PAT file before overwriting\n"
        preview += "  Optimize Size: " + ("Yes" if self.chk_optimize.Checked else "No") + "\n"
        preview += "    - Reduces decimal precision to minimize file size\n\n"
        
        if selected_count > 1:
            preview += "BATCH EXPORT: All " + str(selected_count) + " patterns will be exported to single PAT file\n"
        
        preview += "Ready for export!"
        
        self.export_text.Text = preview
    
    def GetSelectedPatterns(self):
        selected = []
        for item in self.pattern_listview.Items:
            if item.Checked:
                selected.append(item.Tag)
        return selected
    
    def OnFilterButtonClick(self, sender, e):
        for btn in [self.btn_all, self.btn_model, self.btn_drafting]:
            btn.BackColor = Drawing.Color.FromArgb(236, 240, 241)
            btn.ForeColor = Drawing.Color.FromArgb(52, 73, 94)
        
        sender.BackColor = Drawing.Color.FromArgb(52, 152, 219)
        sender.ForeColor = Drawing.Color.White
        
        self.UpdatePatternList()
    
    def OnSearchChanged(self, sender, e):
        self.UpdatePatternList()
    
    def OnExportOptionChanged(self, sender, e):
        if sender.Checked:
            self.UpdatePatternList()
    
    def OnPatternCheck(self, sender, e):
        self.UpdateExportPreview()
    
    def OnPatternSelected(self, sender, e):
        if self.pattern_listview.SelectedItems.Count > 0:
            pattern = self.pattern_listview.SelectedItems[0].Tag
            self.ShowPatternDetails(pattern)
    
    def ShowPatternDetails(self, pattern):
        details = "PATTERN DETAILS\n"
        details += "=" * 30 + "\n\n"
        details += "Name: " + pattern['name'] + "\n"
        details += "Type: " + ("Model" if pattern['is_model'] else "Drafting") + "\n"
        details += "Category: " + pattern['category'] + "\n"
        details += "Element ID: " + str(pattern['id']) + "\n"
        details += "Grid Count: " + str(pattern['grid_count']) + "\n"
        details += "Estimated Size: " + str(pattern['estimated_size']) + " KB\n"
        details += "Host Orientation: " + str(pattern['host_orientation']) + "\n\n"
        
        if pattern['grids']:
            details += "GRID INFORMATION:\n"
            details += "-" * 20 + "\n"
            for i, grid in enumerate(pattern['grids']):
                details += "\nGrid " + str(i + 1) + ":\n"
                try:
                    angle_deg = round(grid.Angle * 180 / 3.14159, 2)
                    details += "  Angle: " + str(angle_deg) + " degrees\n"
                    
                    try:
                        details += "  Shift: " + str(round(grid.GetShift(), 4)) + "\n"
                        details += "  Offset: " + str(round(grid.GetOffset(), 4)) + "\n"
                    except:
                        details += "  Shift/Offset: Not available\n"
                        
                except Exception as e:
                    details += "  Error reading grid data: " + str(e) + "\n"
        else:
            details += "No grid information available."
        
        self.details_text.Text = details
    
    def OnSelectAll(self, sender, e):
        all_checked = True
        for item in self.pattern_listview.Items:
            if not item.Checked:
                all_checked = False
                break
        
        for item in self.pattern_listview.Items:
            item.Checked = not all_checked
        
        self.UpdateExportPreview()
    
    def OnExport(self, sender, e):
        selected = self.GetSelectedPatterns()
        
        if len(selected) == 0:
            TaskDialog.Show("Warning", "Please select patterns to export.")
            return
        
        if len(selected) == 1:
            clean_name = "".join(c for c in selected[0]['name'] if c.isalnum() or c in (' ', '-', '_')).strip()
            default_filename = clean_name + ".pat"
        else:
            export_type = "Mixed"
            if self.rb_force_model.Checked:
                export_type = "Model"
            elif self.rb_force_drafting.Checked:
                export_type = "Drafting"
            default_filename = str(len(selected)) + "_Patterns_" + export_type + ".pat"
        
        saveDialog = WinForms.SaveFileDialog()
        saveDialog.Filter = "Pattern files (*.pat)|*.pat"
        saveDialog.FileName = default_filename
        
        if saveDialog.ShowDialog() == WinForms.DialogResult.OK:
            self.ExportToPAT(selected, saveDialog.FileName)
    
    def ExportToPAT(self, patterns, filename):
        try:
            self.ShowProgress("Exporting " + str(len(patterns)) + " patterns...")
            
            # Create backup if file exists and backup is enabled
            if self.chk_backup.Checked:
                try:
                    import os
                    if os.path.exists(filename):
                        backup_name = filename.replace(".pat", "_backup.pat")
                        import shutil
                        shutil.copy2(filename, backup_name)
                        print("Backup created: " + backup_name)
                except Exception as backup_error:
                    print("Backup failed: " + str(backup_error))
            
            pat_content = self.GeneratePATContent(patterns)
            
            with open(filename, 'w') as f:
                f.write(pat_content)
            
            self.HideProgress()
            self.UpdateStatus("Export completed: " + str(len(patterns)) + " patterns exported successfully", False)
            
            success_msg = "Successfully exported " + str(len(patterns)) + " patterns!\n\n"
            success_msg += "File: " + filename + "\n"
            
            if self.chk_backup.Checked:
                success_msg += "Backup: Created (if file existed)\n"
            
            total_size = sum(p['estimated_size'] for p in patterns)
            success_msg += "File Size: ~" + str(round(total_size, 1)) + " KB\n\n"
            
            success_msg += "Pattern Details:\n"
            for pattern in patterns[:5]:  # Show first 5 patterns
                success_msg += "- " + pattern['name'] + " (" + ("Model" if pattern['is_model'] else "Drafting") + ")\n"
            
            if len(patterns) > 5:
                success_msg += "... and " + str(len(patterns) - 5) + " more patterns\n"
            
            success_msg += "\nImport Instructions:\n"
            success_msg += "1. Open Revit Fill Pattern dialog\n"
            success_msg += "2. Click Browse button\n"
            success_msg += "3. Select the PAT file\n"
            success_msg += "4. All patterns will appear in correct type"
            
            TaskDialog.Show("Batch Export Successful", success_msg)
            
        except Exception as e:
            self.HideProgress()
            self.UpdateStatus("Export failed: " + str(e), True)
            TaskDialog.Show("Export Error", "Failed to export patterns:\n\n" + str(e))
    
    def GeneratePATContent(self, patterns):
        pat_content = ""
        
        # Add file header with batch export info
        pat_content += "; Generated by Pattern Export Pro - Batch Export\n"
        pat_content += "; Total Patterns: " + str(len(patterns)) + "\n"
        pat_content += "; Export Options: Enhanced Comments=" + str(self.chk_comments.Checked)
        pat_content += ", Optimized=" + str(self.chk_optimize.Checked) + "\n"
        pat_content += "; " + "=" * 60 + "\n\n"
        
        exported_count = 0
        for pattern in patterns:
            try:
                current_type = "Model" if pattern['is_model'] else "Drafting"
                
                if self.rb_keep.Checked:
                    export_type = current_type.upper()
                elif self.rb_force_model.Checked:
                    export_type = "MODEL"
                else:
                    export_type = "DRAFTING"
                
                # Pattern header
                pat_content += "*" + pattern['name'] + ", " + pattern['name'] + "\n"
                pat_content += ";%TYPE=" + export_type + "\n"
                
                # Enhanced comments if enabled
                if self.chk_comments.Checked:
                    pat_content += ";" + pattern['name'] + " - " + export_type + " Pattern\n"
                    pat_content += ";Original Type: " + current_type + "\n"
                    pat_content += ";Category: " + pattern['category'] + "\n"
                    pat_content += ";Grid Count: " + str(pattern['grid_count']) + "\n"
                    pat_content += ";Estimated Size: " + str(pattern['estimated_size']) + " KB\n"
                    pat_content += ";Exported from Pattern Export Pro (Batch " + str(exported_count + 1) + "/" + str(len(patterns)) + ")\n"
                else:
                    pat_content += ";" + pattern['name'] + " - " + export_type + " Pattern\n"
                
                # Pattern grid data
                if pattern['grids'] and len(pattern['grids']) > 0:
                    try:
                        grid_lines_added = 0
                        for grid in pattern['grids']:
                            try:
                                angle = grid.Angle * 180.0 / 3.14159
                                origin_u = grid.Origin.U if hasattr(grid.Origin, 'U') else 0
                                origin_v = grid.Origin.V if hasattr(grid.Origin, 'V') else 0
                                
                                try:
                                    shift = grid.GetShift()
                                except:
                                    shift = 1.0 if export_type == "DRAFTING" else 25.4
                                
                                try:
                                    offset = grid.GetOffset()
                                except:
                                    offset = 1.0 if export_type == "DRAFTING" else 25.4
                                
                                # Ensure valid values
                                if export_type == "DRAFTING" and shift == 0 and offset == 0:
                                    shift = 1.0
                                    offset = 1.0
                                elif export_type == "MODEL" and shift == 0 and offset == 0:
                                    shift = 25.4
                                    offset = 25.4
                                
                                # Format with appropriate precision
                                if self.chk_optimize.Checked:
                                    line = "{:.3f},{:.3f},{:.3f},{:.3f},{:.3f}".format(
                                        angle, origin_u, origin_v, shift, offset)
                                else:
                                    line = "{:.6f},{:.6f},{:.6f},{:.6f},{:.6f}".format(
                                        angle, origin_u, origin_v, shift, offset)
                                
                                pat_content += line + "\n"
                                grid_lines_added += 1
                                
                            except Exception as grid_error:
                                print("Error processing grid in pattern " + pattern['name'] + ": " + str(grid_error))
                                continue
                        
                        # If no grid lines were successfully added, add default
                        if grid_lines_added == 0:
                            if export_type == "DRAFTING":
                                pat_content += "45,0,0,1,1\n"
                                pat_content += "135,0,0,1,1\n"
                            else:
                                pat_content += "0,0,0,25.4,25.4\n"
                                
                    except Exception as pattern_grid_error:
                        print("Error processing grids for pattern " + pattern['name'] + ": " + str(pattern_grid_error))
                        # Add default pattern
                        if export_type == "DRAFTING":
                            pat_content += "45,0,0,1,1\n"
                            pat_content += "135,0,0,1,1\n"
                        else:
                            pat_content += "0,0,0,25.4,25.4\n"
                else:
                    # Default patterns for patterns without grids
                    if export_type == "DRAFTING":
                        pat_content += "45,0,0,1,1\n"
                        pat_content += "135,0,0,1,1\n"
                    else:
                        pat_content += "0,0,0,25.4,25.4\n"
                
                pat_content += "\n"
                exported_count += 1
                
            except Exception as pattern_error:
                print("Error exporting pattern " + pattern['name'] + ": " + str(pattern_error))
                continue
        
        # Add footer
        pat_content += "; End of Pattern Export Pro batch export\n"
        pat_content += "; Successfully exported " + str(exported_count) + " of " + str(len(patterns)) + " patterns\n"
        
        return pat_content
    
    def OnRefresh(self, sender, e):
        self.LoadPatterns()
    
    def OnClose(self, sender, e):
        self.Close()

def main():
    try:
        if not doc:
            TaskDialog.Show("Error", "No active Revit document found.")
            return
        
        if doc.IsReadOnly:
            result = TaskDialog.Show("Read-Only Document", 
                                   "Document is read-only. Pattern export will work.\n\nContinue?",
                                   TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No)
            if result == TaskDialogResult.No:
                return
        
        window = PatternExportWindow()
        window.ShowDialog()
        
    except Exception as e:
        error_msg = "Failed to start Pattern Export Pro:\n\n" + str(e)
        TaskDialog.Show("Startup Error", error_msg)

if __name__ == '__main__':
    main()