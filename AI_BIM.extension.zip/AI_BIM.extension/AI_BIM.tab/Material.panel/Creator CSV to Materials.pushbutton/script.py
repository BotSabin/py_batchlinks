﻿# -*- coding: utf-8 -*-
"""Material Creator from CSV File
This script creates materials in Revit from a CSV file.
Compatible with IronPython - no external dependencies required.
"""

__title__ = "Material Creator"
__author__ = "Your Name"
__version__ = "2.0"

import sys
import clr

# Add .NET references
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')

# System imports
from System.Windows.Forms import (
    Application, Form, Button, Label, TextBox, OpenFileDialog, 
    MessageBox, MessageBoxButtons, MessageBoxIcon, ProgressBar,
    DialogResult, FormBorderStyle, FormStartPosition, Panel, 
    DragDropEffects, DragEventArgs, ListView, ListViewItem,
    View, ColumnHeader, BorderStyle
)
from System.Drawing import Size, Point, Color, Font, FontStyle
from System.IO import File, StreamReader, Path
from System.Text import Encoding

# Revit API imports
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
from Autodesk.Revit.DB import (
    Transaction, FilteredElementCollector, Material,
    BuiltInCategory, Color as RevitColor, BuiltInParameter
)
from Autodesk.Revit.UI import TaskDialog

# pyRevit imports
from pyrevit import revit

class MaterialCreatorForm(Form):
    
    def __init__(self):
        self.csv_file_path = None
        self.InitializeComponent()
        
    def InitializeComponent(self):
        # Form settings
        self.Text = "Material Creator - Create Materials from CSV"
        self.Size = Size(900, 520)  # Adjusted height to fit all elements
        self.FormBorderStyle = FormBorderStyle.FixedDialog
        self.MaximizeBox = False
        self.MinimizeBox = False
        self.StartPosition = FormStartPosition.CenterScreen
        self.BackColor = Color.FromArgb(245, 245, 245)
        
        # Enable drag and drop (simplified approach)
        try:
            self.AllowDrop = True
            self.DragEnter += self.form_drag_enter
            self.DragDrop += self.form_drag_drop
        except:
            # If drag and drop not supported, just continue without it
            pass
        
        # Title label
        self.title_label = Label()
        self.title_label.Text = "Create Materials from CSV File"
        self.title_label.Font = Font("Arial", 12, FontStyle.Bold)
        self.title_label.Location = Point(20, 20)
        self.title_label.Size = Size(480, 30)
        self.title_label.ForeColor = Color.FromArgb(51, 51, 51)
        
        # Conversion info label - Fixed text overlap
        self.convert_label = Label()
        self.convert_label.Text = "Drag & Drop CSV file here OR Browse to select"
        self.convert_label.Font = Font("Arial", 8, FontStyle.Italic)
        self.convert_label.Location = Point(20, 55)
        self.convert_label.Size = Size(400, 20)
        self.convert_label.ForeColor = Color.FromArgb(100, 100, 100)
        
        # File selection label
        self.file_label = Label()
        self.file_label.Text = "Select CSV File:"
        self.file_label.Font = Font("Arial", 9)
        self.file_label.Location = Point(20, 85)
        self.file_label.Size = Size(120, 20)
        
        # File path textbox
        self.file_textbox = TextBox()
        self.file_textbox.Location = Point(20, 110)
        self.file_textbox.Size = Size(360, 25)
        self.file_textbox.ReadOnly = True
        self.file_textbox.BackColor = Color.White
        
        # Browse button
        self.browse_button = Button()
        self.browse_button.Text = "Browse..."
        self.browse_button.Location = Point(390, 108)
        self.browse_button.Size = Size(100, 28)
        self.browse_button.BackColor = Color.FromArgb(0, 120, 215)
        self.browse_button.ForeColor = Color.White
        self.browse_button.Click += self.browse_button_click
        
        # Info label with better text wrapping
        info_text = "CSV file should contain these columns:\n"
        info_text += "Name, R, G, B, A, Description, Comments, Model, URL, Cost\n\n"
        info_text += "• R, G, B: Color values (0-255)\n"
        info_text += "• A: Alpha/Transparency (0-255)\n"
        info_text += "• First row: column headers\n"
        info_text += "• Values: separated by commas\n"
        info_text += "• Format: CSV UTF-8 recommended"
        
        self.info_label = Label()
        self.info_label.Text = info_text
        self.info_label.Font = Font("Arial", 8)
        self.info_label.Location = Point(20, 155)
        self.info_label.Size = Size(470, 120)
        self.info_label.ForeColor = Color.FromArgb(102, 102, 102)
        
        # CSV Example Header
        self.example_header = Label()
        self.example_header.Text = "CSV File Format Example:"
        self.example_header.Font = Font("Arial", 9, FontStyle.Bold)
        self.example_header.Location = Point(20, 285)
        self.example_header.Size = Size(470, 20)
        self.example_header.ForeColor = Color.FromArgb(51, 51, 51)
        
        # CSV Example Table Panel for better borders
        self.csv_table_panel = Panel()
        self.csv_table_panel.Location = Point(20, 310)
        self.csv_table_panel.Size = Size(470, 55)
        self.csv_table_panel.BorderStyle = BorderStyle.FixedSingle
        self.csv_table_panel.BackColor = Color.White
        
        # CSV Example Table - Header with solid lines
        self.csv_header = Label()
        self.csv_header.Text = "Name          | R   | G   | B   | A   | Description   | Comments     | Model | URL                    | Cost"
        self.csv_header.Font = Font("Consolas", 8, FontStyle.Bold)
        self.csv_header.Location = Point(2, 2)
        self.csv_header.Size = Size(466, 16)
        self.csv_header.ForeColor = Color.FromArgb(255, 255, 255)
        self.csv_header.BackColor = Color.FromArgb(70, 130, 180)
        self.csv_header.BorderStyle = BorderStyle.FixedSingle
        self.csv_table_panel.Controls.Add(self.csv_header)
        
        # CSV Example Table - Row 1 with solid lines
        self.csv_row1 = Label()
        self.csv_row1.Text = "Material-01   | 200 | 201 | 185 | 255 | Description-1 | Comments-1   | 2025  | https://iran-bim.com   | 9,800,000"
        self.csv_row1.Font = Font("Consolas", 8)
        self.csv_row1.Location = Point(2, 18)
        self.csv_row1.Size = Size(466, 16)
        self.csv_row1.ForeColor = Color.FromArgb(51, 51, 51)
        self.csv_row1.BackColor = Color.FromArgb(248, 248, 255)
        self.csv_row1.BorderStyle = BorderStyle.FixedSingle
        self.csv_table_panel.Controls.Add(self.csv_row1)
        
        # CSV Example Table - Row 2 with solid lines
        self.csv_row2 = Label()
        self.csv_row2.Text = "Material-02   | 180 | 190 | 170 | 255 | Description-2 | Comments-2   | 2025  | https://iran-bim.com   | 8,500,000"
        self.csv_row2.Font = Font("Consolas", 8)
        self.csv_row2.Location = Point(2, 34)
        self.csv_row2.Size = Size(466, 16)
        self.csv_row2.ForeColor = Color.FromArgb(51, 51, 51)
        self.csv_row2.BackColor = Color.White
        self.csv_row2.BorderStyle = BorderStyle.FixedSingle
        self.csv_table_panel.Controls.Add(self.csv_row2)
        
        # Preview Panel - Reduced height to make room for buttons
        self.preview_panel = Panel()
        self.preview_panel.Location = Point(520, 20)
        self.preview_panel.Size = Size(360, 350)  # Reduced height from 480 to 350
        self.preview_panel.BackColor = Color.White
        self.preview_panel.BorderStyle = BorderStyle.FixedSingle
        
        # Preview Panel Title
        self.preview_title = Label()
        self.preview_title.Text = "Material Preview"
        self.preview_title.Font = Font("Arial", 10, FontStyle.Bold)
        self.preview_title.Location = Point(80, 5)
        self.preview_title.Size = Size(200, 25)
        self.preview_title.ForeColor = Color.FromArgb(51, 51, 51)
        self.preview_panel.Controls.Add(self.preview_title)
        
        # Preview ListView - Reduced height
        self.preview_list = ListView()
        self.preview_list.Location = Point(5, 35)
        self.preview_list.Size = Size(350, 310)  # Reduced height from 440 to 310
        self.preview_list.View = View.Details
        self.preview_list.FullRowSelect = True
        self.preview_list.GridLines = True
        self.preview_list.Font = Font("Arial", 8)
        
        # Add columns to preview list with better widths
        name_col = ColumnHeader()
        name_col.Text = "Material Name"
        name_col.Width = 100
        self.preview_list.Columns.Add(name_col)
        
        r_col = ColumnHeader()
        r_col.Text = "R"
        r_col.Width = 30
        self.preview_list.Columns.Add(r_col)
        
        g_col = ColumnHeader()
        g_col.Text = "G"
        g_col.Width = 30
        self.preview_list.Columns.Add(g_col)
        
        b_col = ColumnHeader()
        b_col.Text = "B"
        b_col.Width = 30
        self.preview_list.Columns.Add(b_col)
        
        desc_col = ColumnHeader()
        desc_col.Text = "Description"
        desc_col.Width = 90
        self.preview_list.Columns.Add(desc_col)
        
        cost_col = ColumnHeader()
        cost_col.Text = "Cost"
        cost_col.Width = 80
        self.preview_list.Columns.Add(cost_col)
        
        self.preview_panel.Controls.Add(self.preview_list)
        
        # Progress Bar
        self.progress_bar = ProgressBar()
        self.progress_bar.Location = Point(20, 380)
        self.progress_bar.Size = Size(860, 20)  # Slightly thinner
        self.progress_bar.Visible = False
        
        # Status label
        self.status_label = Label()
        self.status_label.Text = "Ready to create materials..."
        self.status_label.Font = Font("Arial", 9)
        self.status_label.Location = Point(20, 410)
        self.status_label.Size = Size(860, 20)
        self.status_label.ForeColor = Color.FromArgb(0, 120, 0)
        
        # Create materials button - Positioned to be visible
        self.create_button = Button()
        self.create_button.Text = "Create Materials"
        self.create_button.Font = Font("Arial", 10, FontStyle.Bold)
        self.create_button.Location = Point(650, 440)  # Moved down to be visible
        self.create_button.Size = Size(130, 35)
        self.create_button.BackColor = Color.FromArgb(0, 150, 0)
        self.create_button.ForeColor = Color.White
        self.create_button.Enabled = False
        self.create_button.Click += self.create_materials_click
        
        # Cancel button - Positioned to be visible
        self.cancel_button = Button()
        self.cancel_button.Text = "Cancel"
        self.cancel_button.Location = Point(790, 440)  # Moved down to be visible
        self.cancel_button.Size = Size(80, 35)  # Slightly wider
        self.cancel_button.BackColor = Color.FromArgb(150, 150, 150)
        self.cancel_button.ForeColor = Color.White
        self.cancel_button.Click += self.cancel_button_click
        
        # Add controls to form
        self.Controls.Add(self.title_label)
        self.Controls.Add(self.convert_label)
        self.Controls.Add(self.file_label)
        self.Controls.Add(self.file_textbox)
        self.Controls.Add(self.browse_button)
        self.Controls.Add(self.info_label)
        self.Controls.Add(self.example_header)
        self.Controls.Add(self.csv_table_panel)  # Add panel instead of individual labels
        self.Controls.Add(self.preview_panel)
        self.Controls.Add(self.progress_bar)
        self.Controls.Add(self.status_label)
        self.Controls.Add(self.create_button)
        self.Controls.Add(self.cancel_button)
        
    def browse_button_click(self, sender, args):
        dialog = OpenFileDialog()
        dialog.Title = "Select CSV File"
        dialog.Filter = "CSV Files (*.csv)|*.csv|Text Files (*.txt)|*.txt|All Files (*.*)|*.*"
        dialog.FilterIndex = 1
        
        if dialog.ShowDialog() == DialogResult.OK:
            self.load_csv_file(dialog.FileName)
    
    def form_drag_enter(self, sender, e):
        """Handle drag enter event"""
        try:
            if hasattr(e.Data, 'GetDataPresent') and e.Data.GetDataPresent("FileDrop"):
                e.Effect = DragDropEffects.Copy
            else:
                e.Effect = DragDropEffects.None
        except:
            e.Effect = DragDropEffects.None
    
    def form_drag_drop(self, sender, e):
        """Handle drag drop event"""
        try:
            if hasattr(e.Data, 'GetData'):
                files = e.Data.GetData("FileDrop")
                if files and len(files) > 0:
                    file_path = str(files[0])
                    file_ext = file_path.lower()
                    
                    if file_ext.endswith('.csv') or file_ext.endswith('.txt'):
                        self.load_csv_file(file_path)
                    else:
                        MessageBox.Show("Please drop a CSV or TXT file.", "Invalid File Type", 
                                      MessageBoxButtons.OK, MessageBoxIcon.Warning)
        except Exception as ex:
            # Silently handle drag drop errors - not critical functionality
            print("Drag drop error: {0}".format(str(ex)))
    
    def load_csv_file(self, file_path):
        """Load and preview CSV file"""
        try:
            self.csv_file_path = file_path
            self.file_textbox.Text = Path.GetFileName(self.csv_file_path)
            self.create_button.Enabled = True
            self.status_label.Text = "File loaded: " + Path.GetFileName(self.csv_file_path)
            self.status_label.ForeColor = Color.FromArgb(0, 120, 0)
            
            # Load preview
            self.load_preview()
        except Exception as e:
            MessageBox.Show("Error loading file:\n{0}".format(str(e)), "Error", 
                          MessageBoxButtons.OK, MessageBoxIcon.Error)
    
    def load_preview(self):
        """Load preview of materials from CSV file"""
        try:
            self.preview_list.Items.Clear()
            
            if not self.csv_file_path or not File.Exists(self.csv_file_path):
                return
            
            # Read and parse CSV for preview
            materials_data = self.read_csv_file(self.csv_file_path)
            
            if not materials_data:
                return
            
            # Add items to preview list - show all materials
            for i, material_data in enumerate(materials_data):
                
                # Create list item with name
                material_name = str(material_data.get('Name', 'N/A'))
                item = ListViewItem(material_name)
                
                # Add RGB values
                r = self.safe_int(material_data.get('R', 128), 128)
                g = self.safe_int(material_data.get('G', 128), 128)
                b = self.safe_int(material_data.get('B', 128), 128)
                
                item.SubItems.Add(str(r))
                item.SubItems.Add(str(g))
                item.SubItems.Add(str(b))
                
                # Add description (better length)
                desc = str(material_data.get('Description', 'N/A'))
                if len(desc) > 15:
                    desc = desc[:15] + "..."
                item.SubItems.Add(desc)
                
                # Add cost with better formatting (without M suffix)
                cost = str(material_data.get('Cost', 'N/A'))
                if cost != 'N/A' and cost:
                    try:
                        # Format as number with thousands separator (no M suffix)
                        cost_num = float(cost)
                        if cost_num >= 1000:
                            cost_formatted = "{:,.0f}".format(cost_num)
                        else:
                            cost_formatted = str(int(cost_num))
                    except:
                        # If not a number, truncate if too long
                        cost_formatted = cost[:12] + "..." if len(cost) > 12 else cost
                else:
                    cost_formatted = "N/A"
                
                item.SubItems.Add(cost_formatted)
                
                # Set background color to approximate material color
                try:
                    # Ensure minimum brightness for readability  
                    display_r = min(255, max(180, r))
                    display_g = min(255, max(180, g))
                    display_b = min(255, max(180, b))
                    item.BackColor = Color.FromArgb(display_r, display_g, display_b)
                    
                    # Always use black text for consistency
                    item.ForeColor = Color.Black
                except:
                    # Default colors if RGB setting fails
                    item.BackColor = Color.FromArgb(240, 240, 240)
                    item.ForeColor = Color.Black
                
                self.preview_list.Items.Add(item)
            
            # Update preview title with count
            total_count = len(materials_data)
            self.preview_title.Text = "Material Preview - {0} Materials Found".format(total_count)
            
            print("Preview loaded: {0} materials".format(total_count))
                
        except Exception as e:
            print("Error loading preview: {0}".format(str(e)))
            MessageBox.Show("Error loading preview:\n{0}".format(str(e)), "Preview Error", 
                          MessageBoxButtons.OK, MessageBoxIcon.Warning)
            
    def cancel_button_click(self, sender, args):
        self.Close()
        
    def create_materials_click(self, sender, args):
        if not self.csv_file_path:
            MessageBox.Show("Please select a CSV file first.", "Error", 
                          MessageBoxButtons.OK, MessageBoxIcon.Error)
            return
            
        if not File.Exists(self.csv_file_path):
            MessageBox.Show("Selected file does not exist.", "Error", 
                          MessageBoxButtons.OK, MessageBoxIcon.Error)
            return
            
        try:
            self.status_label.Text = "Reading CSV file..."
            self.status_label.ForeColor = Color.FromArgb(255, 140, 0)
            Application.DoEvents()
            
            # Read CSV file
            materials_data = self.read_csv_file(self.csv_file_path)
            
            if not materials_data:
                MessageBox.Show("No valid material data found in CSV file.\nPlease check:\n- File has headers in first row\n- File has at least one data row\n- Name column is not empty", "Error", 
                              MessageBoxButtons.OK, MessageBoxIcon.Error)
                self.status_label.Text = "No valid data found in file"
                self.status_label.ForeColor = Color.Red
                return
                
            self.status_label.Text = "Creating materials in Revit..."
            Application.DoEvents()
            
            # Setup progress bar
            self.progress_bar.Minimum = 0
            self.progress_bar.Maximum = len(materials_data)
            self.progress_bar.Value = 0
            self.progress_bar.Visible = True
            Application.DoEvents()
            
            # Create materials in Revit
            success_count = self.create_revit_materials(materials_data)
            
            # Hide progress bar
            self.progress_bar.Visible = False
            
            self.status_label.Text = "Process completed successfully!"
            self.status_label.ForeColor = Color.FromArgb(0, 120, 0)
            
            MessageBox.Show("Process completed successfully!\n\nCreated/Updated: {0} materials from {1} rows.\n\nNote: Existing materials were updated with new parameters.".format(
                success_count, len(materials_data)), 
                "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            
            self.Close()
            
        except Exception as e:
            self.status_label.Text = "Error occurred during process"
            self.status_label.ForeColor = Color.Red
            error_msg = str(e)
            
            # Provide specific help based on error type
            if "encoding" in error_msg.lower():
                error_msg += "\n\nSuggestion: Try saving your Excel file as 'CSV UTF-8' format instead of regular CSV."
            elif "unexpected keyword" in error_msg.lower():
                error_msg += "\n\nThis appears to be a Python syntax error. Please check the script installation."
            
            MessageBox.Show("Error creating materials:\n{0}".format(error_msg), "Error", 
                          MessageBoxButtons.OK, MessageBoxIcon.Error)
    
    def read_csv_file(self, file_path):
        """Read CSV file using .NET StreamReader for IronPython compatibility"""
        try:
            # Try different encodings using .NET StreamReader
            encodings = [Encoding.UTF8, Encoding.Default, Encoding.ASCII]
            
            for encoding in encodings:
                try:
                    print("Trying encoding: {0}".format(encoding.EncodingName))
                    
                    # Read file using .NET StreamReader
                    reader = StreamReader(file_path, encoding)
                    content = reader.ReadToEnd()
                    reader.Close()
                    
                    # Handle different line endings
                    content = content.replace('\r\n', '\n').replace('\r', '\n')
                    lines = content.split('\n')
                    
                    # Remove empty lines
                    lines = [line.strip() for line in lines if line.strip()]
                    
                    if len(lines) < 2:
                        continue  # Try next encoding
                    
                    # Parse header line
                    header_line = lines[0]
                    headers = self.simple_csv_split(header_line)
                    
                    print("Found headers: {0}".format(str(headers)))
                    
                    # Validate required headers
                    if not headers or 'Name' not in headers:
                        continue  # Try next encoding
                    
                    # Parse data lines
                    data = []
                    for line_num, line in enumerate(lines[1:], 2):
                        if not line:
                            continue
                            
                        values = self.simple_csv_split(line)
                        
                        # Create row dictionary
                        row_data = {}
                        has_name = False
                        
                        for i, value in enumerate(values):
                            if i < len(headers) and headers[i]:
                                # Always add the value, even if empty (will be handled as N/A later)
                                row_data[headers[i]] = value if value else ""
                                
                                # Check if this row has a valid Name
                                if headers[i] == 'Name' and value and value.strip():
                                    has_name = True
                        
                        # Only add row if it has a valid Name
                        if has_name and row_data.get('Name', '').strip():
                            data.append(row_data)
                            print("Parsed row {0}: {1}".format(line_num, row_data.get('Name')))
                        else:
                            print("Skipped row {0}: No valid name found".format(line_num))
                    
                    print("Successfully parsed {0} material records".format(len(data)))
                    return data
                    
                except Exception as e:
                    print("Failed with {0}: {1}".format(encoding.EncodingName, str(e)))
                    continue
            
            # If all encodings failed
            raise Exception("Could not read CSV file. Please ensure it's a valid CSV file saved as UTF-8.")
            
        except Exception as e:
            raise Exception("Error reading CSV file: {0}".format(str(e)))
    
    def simple_csv_split(self, line):
        """Simple CSV line splitter for IronPython"""
        # Remove quotes and split by comma
        line = line.strip()
        if line.startswith('"') and line.endswith('"'):
            line = line[1:-1]
        
        # Simple split - works for most cases
        parts = line.split(',')
        result = []
        
        for part in parts:
            part = part.strip()
            # Remove surrounding quotes if present
            if part.startswith('"') and part.endswith('"') and len(part) > 1:
                part = part[1:-1]
            result.append(part)
        
        return result
    
    def create_revit_materials(self, materials_data):
        doc = revit.doc
        success_count = 0
        
        print("=== Starting material creation process ===")
        print("Document: {0}".format(doc.Title if doc else "No Document"))
        print("Total materials to process: {0}".format(len(materials_data)))
        
        if not doc:
            print("ERROR: No active Revit document found!")
            return 0
        
        # Start transaction
        try:
            with revit.Transaction("Create Materials from CSV"):
                print("Transaction started successfully")
                
                for i, material_data in enumerate(materials_data):
                    try:
                        # Update status and progress
                        material_name = str(material_data.get('Name', '')).strip()
                        print("Processing material {0}/{1}: '{2}'".format(i+1, len(materials_data), material_name))
                        
                        self.status_label.Text = "Creating material {0} of {1}: {2}".format(
                            i + 1, len(materials_data), material_name)
                        self.progress_bar.Value = i + 1
                        Application.DoEvents()
                        
                        # Get material name
                        if not material_name or material_name.lower() == 'none':
                            print("Skipping material with no name")
                            continue
                            
                        # Check if material already exists
                        existing_materials = FilteredElementCollector(doc)\
                            .OfCategory(BuiltInCategory.OST_Materials)\
                            .WhereElementIsNotElementType()\
                            .ToElements()
                        
                        existing_material = None
                        for mat in existing_materials:
                            if mat.Name == material_name:
                                existing_material = mat
                                break
                        
                        if existing_material:
                            print("Material '{0}' already exists - updating parameters".format(material_name))
                            material = existing_material
                            # Update existing material
                            update_success = self.update_existing_material(material, material_data, material_name)
                            if update_success:
                                success_count += 1
                                print("Successfully updated existing material: '{0}'".format(material_name))
                            continue
                        
                        # Create new material
                        print("Creating new material: '{0}'".format(material_name))
                        try:
                            material_id = Material.Create(doc, material_name)
                            material = doc.GetElement(material_id)
                            print("New material created successfully with ID: {0}".format(material_id))
                        except Exception as create_error:
                            print("ERROR creating material '{0}': {1}".format(material_name, str(create_error)))
                            continue
                        
                        # Set material properties
                        self.set_new_material_properties(material, material_data, material_name, i)
                        
                        success_count += 1
                        print("Successfully created new material: '{0}'".format(material_name))
                        
                    except Exception as e:
                        print("Error processing material '{0}': {1}".format(
                            material_data.get('Name', 'Unknown'), str(e)))
                        continue
                
                print("Transaction completing...")
            
            print("=== Material creation completed ===")
            print("Successfully processed: {0} materials".format(success_count))
            
        except Exception as transaction_error:
            print("ERROR in transaction: {0}".format(str(transaction_error)))
            success_count = 0
        
        return success_count
    
    def set_new_material_properties(self, material, material_data, material_name, index):
        """Set properties for newly created material"""
        try:
            # Set color
            try:
                r = self.safe_int(material_data.get('R', 128), 128)
                g = self.safe_int(material_data.get('G', 128), 128)
                b = self.safe_int(material_data.get('B', 128), 128)
                
                # Clamp values to 0-255 range
                r = max(0, min(255, r))
                g = max(0, min(255, g))
                b = max(0, min(255, b))
                
                color = RevitColor(r, g, b)
                material.Color = color
                print("Set color for '{0}': R={1}, G={2}, B={3}".format(material_name, r, g, b))
            except Exception as color_error:
                print("Could not set color for '{0}': {1}".format(material_name, str(color_error)))
            
            # Set transparency
            try:
                alpha = self.safe_int(material_data.get('A', 255), 255)
                alpha = max(0, min(255, alpha))
                # Convert from 0-255 to 0-100 transparency
                transparency_percent = int((255 - alpha) * 100.0 / 255.0)
                material.Transparency = transparency_percent
                print("Set transparency for '{0}': {1}% (Alpha: {2})".format(material_name, transparency_percent, alpha))
            except Exception as trans_error:
                print("Could not set transparency for '{0}': {1}".format(material_name, str(trans_error)))
            
            # Set material properties
            try:
                material.Shininess = 50
                material.Smoothness = 50
                print("Set shininess and smoothness for '{0}'".format(material_name))
            except Exception as prop_error:
                print("Could not set material properties for '{0}': {1}".format(material_name, str(prop_error)))
            
            # Set material identity information
            self.set_material_identity_properties(material, material_data, material_name, index)
            
        except Exception as e:
            print("Error setting properties for '{0}': {1}".format(material_name, str(e)))
    
    def set_material_identity_properties(self, material, material_data, material_name, index):
        """Set identity properties for material"""
        try:
            # Description
            description = str(material_data.get('Description', '')).strip()
            if not description:
                description = "N/A"
            try:
                desc_param = material.get_Parameter(BuiltInParameter.ALL_MODEL_DESCRIPTION)
                if desc_param and not desc_param.IsReadOnly:
                    desc_param.Set(description)
                    print("Set description for '{0}': {1}".format(material_name, description))
            except Exception as desc_error:
                print("Could not set description for '{0}': {1}".format(material_name, str(desc_error)))
            
            # Comments - add IRAN-BIM prefix to comments
            comments = str(material_data.get('Comments', '')).strip()
            if not comments:
                comments = "N/A"
            comments = "[IRAN-BIM] " + comments
            try:
                comments_param = material.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)
                if comments_param and not comments_param.IsReadOnly:
                    comments_param.Set(comments)
                    print("Set comments for '{0}': {1}".format(material_name, comments))
            except Exception as comments_error:
                print("Could not set comments for '{0}': {1}".format(material_name, str(comments_error)))
            
            # Model
            model = str(material_data.get('Model', '')).strip()
            if not model:
                model = "N/A"
            try:
                model_param = material.get_Parameter(BuiltInParameter.ALL_MODEL_MODEL)
                if model_param and not model_param.IsReadOnly:
                    model_param.Set(model)
                    print("Set model for '{0}': {1}".format(material_name, model))
            except Exception as model_error:
                print("Could not set model for '{0}': {1}".format(material_name, str(model_error)))
            
            # URL
            url = str(material_data.get('URL', '')).strip()
            if not url:
                url = "N/A"
            try:
                url_param = material.get_Parameter(BuiltInParameter.ALL_MODEL_URL)
                if url_param and not url_param.IsReadOnly:
                    url_param.Set(url)
                    print("Set URL for '{0}': {1}".format(material_name, url))
            except Exception as url_error:
                print("Could not set URL for '{0}': {1}".format(material_name, str(url_error)))
            
            # Cost - enhanced cost setting with debug
            cost = str(material_data.get('Cost', '')).strip()
            if not cost:
                cost = "N/A"
            
            # Debug: Show all available parameters for first material
            if index == 0:  # Only for first material to avoid spam
                self.debug_material_parameters(material, material_name)
            
            cost_set = self.set_material_cost(material, cost, material_name)
            
            # Keywords - add IRAN-BIM to keywords
            keywords = str(material_data.get('Keywords', '')).strip()
            if keywords:
                keywords = "IRAN-BIM, " + keywords
            else:
                keywords = "IRAN-BIM"
            
            try:
                keywords_param = material.get_Parameter(BuiltInParameter.ALL_MODEL_KEYWORDS)
                if keywords_param and not keywords_param.IsReadOnly:
                    keywords_param.Set(keywords)
                    print("Set keywords for '{0}': {1}".format(material_name, keywords))
            except Exception as keywords_error:
                print("Could not set keywords for '{0}': {1}".format(material_name, str(keywords_error)))
                        
        except Exception as e:
            print("Error setting identity properties for '{0}': {1}".format(material_name, str(e)))
    
    def update_existing_material(self, material, material_data, material_name):
        """Update parameters of existing material"""
        try:
            print("=== Updating existing material: '{0}' ===".format(material_name))
            
            # Update color
            try:
                r = self.safe_int(material_data.get('R', 128), 128)
                g = self.safe_int(material_data.get('G', 128), 128)
                b = self.safe_int(material_data.get('B', 128), 128)
                
                # Clamp values to 0-255 range
                r = max(0, min(255, r))
                g = max(0, min(255, g))
                b = max(0, min(255, b))
                
                new_color = RevitColor(r, g, b)
                current_color = material.Color
                
                if (current_color.Red != r or current_color.Green != g or current_color.Blue != b):
                    material.Color = new_color
                    print("Updated color: R={0}, G={1}, B={2}".format(r, g, b))
                else:
                    print("Color unchanged: R={0}, G={1}, B={2}".format(r, g, b))
                    
            except Exception as color_error:
                print("Could not update color for '{0}': {1}".format(material_name, str(color_error)))
            
            # Update transparency
            try:
                alpha = self.safe_int(material_data.get('A', 255), 255)
                alpha = max(0, min(255, alpha))
                # Convert from 0-255 to 0-100 transparency
                new_transparency = int((255 - alpha) * 100.0 / 255.0)
                current_transparency = material.Transparency
                
                if current_transparency != new_transparency:
                    material.Transparency = new_transparency
                    print("Updated transparency: {0}% (Alpha: {1})".format(new_transparency, alpha))
                else:
                    print("Transparency unchanged: {0}%".format(current_transparency))
                    
            except Exception as trans_error:
                print("Could not update transparency for '{0}': {1}".format(material_name, str(trans_error)))
            
            # Update material properties
            try:
                if material.Shininess != 50:
                    material.Shininess = 50
                    print("Updated shininess to 50")
                if material.Smoothness != 50:
                    material.Smoothness = 50
                    print("Updated smoothness to 50")
            except:
                pass
            
            # Update identity information
            self.update_material_identity(material, material_data, material_name)
            
            print("=== Update completed for '{0}' ===".format(material_name))
            return True
            
        except Exception as e:
            print("Error updating material '{0}': {1}".format(material_name, str(e)))
            return False
    
    def update_material_identity(self, material, material_data, material_name):
        """Update identity parameters of material"""
        try:
            # Description
            description = str(material_data.get('Description', '')).strip()
            if not description:
                description = "N/A"
            
            desc_param = material.get_Parameter(BuiltInParameter.ALL_MODEL_DESCRIPTION)
            if desc_param and not desc_param.IsReadOnly:
                current_desc = desc_param.AsString() or ""
                if current_desc != description:
                    desc_param.Set(description)
                    print("Updated description: '{0}'".format(description))
                else:
                    print("Description unchanged: '{0}'".format(description))
            
            # Comments
            comments = str(material_data.get('Comments', '')).strip()
            if not comments:
                comments = "N/A"
            comments = "[IRAN-BIM] " + comments
            
            comments_param = material.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)
            if comments_param and not comments_param.IsReadOnly:
                current_comments = comments_param.AsString() or ""
                if current_comments != comments:
                    comments_param.Set(comments)
                    print("Updated comments: '{0}'".format(comments))
                else:
                    print("Comments unchanged: '{0}'".format(comments))
            
            # Model
            model = str(material_data.get('Model', '')).strip()
            if not model:
                model = "N/A"
            
            model_param = material.get_Parameter(BuiltInParameter.ALL_MODEL_MODEL)
            if model_param and not model_param.IsReadOnly:
                current_model = model_param.AsString() or ""
                if current_model != model:
                    model_param.Set(model)
                    print("Updated model: '{0}'".format(model))
                else:
                    print("Model unchanged: '{0}'".format(model))
            
            # URL
            url = str(material_data.get('URL', '')).strip()
            if not url:
                url = "N/A"
            
            url_param = material.get_Parameter(BuiltInParameter.ALL_MODEL_URL)
            if url_param and not url_param.IsReadOnly:
                current_url = url_param.AsString() or ""
                if current_url != url:
                    url_param.Set(url)
                    print("Updated URL: '{0}'".format(url))
                else:
                    print("URL unchanged: '{0}'".format(url))
            
            # Cost
            cost = str(material_data.get('Cost', '')).strip()
            if not cost:
                cost = "N/A"
            
            # Always try to update cost since it might not have been set before
            cost_updated = self.update_material_cost(material, cost, material_name)
            if cost_updated:
                print("Updated cost: '{0}'".format(cost))
            
            # Keywords
            keywords = str(material_data.get('Keywords', '')).strip()
            if keywords:
                keywords = "IRAN-BIM, " + keywords
            else:
                keywords = "IRAN-BIM"
            
            keywords_param = material.get_Parameter(BuiltInParameter.ALL_MODEL_KEYWORDS)
            if keywords_param and not keywords_param.IsReadOnly:
                current_keywords = keywords_param.AsString() or ""
                if current_keywords != keywords:
                    keywords_param.Set(keywords)
                    print("Updated keywords: '{0}'".format(keywords))
                else:
                    print("Keywords unchanged: '{0}'".format(keywords))
                    
        except Exception as e:
            print("Error updating identity for '{0}': {1}".format(material_name, str(e)))
    
    def update_material_cost(self, material, cost, material_name):
        """Update cost parameter for existing material"""
        try:
            # Check current cost value first
            current_cost = self.get_current_cost(material)
            print("Current cost for '{0}': '{1}', New cost: '{2}'".format(material_name, current_cost, cost))
            
            if current_cost == cost:
                print("Cost unchanged for '{0}'".format(material_name))
                return True
            
            # Try to update cost using the same method as setting
            return self.set_material_cost(material, cost, material_name)
            
        except Exception as e:
            print("Error updating cost for '{0}': {1}".format(material_name, str(e)))
            return False
    
    def get_current_cost(self, material):
        """Get current cost value from material"""
        try:
            # Try to find cost parameters
            all_params = list(material.Parameters)
            for param in all_params:
                try:
                    param_name = param.Definition.Name
                    if 'cost' in param_name.lower():
                        current_value = param.AsString() or param.AsValueString() or ""
                        if current_value:
                            return current_value
                except:
                    continue
            
            # If no cost parameter found, return empty
            return ""
            
        except:
            return ""
    
    def set_material_cost(self, material, cost, material_name):
        """Enhanced cost setting with multiple approaches"""
        try:
            # If cost is N/A, try to set it anyway to show N/A in the field
            if cost == "N/A":
                print("Cost is N/A, will try to set N/A in cost field")
            
            # Try to find Cost parameter by iterating through all parameters
            all_params = list(material.Parameters)
            print("Total parameters found: {0}".format(len(all_params)))
            
            cost_related_params = []
            for param in all_params:
                try:
                    param_name = param.Definition.Name
                    if 'cost' in param_name.lower():
                        cost_related_params.append((param_name, param))
                        print("Found cost parameter: '{0}' (ReadOnly: {1}, StorageType: {2})".format(
                            param_name, param.IsReadOnly, param.StorageType))
                except:
                    continue
            
            # Try to set the most likely Cost parameter
            for param_name, param in cost_related_params:
                if not param.IsReadOnly:
                    try:
                        storage_type = param.StorageType.ToString()
                        print("Trying to set parameter '{0}' with storage type '{1}'".format(param_name, storage_type))
                        
                        if cost == "N/A":
                            # For N/A, always set as string
                            param.Set(cost)
                            print("SUCCESS: Set cost N/A in parameter '{0}'".format(param_name))
                            return True
                        else:
                            # Try to convert to appropriate type
                            if storage_type in ['Double', 'Integer']:
                                try:
                                    if storage_type == 'Double':
                                        cost_value = float(cost)
                                        param.Set(cost_value)
                                    else:
                                        cost_value = int(float(cost))
                                        param.Set(cost_value)
                                    print("SUCCESS: Set cost as {0} in parameter '{1}': {2}".format(storage_type.lower(), param_name, cost_value))
                                    return True
                                except ValueError:
                                    # If can't convert to number, try as string
                                    param.Set(cost)
                                    print("SUCCESS: Set cost as string in parameter '{0}': {1}".format(param_name, cost))
                                    return True
                            else:
                                # String or other type
                                param.Set(cost)
                                print("SUCCESS: Set cost as string in parameter '{0}': {1}".format(param_name, cost))
                                return True
                    except Exception as e:
                        print("Failed to set parameter '{0}': {1}".format(param_name, str(e)))
                        continue
                else:
                    print("Parameter '{0}' is read-only, skipping".format(param_name))
            
            if not cost_related_params:
                print("No cost-related parameters found")
                
        except Exception as e:
            print("Error searching for cost parameters: {0}".format(str(e)))
        
        # Fallback: Try built-in parameters
        try:
            print("Trying built-in cost parameters...")
            builtin_params = [
                ("ALL_MODEL_COST", BuiltInParameter.ALL_MODEL_COST),
            ]
            
            for param_name, param_type in builtin_params:
                try:
                    cost_param = material.get_Parameter(param_type)
                    if cost_param and not cost_param.IsReadOnly:
                        try:
                            if cost == "N/A":
                                cost_param.Set(cost)
                            else:
                                cost_value = float(cost)
                                cost_param.Set(cost_value)
                            print("SUCCESS: Set cost using built-in parameter {0}".format(param_name))
                            return True
                        except:
                            try:
                                cost_param.Set(cost)
                                print("SUCCESS: Set cost as string using built-in parameter {0}".format(param_name))
                                return True
                            except Exception as e:
                                print("Failed built-in parameter {0}: {1}".format(param_name, str(e)))
                except Exception as e:
                    print("Error with built-in parameter {0}: {1}".format(param_name, str(e)))
        except Exception as e:
            print("Error trying built-in parameters: {0}".format(str(e)))
        
        # Final fallback: Add to description
        try:
            print("Final fallback: Adding cost to description...")
            desc_param = material.get_Parameter(BuiltInParameter.ALL_MODEL_DESCRIPTION)
            if desc_param and not desc_param.IsReadOnly:
                current_desc = desc_param.AsString() or ""
                if current_desc and current_desc != "N/A":
                    new_desc = current_desc + " | Cost: " + cost
                else:
                    new_desc = "Cost: " + cost
                desc_param.Set(new_desc)
                print("Added cost to description: {0}".format(new_desc))
                return True
        except Exception as e:
            print("Failed to add cost to description: {0}".format(str(e)))
        
        return False
    
    def debug_material_parameters(self, material, material_name):
        """Debug function to show all available parameters"""
        print("=== DEBUG: All parameters for material '{0}' ===".format(material_name))
        try:
            all_params = material.Parameters
            for i, param in enumerate(all_params):
                try:
                    param_name = param.Definition.Name
                    storage_type = param.StorageType.ToString()
                    is_readonly = param.IsReadOnly
                    print("{0:3d}. {1} (Type: {2}, ReadOnly: {3})".format(i+1, param_name, storage_type, is_readonly))
                    
                    # Show cost-related parameters in detail
                    if 'cost' in param_name.lower():
                        print("     *** COST PARAMETER FOUND: {0} ***".format(param_name))
                except Exception as e:
                    print("{0:3d}. [Error reading parameter: {1}]".format(i+1, str(e)))
            
            print("=== END DEBUG ===")
        except Exception as e:
            print("Error in debug function: {0}".format(str(e)))
    
    def safe_int(self, value, default):
        """Safely convert value to integer"""
        try:
            if value is None or value == '':
                return default
            # Remove any quotes and convert
            value = str(value).strip().strip('"').strip("'")
            return int(float(value))
        except:
            return default

def main():
    try:
        # Create and show form
        Application.EnableVisualStyles()
        form = MaterialCreatorForm()
        form.ShowDialog()
    except Exception as e:
        TaskDialog.Show("Error", "Error starting application:\n{0}".format(str(e)))

# Run script
if __name__ == '__main__':
    main()