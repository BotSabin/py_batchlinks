# -*- coding: utf-8 -*-

from pyrevit import revit, DB, forms, script
from Autodesk.Revit.DB import *
from pyrevit.forms import WPFWindow
import os
import clr
clr.AddReference('System.Windows.Forms')
from System.Windows.Forms import DialogResult

# -----------------------
# Enhanced Categories List
# -----------------------
target_categories = {
    "Air Terminals": BuiltInCategory.OST_DuctTerminal,
    "Audio Visual Devices": BuiltInCategory.OST_AudioVisualDevices,
    "Cable Tray Fittings": BuiltInCategory.OST_CableTrayFitting,
    "Cable Trays": BuiltInCategory.OST_CableTray,
    "Casework": BuiltInCategory.OST_Casework,
    "Ceilings": BuiltInCategory.OST_Ceilings,
    "Columns": BuiltInCategory.OST_Columns,
    "Communication Devices": BuiltInCategory.OST_CommunicationDevices,
    "Conduit Fittings": BuiltInCategory.OST_ConduitFitting,
    "Conduits": BuiltInCategory.OST_Conduit,
    "Curtain Panels": BuiltInCategory.OST_CurtainWallPanels,
    "Curtain Wall Mullions": BuiltInCategory.OST_CurtainWallMullions,
    "Data Devices": BuiltInCategory.OST_DataDevices,
    "Doors": BuiltInCategory.OST_Doors,
    "Duct Accessories": BuiltInCategory.OST_DuctAccessory,
    "Duct Fittings": BuiltInCategory.OST_DuctFitting,
    "Ducts": BuiltInCategory.OST_DuctCurves,
    "Electrical Equipment": BuiltInCategory.OST_ElectricalEquipment,
    "Electrical Fixtures": BuiltInCategory.OST_ElectricalFixtures,
    "Fire Alarm Devices": BuiltInCategory.OST_FireAlarmDevices,
    "Fire Protection": BuiltInCategory.OST_FireProtection,
    "Flex Ducts": BuiltInCategory.OST_FlexDuctCurves,
    "Flex Pipes": BuiltInCategory.OST_FlexPipeCurves,
    "Floors": BuiltInCategory.OST_Floors,
    "Food Service Equipment": BuiltInCategory.OST_FoodServiceEquipment,
    "Furniture": BuiltInCategory.OST_Furniture,
    "Furniture Systems": BuiltInCategory.OST_FurnitureSystems,
    "Generic Models": BuiltInCategory.OST_GenericModel,
    "Lighting Devices": BuiltInCategory.OST_LightingDevices,
    "Lighting Fixtures": BuiltInCategory.OST_LightingFixtures,
    "Mechanical Equipment": BuiltInCategory.OST_MechanicalEquipment,
    "Mechanical Control Devices": BuiltInCategory.OST_MechanicalControlDevices,
    "Medical Equipment": BuiltInCategory.OST_MedicalEquipment,
    "MEP Ancillary Framing": BuiltInCategory.OST_MEPAncillaryFraming,
    "Nurse Call Devices": BuiltInCategory.OST_NurseCallDevices,
    "Pipe Accessories": BuiltInCategory.OST_PipeAccessory,
    "Pipe Fittings": BuiltInCategory.OST_PipeFitting,
    "Pipes": BuiltInCategory.OST_PipeCurves,
    "Plumbing Equipment": BuiltInCategory.OST_PlumbingEquipment,
    "Plumbing Fixtures": BuiltInCategory.OST_PlumbingFixtures,
    "Railings": BuiltInCategory.OST_Railings,
    "Ramps": BuiltInCategory.OST_Ramps,
    "Roofs": BuiltInCategory.OST_Roofs,
    "Security Devices": BuiltInCategory.OST_SecurityDevices,
    "Specialty Equipment": BuiltInCategory.OST_SpecialityEquipment,
    "Sprinklers": BuiltInCategory.OST_Sprinklers,
    "Stairs": BuiltInCategory.OST_Stairs,
    "Structural Columns": BuiltInCategory.OST_StructuralColumns,
    "Structural Connections": BuiltInCategory.OST_StructConnections,
    "Structural Foundations": BuiltInCategory.OST_StructuralFoundation,
    "Structural Framing": BuiltInCategory.OST_StructuralFraming,
    "Structural Trusses": BuiltInCategory.OST_StructuralTruss,
    "Telephone Devices": BuiltInCategory.OST_TelephoneDevices,
    "Walls": BuiltInCategory.OST_Walls,
    "Windows": BuiltInCategory.OST_Windows
}

# -----------------------
# Enhanced Color Scheme
# -----------------------
colors = {
    "removed": DB.Color(220, 53, 69),       # Strong Red - Elements removed from current
    "added": DB.Color(40, 167, 69),         # Strong Green - Elements added to current
    "geometry_changed": DB.Color(255, 193, 7),   # Bright Yellow - Geometry differences
    "parameters_changed": DB.Color(23, 162, 184), # Cyan - Parameter differences
    "identical": DB.Color(108, 117, 125),    # Gray - No changes
    "link_highlight": DB.Color(255, 140, 0), # Orange - Highlight link elements
}

# -----------------------
# Utility Functions
# -----------------------
def get_solid_fill_pattern():
    """Get solid fill pattern with better error handling"""
    try:
        collector = FilteredElementCollector(revit.doc).OfClass(FillPatternElement)
        for fp in collector:
            if fp.GetFillPattern().IsSolidFill:
                return fp.Id
    except:
        pass
    return ElementId.InvalidElementId

def create_enhanced_override(color, transparency=0, line_weight=3, use_pattern=True):
    """Create enhanced graphic override settings"""
    ogs = OverrideGraphicSettings()
    fill_id = get_solid_fill_pattern() if use_pattern else ElementId.InvalidElementId
    
    # Surface settings
    ogs.SetSurfaceForegroundPatternColor(color)
    if fill_id != ElementId.InvalidElementId and use_pattern:
        ogs.SetSurfaceForegroundPatternId(fill_id)
    ogs.SetSurfaceTransparency(transparency)
    
    # Line settings with weight
    ogs.SetProjectionLineColor(color)
    ogs.SetProjectionLineWeight(line_weight)
    ogs.SetCutLineColor(color)
    ogs.SetCutLineWeight(line_weight)
    
    return ogs

def apply_override_to_element(element_id, color, transparency=0, line_weight=3):
    """Apply override to current model element"""
    try:
        ogs = create_enhanced_override(color, transparency, line_weight)
        revit.doc.ActiveView.SetElementOverrides(element_id, ogs)
        return True
    except Exception as e:
        print("Error applying override to element {}: {}".format(element_id, str(e)))
        return False

def apply_override_to_link_element(link_instance, element_id, color, transparency=0, line_weight=3):
    """Apply override to linked model element - Enhanced method"""
    try:
        # Create override for the linked element
        ogs = create_enhanced_override(color, transparency, line_weight, use_pattern=True)
        
        # Method 1: Try to override the link instance itself for the specific element
        try:
            # Create a reference to the linked element
            reference = Reference(element_id)
            linkRef = reference.CreateLinkInstanceReference(link_instance)
            if linkRef:
                revit.doc.ActiveView.SetElementOverrides(linkRef.ElementId, ogs)
                return True
        except:
            pass
        
        # Method 2: Override by category in link
        try:
            # Get the linked document and element
            linked_doc = link_instance.GetLinkDocument()
            if linked_doc:
                linked_element = linked_doc.GetElement(element_id)
                if linked_element:
                    # Apply override using link transform
                    revit.doc.ActiveView.SetElementOverrides(element_id, ogs)
        except:
            pass
        
        # Method 3: Apply to link instance with category filter
        try:
            link_ogs = create_enhanced_override(color, transparency + 10, line_weight - 1)
            revit.doc.ActiveView.SetElementOverrides(link_instance.Id, link_ogs)
        except:
            pass
            
        return True
    except Exception as e:
        print("Error applying override to linked element {}: {}".format(element_id, str(e)))
        return False

# -----------------------
# Link Selection Dialog
# -----------------------
def show_link_selection_dialog():
    """Show enhanced dialog for link selection"""
    doc = revit.doc
    
    # Find link instances with better filtering
    link_instances = FilteredElementCollector(doc).OfClass(RevitLinkInstance).ToElements()
    
    if not link_instances:
        forms.alert("⚠️ No Linked Models Found", 
                   "No linked Revit models found in the current project!\n\n" +
                   "Please load a linked model first and try again.")
        return None
    
    # Prepare link options with detailed info
    link_options = []
    for link_instance in link_instances:
        try:
            link_name = link_instance.Name
            link_doc = link_instance.GetLinkDocument()
            status = "✅ Loaded" if link_doc else "❌ Unloaded"
            
            if link_name:
                display_name = "{} - {}".format(link_name, status)
                link_options.append({
                    'name': display_name,
                    'instance': link_instance,
                    'loaded': link_doc is not None,
                    'doc': link_doc
                })
        except Exception as e:
            print("Error processing link: {}".format(str(e)))
            continue
    
    if not link_options:
        forms.alert("⚠️ No Valid Links", 
                   "No valid linked models found!\n\n" +
                   "Make sure your linked models are properly loaded.")
        return None
    
    # Filter loaded links
    loaded_links = [opt for opt in link_options if opt['loaded']]
    
    if not loaded_links:
        forms.alert("⚠️ No Loaded Links", 
                   "Found linked models but none are loaded!\n\n" +
                   "Please load the linked models and try again.")
        return None
    
    # Show selection dialog
    if len(loaded_links) == 1:
        selected_option = loaded_links[0]
        result = forms.alert("🔗 Link Found", 
                           "Found one loaded link:\n{}\n\nProceed with comparison?".format(selected_option['name']),
                           options=["Yes", "Cancel"])
        if result == "Yes":
            return selected_option
        else:
            return None
    else:
        # Multiple links - show selection
        link_names = [opt['name'] for opt in loaded_links]
        selected_name = forms.SelectFromList.show(
            link_names,
            title="🏗️ Select Linked Model for Comparison",
            button_name="🔍 Start Comparison",
            message="Choose the linked model to compare with the current model:"
        )
        
        if selected_name:
            return next(opt for opt in loaded_links if opt['name'] == selected_name)
    
    return None

# -----------------------
# Improved Geometry Extraction
# -----------------------
def get_element_geometry_data(element):
    """Extract comprehensive geometry data from element"""
    try:
        options = Options()
        options.ComputeReferences = True
        options.DetailLevel = ViewDetailLevel.Fine
        
        geom = element.get_Geometry(options)
        if not geom:
            return None
            
        solids = []
        total_volume = 0
        bounding_box = None
        
        for geom_obj in geom:
            if isinstance(geom_obj, Solid) and geom_obj.Volume > 0:
                solids.append(geom_obj)
                total_volume += geom_obj.Volume
                if bounding_box is None:
                    bounding_box = geom_obj.GetBoundingBox()
                    
            elif isinstance(geom_obj, GeometryInstance):
                # Handle family instances
                inst_geom = geom_obj.GetInstanceGeometry()
                if inst_geom:
                    for inst_obj in inst_geom:
                        if isinstance(inst_obj, Solid) and inst_obj.Volume > 0:
                            solids.append(inst_obj)
                            total_volume += inst_obj.Volume
                            if bounding_box is None:
                                bounding_box = inst_obj.GetBoundingBox()
        
        if solids:
            return {
                'solids': solids,
                'volume': total_volume,
                'bbox': bounding_box,
                'primary_solid': solids[0] if solids else None
            }
        
        # Fallback for elements without solid geometry
        if bounding_box or hasattr(element, 'Location'):
            return {
                'solids': [],
                'volume': 0,
                'bbox': bounding_box,
                'primary_solid': None,
                'location': getattr(element, 'Location', None)
            }
            
    except Exception as e:
        print("Error extracting geometry from element {}: {}".format(element.Id, str(e)))
    
    return None

# -----------------------
# Enhanced Element Collection
# -----------------------
def collect_elements_by_category(document, built_in_category):
    """Collect elements with enhanced data"""
    elements_data = {}
    
    try:
        collector = FilteredElementCollector(document).OfCategory(built_in_category)
        collector = collector.WhereElementIsNotElementType()
        
        for element in collector:
            try:
                # Get geometry data
                geom_data = get_element_geometry_data(element)
                if geom_data is None:
                    continue
                
                # Get key parameters
                key_params = {}
                for param in element.Parameters:
                    try:
                        if param.HasValue and not param.IsReadOnly:
                            param_name = param.Definition.Name
                            if param.StorageType == StorageType.String:
                                param_value = param.AsString()
                            elif param.StorageType == StorageType.Double:
                                param_value = param.AsValueString() or str(param.AsDouble())
                            elif param.StorageType == StorageType.Integer:
                                param_value = str(param.AsInteger())
                            else:
                                param_value = param.AsValueString()
                            
                            if param_value:
                                key_params[param_name] = param_value
                    except:
                        continue
                
                elements_data[element.UniqueId] = {
                    'element': element,
                    'geometry': geom_data,
                    'parameters': key_params,
                    'category': built_in_category
                }
                
            except Exception as e:
                print("Error processing element {}: {}".format(element.Id, str(e)))
                continue
                
    except Exception as e:
        print("Error collecting category {}: {}".format(built_in_category, str(e)))
    
    return elements_data

# -----------------------
# Advanced Comparison Functions
# -----------------------
def compare_geometry(geom1, geom2, tolerance=0.01):
    """Compare geometry with better tolerance handling"""
    try:
        if not geom1['primary_solid'] or not geom2['primary_solid']:
            # Compare volumes if no solid geometry
            vol_diff = abs(geom1['volume'] - geom2['volume'])
            return vol_diff < tolerance
        
        # Volume comparison first (quick check)
        vol_diff = abs(geom1['volume'] - geom2['volume'])
        if vol_diff > tolerance:
            return False
            
        # Boolean difference for detailed comparison
        try:
            solid1 = geom1['primary_solid']
            solid2 = geom2['primary_solid']
            
            diff = BooleanOperationsUtils.ExecuteBooleanOperation(
                solid1, solid2, BooleanOperationsType.Difference
            )
            
            return diff.Volume <= tolerance
            
        except:
            # Fallback to bounding box comparison
            if geom1['bbox'] and geom2['bbox']:
                bb1, bb2 = geom1['bbox'], geom2['bbox']
                min_diff = (bb1.Min - bb2.Min).GetLength()
                max_diff = (bb1.Max - bb2.Max).GetLength()
                return min_diff < tolerance and max_diff < tolerance
            
    except Exception as e:
        print("Geometry comparison error: {}".format(str(e)))
    
    return False

def compare_parameters(params1, params2, ignore_params=None):
    """Compare parameters with ignore list"""
    if ignore_params is None:
        ignore_params = ['Element ID', 'Level', 'Phase Created', 'Phase Demolished', 'Mark']
    
    # Get significant parameters (exclude auto-generated ones)
    significant_params1 = {k: v for k, v in params1.items() 
                          if k not in ignore_params and v is not None}
    significant_params2 = {k: v for k, v in params2.items() 
                          if k not in ignore_params and v is not None}
    
    # Check if any significant parameter differs
    for param_name, value1 in significant_params1.items():
        value2 = significant_params2.get(param_name)
        if value2 is None or str(value1) != str(value2):
            return False
    
    for param_name, value2 in significant_params2.items():
        if param_name not in significant_params1:
            return False
    
    return True

# -----------------------
# Progress Display
# -----------------------
def show_progress(current, total, category_name):
    """Show progress in output"""
    percentage = int((current / float(total)) * 100)
    bar_length = 30
    filled_length = int(bar_length * current / total)
    bar = '█' * filled_length + '░' * (bar_length - filled_length)
    
    print("Progress: [{}] {}% - Processing: {}".format(bar, percentage, category_name))

# -----------------------
# Main Comparison Logic
# -----------------------
def run_comparison():
    """Main comparison function with better error handling"""
    
    # Show link selection dialog
    selected_link = show_link_selection_dialog()
    if not selected_link:
        return
    
    selected_link_instance = selected_link['instance']
    linked_doc = selected_link['doc']
    
    # Get document and links
    doc = revit.doc
    
    # Initialize report
    report_data = []
    total_counts = {"removed": 0, "added": 0, "geometry_changed": 0, "parameters_changed": 0, "identical": 0}
    
    # Start transaction
    with revit.Transaction("Enhanced Model Comparison"):
        
        # Clear existing overrides
        try:
            print("🧹 Clearing existing overrides...")
            for element_id in FilteredElementCollector(doc).ToElementIds():
                doc.ActiveView.SetElementOverrides(element_id, OverrideGraphicSettings())
            
            # Clear link overrides
            for link_id in FilteredElementCollector(doc).OfClass(RevitLinkInstance).ToElementIds():
                doc.ActiveView.SetElementOverrides(link_id, OverrideGraphicSettings())
                
        except Exception as e:
            print("Warning: Could not clear all overrides: {}".format(str(e)))
        
        # Process each category
        progress_count = 0
        total_categories = len(target_categories)
        
        print("\n🔍 Starting comparison analysis...")
        print("📊 Processing {} categories...".format(total_categories))
        
        for category_name, built_in_category in target_categories.items():
            progress_count += 1
            show_progress(progress_count, total_categories, category_name)
            
            try:
                # Collect elements from both models
                current_elements = collect_elements_by_category(doc, built_in_category)
                linked_elements = collect_elements_by_category(linked_doc, built_in_category)
                
                category_counts = {"removed": 0, "added": 0, "geometry_changed": 0, "parameters_changed": 0, "identical": 0}
                
                # Find removed elements (in link but not in current)
                for uid in linked_elements:
                    if uid not in current_elements:
                        linked_element = linked_elements[uid]['element']
                        apply_override_to_link_element(
                            selected_link_instance, 
                            linked_element.Id, 
                            colors["removed"], 
                            transparency=0, 
                            line_weight=5
                        )
                        category_counts["removed"] += 1
                
                # Find added elements (in current but not in link)
                for uid in current_elements:
                    if uid not in linked_elements:
                        current_element = current_elements[uid]['element']
                        apply_override_to_element(
                            current_element.Id, 
                            colors["added"], 
                            transparency=0, 
                            line_weight=4
                        )
                        category_counts["added"] += 1
                
                # Compare existing elements
                for uid in current_elements:
                    if uid in linked_elements:
                        current_data = current_elements[uid]
                        linked_data = linked_elements[uid]
                        
                        current_element = current_data['element']
                        linked_element = linked_data['element']
                        
                        # Compare geometry
                        geometry_same = compare_geometry(
                            current_data['geometry'], 
                            linked_data['geometry']
                        )
                        
                        if not geometry_same:
                            # Geometry changed
                            apply_override_to_element(
                                current_element.Id, 
                                colors["geometry_changed"], 
                                transparency=0, 
                                line_weight=4
                            )
                            apply_override_to_link_element(
                                selected_link_instance, 
                                linked_element.Id, 
                                colors["geometry_changed"], 
                                transparency=20, 
                                line_weight=4
                            )
                            category_counts["geometry_changed"] += 1
                        else:
                            # Check parameters
                            params_same = compare_parameters(
                                current_data['parameters'], 
                                linked_data['parameters']
                            )
                            
                            if not params_same:
                                # Parameters changed
                                apply_override_to_element(
                                    current_element.Id, 
                                    colors["parameters_changed"], 
                                    transparency=0, 
                                    line_weight=3
                                )
                                apply_override_to_link_element(
                                    selected_link_instance, 
                                    linked_element.Id, 
                                    colors["parameters_changed"], 
                                    transparency=30, 
                                    line_weight=3
                                )
                                category_counts["parameters_changed"] += 1
                            else:
                                # Identical elements - make them semi-transparent
                                apply_override_to_element(
                                    current_element.Id, 
                                    colors["identical"], 
                                    transparency=70, 
                                    line_weight=1
                                )
                                apply_override_to_link_element(
                                    selected_link_instance, 
                                    linked_element.Id, 
                                    colors["identical"], 
                                    transparency=80, 
                                    line_weight=1
                                )
                                category_counts["identical"] += 1
                
                # Add to report
                if sum(category_counts.values()) > 0:
                    report_data.append((category_name, category_counts))
                    for key in total_counts:
                        total_counts[key] += category_counts[key]
                        
            except Exception as e:
                print("❌ Error processing category {}: {}".format(category_name, str(e)))
                continue
    
    print("\n✅ Analysis completed!")
    
    # Generate enhanced report
    generate_enhanced_report(report_data, total_counts, selected_link['name'])

# -----------------------
# Enhanced Report Generation
# -----------------------
def generate_enhanced_report(report_data, total_counts, link_name):
    """Generate a comprehensive comparison report"""
    
    output = script.get_output()
    output.set_title("🔍 Enhanced Model Comparison Results")
    
    # Enhanced Header with icons and styling
    output.print_md("# 🏗️ Advanced Model Comparison Analysis")
    output.print_md("---")
    
    # Model Information Box
    output.print_md("## 📋 Project Information")
    output.print_md("""
<div style="background-color: #f8f9fa; padding: 15px; border-left: 4px solid #007bff; margin: 10px 0;">
<strong>📁 Current Model:</strong> <code>{}</code><br>
<strong>🔗 Linked Model:</strong> <code>{}</code><br>
<strong>📅 Analysis Date:</strong> <code>{}</code>
</div>
    """.format(revit.doc.Title, link_name.replace(" - ✅ Loaded", ""), 
               str(System.DateTime.Now.ToString("yyyy-MM-dd HH:mm"))))
    
    # Enhanced Color legend with visual indicators
    output.print_md("## 🎨 Visual Color Legend")
    output.print_md("""
<table style="width: 100%; border-collapse: collapse;">
<tr style="background-color: #f8f9fa;">
    <th style="padding: 10px; text-align: left;">Status</th>
    <th style="padding: 10px; text-align: left;">Color Indicator</th>
    <th style="padding: 10px; text-align: left;">Description</th>
    <th style="padding: 10px; text-align: left;">Action Required</th>
</tr>
<tr>
    <td style="padding: 8px;"><strong>🟢 Added Elements</strong></td>
    <td style="padding: 8px; background-color: #28a745; color: white; text-align: center;"><strong>GREEN</strong></td>
    <td style="padding: 8px;">Elements only in current model</td>
    <td style="padding: 8px;">New elements added since link</td>
</tr>
<tr style="background-color: #f8f9fa;">
    <td style="padding: 8px;"><strong>🔴 Removed Elements</strong></td>
    <td style="padding: 8px; background-color: #dc3545; color: white; text-align: center;"><strong>RED</strong></td>
    <td style="padding: 8px;">Elements only in linked model</td>
    <td style="padding: 8px;">Elements deleted from current</td>
</tr>
<tr>
    <td style="padding: 8px;"><strong>🟡 Geometry Changed</strong></td>
    <td style="padding: 8px; background-color: #ffc107; text-align: center;"><strong>YELLOW</strong></td>
    <td style="padding: 8px;">Same element, different geometry</td>
    <td style="padding: 8px;">Review geometric modifications</td>
</tr>
<tr style="background-color: #f8f9fa;">
    <td style="padding: 8px;"><strong>🔵 Parameters Changed</strong></td>
    <td style="padding: 8px; background-color: #17a2b8; color: white; text-align: center;"><strong>CYAN</strong></td>
    <td style="padding: 8px;">Same geometry, different parameters</td>
    <td style="padding: 8px;">Check parameter modifications</td>
</tr>
<tr>
    <td style="padding: 8px;"><strong>⚪ Identical Elements</strong></td>
    <td style="padding: 8px; background-color: #6c757d; color: white; text-align: center;"><strong>GRAY</strong></td>
    <td style="padding: 8px;">No differences detected</td>
    <td style="padding: 8px;">No action needed</td>
</tr>
</table>
    """)
    
    # Overall summary with enhanced metrics
    total_elements = sum(total_counts.values())
    if total_elements > 0:
        output.print_md("---")
        output.print_md("## 📊 Executive Summary")
        
        changes_count = total_elements - total_counts["identical"]
        change_percentage = (changes_count / float(total_elements)) * 100
        
        output.print_md("""
<div style="display: flex; flex-wrap: wrap; gap: 15px; margin: 20px 0;">
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; min-width: 200px;">
        <h3 style="margin: 0; font-size: 24px;">📈 {}</h3>
        <p style="margin: 5px 0 0 0;">Total Elements Analyzed</p>
    </div>
    <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 20px; border-radius: 10px; min-width: 200px;">
        <h3 style="margin: 0; font-size: 24px;">⚡ {}</h3>
        <p style="margin: 5px 0 0 0;">Elements with Changes</p>
    </div>
    <div style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; padding: 20px; border-radius: 10px; min-width: 200px;">
        <h3 style="margin: 0; font-size: 24px;">📊 {:.1f}%</h3>
        <p style="margin: 5px 0 0 0;">Change Percentage</p>
    </div>
</div>
        """.format(total_elements, changes_count, change_percentage))
        
        # Detailed breakdown with progress bars
        output.print_md("### 📈 Detailed Breakdown")
        
        for status, count in total_counts.items():
            if count > 0:
                percentage = (count / float(total_elements)) * 100
                bar_width = int(percentage * 3)  # Scale for visual bar
                
                status_icons = {
                    "added": "🟢", 
                    "removed": "🔴", 
                    "geometry_changed": "🟡",
                    "parameters_changed": "🔵", 
                    "identical": "⚪"
                }
                
                status_colors = {
                    "added": "#28a745", 
                    "removed": "#dc3545", 
                    "geometry_changed": "#ffc107",
                    "parameters_changed": "#17a2b8", 
                    "identical": "#6c757d"
                }
                
                status_display = status.replace("_", " ").title()
                status_icon = status_icons.get(status, "•")
                status_color = status_colors.get(status, "#6c757d")
                
                output.print_md("""
<div style="margin: 10px 0; padding: 10px; border-left: 4px solid {};">
    <strong>{} {}</strong>: {} elements ({:.1f}%)<br>
    <div style="background-color: #f8f9fa; height: 20px; border-radius: 10px; overflow: hidden; margin-top: 5px;">
        <div style="background-color: {}; height: 100%; width: {}%; transition: width 0.3s ease;"></div>
    </div>
</div>
                """.format(status_color, status_icon, status_display, count, percentage, status_color, percentage))
    
    # Detailed category breakdown with enhanced tables
    if report_data:
        output.print_md("---")
        output.print_md("## 📂 Detailed Category Analysis")
        
        # Sort by total changes (most changed first)
        sorted_report = sorted(report_data, 
                             key=lambda x: sum(x[1].values()) - x[1]["identical"], 
                             reverse=True)
        
        # Categories with changes
        categories_with_changes = [(cat, counts) for cat, counts in sorted_report 
                                 if sum(counts.values()) - counts["identical"] > 0]
        
        if categories_with_changes:
            output.print_md("### 🔥 Categories with Most Changes")
            
            output.print_md("""
<table style="width: 100%; border-collapse: collapse; margin: 15px 0;">
<tr style="background-color: #343a40; color: white;">
    <th style="padding: 12px; text-align: left;">Category</th>
    <th style="padding: 12px; text-align: center;">🟢 Added</th>
    <th style="padding: 12px; text-align: center;">🔴 Removed</th>
    <th style="padding: 12px; text-align: center;">🟡 Geometry</th>
    <th style="padding: 12px; text-align: center;">🔵 Parameters</th>
    <th style="padding: 12px; text-align: center;">⚪ Identical</th>
    <th style="padding: 12px; text-align: center;">📊 Total</th>
</tr>
            """)
            
            row_style_toggle = True
            for category_name, counts in categories_with_changes[:15]:  # Top 15 categories
                total_cat = sum(counts.values())
                changes = total_cat - counts["identical"]
                
                if changes > 0:
                    bg_color = "#f8f9fa" if row_style_toggle else "#ffffff"
                    row_style_toggle = not row_style_toggle
                    
                    output.print_md("""
<tr style="background-color: {};">
    <td style="padding: 10px; font-weight: bold;">{}</td>
    <td style="padding: 10px; text-align: center;">{}</td>
    <td style="padding: 10px; text-align: center;">{}</td>
    <td style="padding: 10px; text-align: center;">{}</td>
    <td style="padding: 10px; text-align: center;">{}</td>
    <td style="padding: 10px; text-align: center;">{}</td>
    <td style="padding: 10px; text-align: center; font-weight: bold;">{}</td>
</tr>
                    """.format(bg_color, category_name, 
                              counts["added"], counts["removed"], 
                              counts["geometry_changed"], counts["parameters_changed"],
                              counts["identical"], total_cat))
            
            output.print_md("</table>")
        
        # Categories without changes
        categories_no_changes = [cat for cat, counts in sorted_report 
                               if sum(counts.values()) - counts["identical"] == 0 and counts["identical"] > 0]
        
        if categories_no_changes:
            output.print_md("### ✅ Categories with No Changes")
            categories_text = ", ".join(categories_no_changes[:10])
            if len(categories_no_changes) > 10:
                categories_text += " and {} more...".format(len(categories_no_changes) - 10)
            
            output.print_md("""
<div style="background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0;">
    <strong>📋 Categories with identical elements:</strong><br>
    {}
</div>
            """.format(categories_text))
    
    # Action recommendations
    output.print_md("---")
    output.print_md("## 🎯 Recommended Actions")
    
    recommendations = []
    
    if total_counts["removed"] > 0:
        recommendations.append("🔴 **Review Removed Elements**: {} elements were deleted from the current model. Verify if these deletions were intentional.".format(total_counts["removed"]))
    
    if total_counts["added"] > 0:
        recommendations.append("🟢 **Document New Elements**: {} new elements were added. Update project documentation and schedules accordingly.".format(total_counts["added"]))
    
    if total_counts["geometry_changed"] > 0:
        recommendations.append("🟡 **Verify Geometry Changes**: {} elements have geometric modifications. Check if these align with design intent.".format(total_counts["geometry_changed"]))
    
    if total_counts["parameters_changed"] > 0:
        recommendations.append("🔵 **Review Parameter Updates**: {} elements have parameter changes. Ensure data consistency across the project.".format(total_counts["parameters_changed"]))
    
    if not recommendations:
        recommendations.append("✅ **No Action Required**: All elements are identical between models.")
    
    for i, rec in enumerate(recommendations, 1):
        output.print_md("{}. {}".format(i, rec))
    
    # Footer with enhanced styling
    output.print_md("---")
    output.print_md("""
<div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; text-align: center; margin: 20px 0;">
    <h3 style="margin: 0;">✅ Comparison Analysis Complete!</h3>
    <p style="margin: 10px 0 0 0;">Check your 3D view to see the color-coded comparison results.<br>
    Use the legend above to understand what each color represents.</p>
</div>
    """)
    
    # Technical details
    output.print_md("""
<details style="margin: 20px 0;">
<summary style="cursor: pointer; font-weight: bold; padding: 10px; background-color: #f8f9fa; border-radius: 5px;">🔧 Technical Details</summary>
<div style="padding: 15px; background-color: #f8f9fa; margin-top: 5px; border-radius: 0 0 5px 5px;">
    <strong>Analysis Method:</strong> Advanced geometry and parameter comparison<br>
    <strong>Geometry Tolerance:</strong> 0.01 units<br>
    <strong>Categories Analyzed:</strong> {} categories<br>
    <strong>Comparison Algorithm:</strong> Boolean operations with fallback to bounding box comparison<br>
    <strong>Parameter Filtering:</strong> Excludes auto-generated parameters (Element ID, Phase, etc.)
</div>
</details>
    """.format(len(target_categories)))

# -----------------------
# Execute Main Function
# -----------------------
if __name__ == "__main__":
    try:
        print("🚀 Starting Enhanced Model Comparison Tool...")
        print("=" * 50)
        run_comparison()
        print("=" * 50)
        print("🎉 Comparison completed successfully!")
    except Exception as e:
        error_msg = "❌ An error occurred during comparison: {}".format(str(e))
        print(error_msg)
        forms.alert("Comparison Error", error_msg)