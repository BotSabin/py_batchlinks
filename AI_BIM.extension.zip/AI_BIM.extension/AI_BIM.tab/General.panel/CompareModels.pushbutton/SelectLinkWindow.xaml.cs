def Select_Click(sender, e):
    selected = LinkList.SelectedItem
    if selected:
        this.SelectedItem = selected
        this.Close()
