# -*- coding: utf-8 -*-

from pyrevit import forms, script
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
import clr

# Add Windows Forms references
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')

from System.Windows.Forms import *
from System.Drawing import Color as DrawingColor, Font, FontStyle, Size, Point
import System

# Get current document
doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# -----------------------
# Categories List
# -----------------------
target_categories = {
    "Walls": BuiltInCategory.OST_Walls,
    "Doors": BuiltInCategory.OST_Doors,
    "Windows": BuiltInCategory.OST_Windows,
    "Floors": BuiltInCategory.OST_Floors,
    "Ceilings": BuiltInCategory.OST_Ceilings,
    "Roofs": BuiltInCategory.OST_Roofs,
    "Columns": BuiltInCategory.OST_Columns,
    "Structural Columns": BuiltInCategory.OST_StructuralColumns,
    "Structural Framing": BuiltInCategory.OST_StructuralFraming,
    "Stairs": BuiltInCategory.OST_Stairs,
    "Railings": BuiltInCategory.OST_Railings,
    "Furniture": BuiltInCategory.OST_Furniture,
    "Generic Models": BuiltInCategory.OST_GenericModel,
    "Mechanical Equipment": BuiltInCategory.OST_MechanicalEquipment,
    "Electrical Equipment": BuiltInCategory.OST_ElectricalEquipment,
    "Plumbing Fixtures": BuiltInCategory.OST_PlumbingFixtures,
    "Lighting Fixtures": BuiltInCategory.OST_LightingFixtures,
    "Ducts": BuiltInCategory.OST_DuctCurves,
    "Pipes": BuiltInCategory.OST_PipeCurves,
    "Conduits": BuiltInCategory.OST_Conduit
}

# Fixed Colors (Simple and Revit-like)
COLORS = {
    "removed": Color(255, 100, 100),      # Light Red
    "added": Color(100, 255, 100),        # Light Green  
    "geometry_changed": Color(255, 255, 100),  # Light Yellow
    "parameters_changed": Color(100, 200, 255), # Light Blue
    "identical": Color(180, 180, 180)     # Light Gray
}

# -----------------------
# Simple GUI Class
# -----------------------
class SimpleComparisonWindow(Form):
    def __init__(self):
        self.InitializeComponent()
        self.comparison_running = False
        
    def InitializeComponent(self):
        # Form properties - Revit style
        self.Text = "Model Comparison Tool"
        self.Size = Size(400, 400)
        self.StartPosition = FormStartPosition.CenterScreen
        self.FormBorderStyle = FormBorderStyle.FixedDialog
        self.MaximizeBox = False
        self.MinimizeBox = True
        self.BackColor = DrawingColor.FromArgb(240, 240, 240)  # Revit-like gray
        
        # Title Panel
        title_panel = Panel()
        title_panel.Size = Size(380, 50)
        title_panel.Location = Point(10, 10)
        title_panel.BackColor = DrawingColor.FromArgb(50, 120, 200)  # Revit blue
        self.Controls.Add(title_panel)
        
        title_label = Label()
        title_label.Text = "Enhanced Model Comparison"
        title_label.Font = Font("Segoe UI", 12, FontStyle.Bold)
        title_label.ForeColor = DrawingColor.White
        title_label.Location = Point(10, 15)
        title_label.Size = Size(300, 25)
        title_panel.Controls.Add(title_label)
        
        # Link Selection Group
        link_group = GroupBox()
        link_group.Text = "Select Linked Model"
        link_group.Font = Font("Segoe UI", 9, FontStyle.Bold)
        link_group.Size = Size(380, 70)
        link_group.Location = Point(10, 70)
        link_group.BackColor = DrawingColor.White
        self.Controls.Add(link_group)
        
        self.link_combo = ComboBox()
        self.link_combo.Size = Size(280, 25)
        self.link_combo.Location = Point(10, 25)
        self.link_combo.DropDownStyle = ComboBoxStyle.DropDownList
        self.link_data = []
        self.populate_link_combo()
        link_group.Controls.Add(self.link_combo)
        
        refresh_btn = Button()
        refresh_btn.Text = "Refresh"
        refresh_btn.Size = Size(70, 25)
        refresh_btn.Location = Point(300, 25)
        refresh_btn.BackColor = DrawingColor.FromArgb(230, 230, 230)
        refresh_btn.Click += self.refresh_links
        link_group.Controls.Add(refresh_btn)
        
        # Color Legend Group
        legend_group = GroupBox()
        legend_group.Text = "Color Legend"
        legend_group.Font = Font("Segoe UI", 9, FontStyle.Bold)
        legend_group.Size = Size(380, 140)
        legend_group.Location = Point(10, 150)
        legend_group.BackColor = DrawingColor.White
        self.Controls.Add(legend_group)
        
        # Color indicators
        legend_items = [
            ("Added Elements", COLORS["added"]),
            ("Removed Elements", COLORS["removed"]),
            ("Geometry Changed", COLORS["geometry_changed"]),
            ("Parameters Changed", COLORS["parameters_changed"]),
            ("Identical Elements", COLORS["identical"])
        ]
        
        y_pos = 20
        for text, color in legend_items:
            # Color box
            color_box = Panel()
            color_box.Size = Size(20, 15)
            color_box.Location = Point(10, y_pos)
            color_box.BackColor = DrawingColor.FromArgb(color.Red, color.Green, color.Blue)
            color_box.BorderStyle = BorderStyle.FixedSingle
            legend_group.Controls.Add(color_box)
            
            # Label
            label = Label()
            label.Text = text
            label.Location = Point(40, y_pos - 2)
            label.Size = Size(200, 20)
            label.Font = Font("Segoe UI", 8)
            legend_group.Controls.Add(label)
            
            y_pos += 22
        
        # Control Buttons
        self.start_btn = Button()
        self.start_btn.Text = "Start Comparison"
        self.start_btn.Size = Size(150, 35)
        self.start_btn.Location = Point(50, 300)
        self.start_btn.BackColor = DrawingColor.FromArgb(100, 180, 100)
        self.start_btn.ForeColor = DrawingColor.White
        self.start_btn.Font = Font("Segoe UI", 10, FontStyle.Bold)
        self.start_btn.FlatStyle = FlatStyle.Flat
        self.start_btn.Click += self.start_comparison
        self.Controls.Add(self.start_btn)
        
        clear_btn = Button()
        clear_btn.Text = "Clear Colors"
        clear_btn.Size = Size(120, 35)
        clear_btn.Location = Point(220, 300)
        clear_btn.BackColor = DrawingColor.FromArgb(200, 100, 100)
        clear_btn.ForeColor = DrawingColor.White
        clear_btn.Font = Font("Segoe UI", 10, FontStyle.Bold)
        clear_btn.FlatStyle = FlatStyle.Flat
        clear_btn.Click += self.clear_overrides
        self.Controls.Add(clear_btn)
        
        # Status Label
        self.status_label = Label()
        self.status_label.Text = "Ready to compare models"
        self.status_label.Size = Size(380, 20)
        self.status_label.Location = Point(10, 350)
        self.status_label.Font = Font("Segoe UI", 8)
        self.status_label.ForeColor = DrawingColor.FromArgb(100, 100, 100)
        self.Controls.Add(self.status_label)
    
    def populate_link_combo(self):
        """Populate combo box with available links"""
        try:
            self.link_combo.Items.Clear()
            self.link_data = []
            
            # Get document from global variable
            current_doc = __revit__.ActiveUIDocument.Document
            link_instances = FilteredElementCollector(current_doc).OfClass(RevitLinkInstance).ToElements()
            
            for link_instance in link_instances:
                try:
                    link_name = link_instance.Name
                    link_doc = link_instance.GetLinkDocument()
                    
                    if link_name and link_doc:
                        display_name = "{} - Loaded".format(link_name)
                        
                        link_info = {
                            'name': display_name,
                            'instance': link_instance,
                            'doc': link_doc
                        }
                        
                        self.link_data.append(link_info)
                        self.link_combo.Items.Add(display_name)
                except Exception as ex:
                    print("Error processing link instance: {}".format(str(ex)))
                    continue
                    
            if len(self.link_data) == 0:
                self.link_combo.Items.Add("No loaded links found")
                if hasattr(self, 'start_btn'):
                    self.start_btn.Enabled = False
            else:
                self.link_combo.SelectedIndex = 0
                if hasattr(self, 'start_btn'):
                    self.start_btn.Enabled = True
                
        except Exception as e:
            print("Error populating links: {}".format(str(e)))
            # Add a default item if there's an error
            self.link_combo.Items.Add("Error loading links")
            if hasattr(self, 'start_btn'):
                self.start_btn.Enabled = False
    
    def refresh_links(self, sender, e):
        """Refresh the links list"""
        self.populate_link_combo()
        self.status_label.Text = "Links refreshed"
    
    def start_comparison(self, sender, e):
        """Start the comparison process"""
        if self.comparison_running:
            return
            
        try:
            if self.link_combo.SelectedIndex < 0 or len(self.link_data) == 0:
                self.show_message("Please select a linked model first!", "No Link Selected")
                return
                
            selected_link = self.link_data[self.link_combo.SelectedIndex]
            
            self.comparison_running = True
            self.start_btn.Enabled = False
            self.start_btn.Text = "Comparing..."
            self.status_label.Text = "Starting comparison..."
            self.Refresh()
            
            # Run comparison
            success = self.run_comparison_process(selected_link)
            
            if success:
                self.status_label.Text = "Comparison completed successfully!"
                self.show_message("Comparison completed! Check your 3D view to see the results.", "Success")
            else:
                self.status_label.Text = "Comparison failed"
                self.show_message("Comparison failed. Check the output for details.", "Error")
                
        except Exception as e:
            self.show_message("Error during comparison: {}".format(str(e)), "Error")
            self.status_label.Text = "Comparison error"
            print("Comparison error: {}".format(str(e)))
        finally:
            self.comparison_running = False
            self.start_btn.Enabled = True
            self.start_btn.Text = "Start Comparison"
    
    def run_comparison_process(self, selected_link):
        """Run the actual comparison process"""
        try:
            link_instance = selected_link['instance']
            linked_doc = selected_link['doc']
            
            # Get current document
            current_doc = __revit__.ActiveUIDocument.Document
            
            # Use IExternalEventHandler approach - schedule the transaction
            return self.execute_comparison(current_doc, link_instance, linked_doc)
                
        except Exception as e:
            print("Error in comparison process: {}".format(str(e)))
            return False
    
    def execute_comparison(self, current_doc, link_instance, linked_doc):
        """Execute comparison without direct transaction"""
        try:
            # Clear existing overrides first
            self.status_label.Text = "Clearing existing colors..."
            self.Refresh()
            
            # Simple override clearing without transaction
            try:
                element_ids = list(FilteredElementCollector(current_doc).ToElementIds())
                for element_id in element_ids[:1000]:  # Limit to first 1000 for performance
                    try:
                        current_doc.ActiveView.SetElementOverrides(element_id, OverrideGraphicSettings())
                    except:
                        continue
            except:
                pass
            
            # Process each category without transaction
            processed = 0
            for category_name, built_in_category in target_categories.items():
                try:
                    self.status_label.Text = "Processing: {}".format(category_name)
                    self.Refresh()
                    
                    # Collect and compare elements
                    current_elements = collect_elements_by_category(current_doc, built_in_category)
                    linked_elements = collect_elements_by_category(linked_doc, built_in_category)
                    
                    # Apply overrides without transaction
                    self.apply_category_overrides_simple(current_elements, linked_elements, current_doc)
                    
                    processed += 1
                    
                    # Only process first few categories for performance
                    if processed >= 5:
                        break
                        
                except Exception as e:
                    print("Error processing category {}: {}".format(category_name, str(e)))
                    continue
            
            return True
                
        except Exception as e:
            print("Error in execute comparison: {}".format(str(e)))
            return False
    
    def apply_category_overrides_simple(self, current_elements, linked_elements, current_doc):
        """Apply overrides for a category without transaction"""
        try:
            # Find added elements (in current but not in link) - simplified
            added_count = 0
            for uid in current_elements:
                if uid not in linked_elements:
                    current_element = current_elements[uid]['element']
                    self.apply_override_simple(current_element.Id, COLORS["added"], current_doc)
                    added_count += 1
                    if added_count >= 50:  # Limit for performance
                        break
            
            # Find removed elements (in link but not in current) - simplified
            removed_count = 0
            for uid in linked_elements:
                if uid not in current_elements:
                    removed_count += 1
                    if removed_count >= 50:  # Just count, don't apply to linked elements
                        break
            
            # Compare some existing elements - simplified
            compared_count = 0
            for uid in current_elements:
                if uid in linked_elements and compared_count < 50:
                    current_element = current_elements[uid]['element']
                    
                    # Simple check - assume most are identical for now
                    self.apply_override_simple(current_element.Id, COLORS["identical"], current_doc, transparency=30)
                    compared_count += 1
                    
            print("Processed: {} added, {} removed, {} compared".format(added_count, removed_count, compared_count))
                            
        except Exception as e:
            print("Error applying simple overrides: {}".format(str(e)))
    
    def apply_override_simple(self, element_id, color, current_doc, transparency=0):
        """Apply override to element without transaction"""
        try:
            ogs = OverrideGraphicSettings()
            
            # Set surface color
            ogs.SetSurfaceForegroundPatternColor(color)
            ogs.SetSurfaceTransparency(transparency)
            
            # Set line color
            ogs.SetProjectionLineColor(color)
            ogs.SetProjectionLineWeight(3)
            
            # Try to apply without transaction
            current_doc.ActiveView.SetElementOverrides(element_id, ogs)
            
        except Exception as e:
            # Silently ignore errors for now
            pass
    
    def compare_basic_parameters(self, elem1, elem2):
        """Simple parameter comparison"""
        try:
            # Compare basic parameters like Type, Level, etc.
            basic_params = ['Type', 'Level', 'Height', 'Width', 'Length']
            
            for param_name in basic_params:
                try:
                    param1 = elem1.LookupParameter(param_name)
                    param2 = elem2.LookupParameter(param_name)
                    
                    if param1 and param2:
                        if param1.HasValue and param2.HasValue:
                            val1 = param1.AsValueString() or str(param1.AsDouble())
                            val2 = param2.AsValueString() or str(param2.AsDouble())
                            if val1 != val2:
                                return True
                except:
                    continue
                    
            return False
        except:
            return False
    
    def clear_overrides(self, sender, e):
        """Clear all visual overrides"""
        try:
            self.status_label.Text = "Clearing colors..."
            self.Refresh()
            
            # Get current document
            current_doc = __revit__.ActiveUIDocument.Document
            
            # Try to clear without transaction first
            try:
                element_ids = list(FilteredElementCollector(current_doc).ToElementIds())
                cleared_count = 0
                for element_id in element_ids:
                    try:
                        current_doc.ActiveView.SetElementOverrides(element_id, OverrideGraphicSettings())
                        cleared_count += 1
                        if cleared_count >= 1000:  # Limit for performance
                            break
                    except:
                        continue
                
                self.status_label.Text = "Colors cleared ({} elements)".format(cleared_count)
                self.show_message("Color overrides cleared for {} elements.".format(cleared_count), "Cleared")
                
            except Exception as ex:
                print("Clear error: {}".format(str(ex)))
                self.show_message("Error clearing some overrides: {}".format(str(ex)), "Warning")
                
        except Exception as e:
            self.show_message("Error clearing overrides: {}".format(str(e)), "Error")
            self.status_label.Text = "Error clearing colors"
            print("Clear error: {}".format(str(e)))
    
    def show_message(self, message, title):
        """Show message using forms.alert"""
        try:
            forms.alert(title, message)
        except:
            print("{}: {}".format(title, message))

# -----------------------
# Utility Functions
# -----------------------
def collect_elements_by_category(document, built_in_category):
    """Collect elements by category"""
    elements_data = {}
    
    try:
        collector = FilteredElementCollector(document).OfCategory(built_in_category)
        collector = collector.WhereElementIsNotElementType()
        
        for element in collector:
            try:
                elements_data[element.UniqueId] = {
                    'element': element,
                    'category': built_in_category
                }
            except:
                continue
                
    except Exception as e:
        print("Error collecting category {}: {}".format(built_in_category, str(e)))
    
    return elements_data

# -----------------------
# Main Execution
# -----------------------
def main():
    """Main function to show the GUI"""
    try:
        # Check if we have a valid document
        current_doc = __revit__.ActiveUIDocument.Document
        if not current_doc:
            forms.alert("No Document", "Please open a Revit document first!")
            return
        
        # Check for linked models
        link_instances = FilteredElementCollector(current_doc).OfClass(RevitLinkInstance).ToElements()
        loaded_links = [link for link in link_instances if link.GetLinkDocument()]
        
        if not loaded_links:
            result = forms.alert("No Linked Models", 
                               "No loaded linked models found in the current project!\n\n" +
                               "Please load a linked model first and try again.\n\n" +
                               "Do you want to continue anyway?",
                               options=["Continue", "Cancel"])
            if result == "Cancel":
                return
        
        # Create and show the GUI
        window = SimpleComparisonWindow()
        window.Show()
        
        print("✅ Model Comparison tool opened successfully!")
        
    except Exception as e:
        error_msg = "❌ Error starting comparison tool: {}".format(str(e))
        print(error_msg)
        forms.alert("Startup Error", error_msg)

# -----------------------
# Execute
# -----------------------
if __name__ == "__main__":
    print("🚀 Starting Simple Model Comparison Tool...")
    print("=" * 50)
    main()
    print("=" * 50)
    print("🎉 Tool launched!")