# -*- coding: utf-8 -*-
__title__ = "Enhanced Live Tooltip"
__author__ = "Enhanced by AI"

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")
clr.AddReference("System.Windows.Forms")
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import ObjectType
from RevitServices.Persistence import DocumentManager
from System.Windows import Window, Thickness, SizeToContent, WindowStartupLocation, Clipboard, FontWeights, GridLength, GridUnitType, HorizontalAlignment
import System.Windows.Input
from System.Windows.Controls import Grid, TextBlock, Button, TextBox, ColumnDefinition, RowDefinition, ScrollViewer, StackPanel, Border
from System.Windows.Media import SolidColorBrush, Colors, Color
from System.Windows.Forms import Cursor, MessageBox
from System.Windows.Threading import Dispatcher
from pyrevit import revit
import System.Windows.Interop
import time
import sys

doc = revit.doc
uidoc = revit.uidoc
window_closed = False

# ---------- Enhanced parameter extraction ----------
def get_element_id_value(elem_id):
    """Get ElementId value with version compatibility"""
    try:
        # For newer Revit versions (2022+)
        if hasattr(elem_id, 'IntegerValue'):
            return elem_id.IntegerValue
        # For older Revit versions
        elif hasattr(elem_id, 'Value'):
            return elem_id.Value
        else:
            return int(str(elem_id))
    except:
        return -1

def get_param_value(elem, pname):
    """Get parameter value with enhanced type handling"""
    param = elem.LookupParameter(pname)
    if not param or not param.HasValue:
        return None
    
    try:
        storage_type = param.StorageType
        
        if storage_type == StorageType.String:
            val = param.AsString()
            return val.strip() if val else None
            
        elif storage_type == StorageType.Double:
            val = param.AsDouble()
            # Try to get formatted value first
            formatted = param.AsValueString()
            if formatted:
                return formatted
            # Fallback to raw value
            return "{:.2f}".format(val) if val != 0 else "0"
            
        elif storage_type == StorageType.Integer:
            return str(param.AsInteger())
            
        elif storage_type == StorageType.ElementId:
            elem_id = param.AsElementId()
            id_value = get_element_id_value(elem_id)
            if id_value == -1:
                return "None"
            try:
                linked_elem = doc.GetElement(elem_id)
                if linked_elem:
                    return getattr(linked_elem, 'Name', str(id_value))
                return str(id_value)
            except:
                return str(id_value)
        else:
            formatted = param.AsValueString()
            return formatted if formatted else "Unknown Type"
            
    except Exception as e:
        return "Error: {}".format(str(e))

def get_element_location(elem):
    """Get element location information"""
    location_info = {}
    
    try:
        location = elem.Location
        if hasattr(location, 'Point'):
            pt = location.Point
            location_info["Location X"] = "{:.2f}".format(pt.X)
            location_info["Location Y"] = "{:.2f}".format(pt.Y)
            location_info["Location Z"] = "{:.2f}".format(pt.Z)
        elif hasattr(location, 'Curve'):
            curve = location.Curve
            start_pt = curve.GetEndPoint(0)
            end_pt = curve.GetEndPoint(1)
            location_info["Start Point"] = "({:.2f}, {:.2f}, {:.2f})".format(start_pt.X, start_pt.Y, start_pt.Z)
            location_info["End Point"] = "({:.2f}, {:.2f}, {:.2f})".format(end_pt.X, end_pt.Y, end_pt.Z)
            location_info["Curve Length"] = "{:.2f}".format(curve.Length)
    except:
        pass
    
    return location_info

def get_element_type_info(elem):
    """Get element type information"""
    type_info = {}
    
    try:
        elem_type = doc.GetElement(elem.GetTypeId())
        if elem_type:
            type_info["Type Name"] = getattr(elem_type, 'Name', 'Unknown')
            type_info["Type ID"] = str(get_element_id_value(elem.GetTypeId()))
            
            # Get family name if available
            if hasattr(elem_type, 'FamilyName'):
                type_info["Family Name"] = elem_type.FamilyName
    except:
        pass
    
    return type_info

def get_material_info(elem):
    """Get material information"""
    material_info = {}
    
    try:
        # Try to get material from MaterialIds
        if hasattr(elem, 'GetMaterialIds'):
            material_ids = elem.GetMaterialIds(False)
            if material_ids.Count > 0:
                materials = []
                for mat_id in material_ids:
                    material = doc.GetElement(mat_id)
                    if material:
                        materials.append(material.Name)
                if materials:
                    material_info["Materials"] = ", ".join(materials)
    except:
        pass
    
    return material_info

def get_workset_info(elem):
    """Get workset information"""
    workset_info = {}
    
    try:
        if hasattr(elem, 'WorksetId'):
            workset_id = elem.WorksetId
            id_value = get_element_id_value(workset_id)
            if id_value != -1:
                workset_table = doc.GetWorksetTable()
                workset = workset_table.GetWorkset(workset_id)
                workset_info["Workset"] = workset.Name
    except:
        pass
    
    return workset_info

# ---------- Enhanced data collection ----------
def get_comprehensive_data(elem):
    """Get comprehensive element data"""
    
    # Enhanced parameter categories
    parameter_groups = {
        "Basic Info": [
            "Category", "Element ID", "Type Name", "Family and Type",
            "Name", "Comments", "Mark", "Description"
        ],
        "Level & Position": [
            "Level", "Reference Level", "Base Level", "Top Level",
            "Base Constraint", "Top Constraint", "Base Offset", "Top Offset",
            "Sill Height", "Head Height", "Unconnected Height"
        ],
        "Dimensions": [
            "Length", "Width", "Height", "Depth", "Thickness", "Diameter",
            "Area", "Volume", "Cut Length", "System Length", "Size"
        ],
        "Elevation & Slope": [
            "Elevation at Top", "Elevation at Bottom", 
            "Upper End Top Elevation", "Lower End Bottom Elevation",
            "Start Elevation", "End Elevation", "Slope", "Fall"
        ],
        "System & MEP": [
            "System Classification", "System Type", "System Name",
            "Flow", "Pressure Drop", "Size", "Roughness",
            "Insulation Type", "Insulation Thickness"
        ],
        "Materials & Finish": [
            "Material", "Finish", "Color", "Manufacturer", "Model",
            "Fire Rating", "Assembly Code", "Keynote"
        ],
        "Construction": [
            "Phase Created", "Phase Demolished", "Design Option",
            "Assembly Description", "Assembly Mark", "Cost"
        ],
        "Analysis": [
            "Structural Usage", "Structural Material", "Cross-Section Rotation",
            "Thermal Mass", "Heat Transfer Coefficient", "Absorptance"
        ]
    }
    
    # Get all parameters from element
    all_params = {}
    try:
        for param in elem.Parameters:
            if param.HasValue:
                param_name = param.Definition.Name
                value = get_param_value(elem, param_name)
                if value and str(value).strip():
                    all_params[param_name] = value
    except:
        pass
    
    # Organize parameters by groups
    organized_data = {}
    used_params = set()
    
    for group_name, param_list in parameter_groups.items():
        group_data = {}
        for param_name in param_list:
            if param_name in all_params:
                group_data[param_name] = all_params[param_name]
                used_params.add(param_name)
        if group_data:
            organized_data[group_name] = group_data
    
    # Add basic element info
    basic_info = {}
    try:
        basic_info["Element ID"] = str(get_element_id_value(elem.Id))
        basic_info["Category"] = elem.Category.Name if elem.Category else "Unknown"
        basic_info["Class"] = elem.GetType().Name
    except:
        pass
    
    if basic_info:
        if "Basic Info" not in organized_data:
            organized_data["Basic Info"] = {}
        organized_data["Basic Info"].update(basic_info)
    
    # Add location info
    location_info = get_element_location(elem)
    if location_info:
        organized_data["Location"] = location_info
    
    # Add type info
    type_info = get_element_type_info(elem)
    if type_info:
        if "Basic Info" not in organized_data:
            organized_data["Basic Info"] = {}
        organized_data["Basic Info"].update(type_info)
    
    # Add material info
    material_info = get_material_info(elem)
    if material_info:
        if "Materials & Finish" not in organized_data:
            organized_data["Materials & Finish"] = {}
        organized_data["Materials & Finish"].update(material_info)
    
    # Add workset info
    workset_info = get_workset_info(elem)
    if workset_info:
        if "Basic Info" not in organized_data:
            organized_data["Basic Info"] = {}
        organized_data["Basic Info"].update(workset_info)
    
    # Add remaining parameters that weren't categorized
    remaining_params = {k: v for k, v in all_params.items() if k not in used_params}
    if remaining_params:
        organized_data["Other Parameters"] = remaining_params
    
    return organized_data

# ---------- Enhanced Tooltip Window ----------
class EnhancedTooltipWindow(Window):
    def __init__(self, pos_x, pos_y):
        global window_closed
        window_closed = False

        self.Title = "Enhanced Live Tooltip - Element Inspector"
        self.Width = 800
        self.Height = 600
        self.WindowStartupLocation = WindowStartupLocation.Manual
        self.Left = pos_x
        self.Top = pos_y
        self.Background = SolidColorBrush(Color.FromRgb(25, 25, 25))
        self.Closed += self.on_close

        # Set Revit as owner
        try:
            helper = System.Windows.Interop.WindowInteropHelper(self)
            helper.Owner = System.Diagnostics.Process.GetCurrentProcess().MainWindowHandle
        except:
            pass

        self.compare_mode = False
        self.data_list = []
        self.setup_ui()

    def setup_ui(self):
        """Setup the user interface"""
        main_grid = Grid()
        main_grid.Margin = Thickness(10)
        
        # Define rows
        main_grid.RowDefinitions.Add(RowDefinition(Height=GridLength.Auto))  # Search
        main_grid.RowDefinitions.Add(RowDefinition(Height=GridLength.Auto))  # Buttons
        main_grid.RowDefinitions.Add(RowDefinition(Height=GridLength.Auto))  # Info
        main_grid.RowDefinitions.Add(RowDefinition())  # Content
        
        # Search box
        search_border = Border(
            Background=SolidColorBrush(Color.FromRgb(40, 40, 40)),
            CornerRadius=System.Windows.CornerRadius(5),
            Margin=Thickness(0, 0, 0, 10)
        )
        self.search_box = TextBox(
            Background=SolidColorBrush(Colors.Transparent),
            Foreground=SolidColorBrush(Colors.White),
            CaretBrush=SolidColorBrush(Colors.White),
            BorderThickness=Thickness(0),
            Margin=Thickness(10, 8, 10, 8),
            FontSize=14
        )
        self.search_box.TextChanged += self.filter_data
        search_border.Child = self.search_box
        Grid.SetRow(search_border, 0)
        main_grid.Children.Add(search_border)
        
        # Button panel
        button_panel = StackPanel(Orientation=System.Windows.Controls.Orientation.Horizontal)
        button_panel.Margin = Thickness(0, 0, 0, 10)
        
        self.toggle_btn = self.create_button("Compare Mode: OFF", self.toggle_compare)
        self.copy_btn = self.create_button("Copy All", self.copy_all)
        self.export_btn = self.create_button("Export", self.export_data)
        self.close_btn = self.create_button("Close", self.on_close_click)
        
        button_panel.Children.Add(self.toggle_btn)
        button_panel.Children.Add(self.copy_btn)
        button_panel.Children.Add(self.export_btn)
        button_panel.Children.Add(self.close_btn)
        
        Grid.SetRow(button_panel, 1)
        main_grid.Children.Add(button_panel)
        
        # Info panel
        self.info_panel = TextBlock(
            Text="Click on elements to inspect their properties",
            Foreground=SolidColorBrush(Colors.Gray),
            Margin=Thickness(0, 0, 0, 10),
            FontStyle=System.Windows.FontStyles.Italic
        )
        Grid.SetRow(self.info_panel, 2)
        main_grid.Children.Add(self.info_panel)
        
        # Content area with scroll
        scroll_viewer = ScrollViewer(
            VerticalScrollBarVisibility=System.Windows.Controls.ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility=System.Windows.Controls.ScrollBarVisibility.Auto
        )
        
        self.content_grid = Grid()
        scroll_viewer.Content = self.content_grid
        Grid.SetRow(scroll_viewer, 3)
        main_grid.Children.Add(scroll_viewer)
        
        self.Content = main_grid

    def create_button(self, text, handler):
        """Create a styled button"""
        btn = Button(
            Content=text,
            Margin=Thickness(0, 0, 10, 0),
            Padding=Thickness(15, 8, 15, 8),
            Background=SolidColorBrush(Color.FromRgb(70, 130, 180)),
            Foreground=SolidColorBrush(Colors.White),
            BorderThickness=Thickness(0),
            FontWeight=FontWeights.Bold
        )
        btn.Click += handler
        return btn

    def on_close(self, sender=None, args=None):
        global window_closed
        window_closed = True

    def on_close_click(self, sender, args):
        self.Close()

    def toggle_compare(self, sender, args):
        self.compare_mode = not self.compare_mode
        self.toggle_btn.Content = "Compare Mode: ON" if self.compare_mode else "Compare Mode: OFF"
        self.toggle_btn.Background = SolidColorBrush(Color.FromRgb(220, 20, 60)) if self.compare_mode else SolidColorBrush(Color.FromRgb(70, 130, 180))
        self.data_list = []
        self.refresh_display()

    def update_element_data(self, data_dict, element_info=""):
        """Update with new element data"""
        if not self.compare_mode:
            self.data_list = [data_dict]
        else:
            if len(self.data_list) >= 2:
                self.data_list.pop(0)
            self.data_list.append(data_dict)
        
        # Update info panel
        if self.compare_mode:
            self.info_panel.Text = "Compare Mode: {} element(s) selected".format(len(self.data_list))
        else:
            self.info_panel.Text = element_info if element_info else "Element selected"
        
        self.refresh_display()

    def filter_data(self, sender, args):
        self.refresh_display()

    def refresh_display(self):
        """Refresh the display with current data"""
        self.content_grid.Children.Clear()
        self.content_grid.RowDefinitions.Clear()
        self.content_grid.ColumnDefinitions.Clear()
        
        if not self.data_list:
            return
        
        # Setup columns
        self.content_grid.ColumnDefinitions.Add(ColumnDefinition(Width=GridLength(200, GridUnitType.Pixel)))
        for i in range(len(self.data_list)):
            self.content_grid.ColumnDefinitions.Add(ColumnDefinition())
        
        # Get all sections
        all_sections = set()
        for data in self.data_list:
            all_sections.update(data.keys())
        
        keyword = self.search_box.Text.lower()
        row = 0
        
        # Add headers for compare mode
        if self.compare_mode and len(self.data_list) > 1:
            self.content_grid.RowDefinitions.Add(RowDefinition(Height=GridLength.Auto))
            for i, data in enumerate(self.data_list):
                header = TextBlock(
                    Text="Element {}".format(i + 1),
                    FontWeight=FontWeights.Bold,
                    FontSize=16,
                    Foreground=SolidColorBrush(Colors.Yellow),
                    Margin=Thickness(10),
                    HorizontalAlignment=HorizontalAlignment.Center
                )
                Grid.SetRow(header, row)
                Grid.SetColumn(header, i + 1)
                self.content_grid.Children.Add(header)
            row += 1
        
        # Display sections
        for section in sorted(all_sections):
            # Section header
            self.content_grid.RowDefinitions.Add(RowDefinition(Height=GridLength.Auto))
            section_header = TextBlock(
                Text=section,
                FontWeight=FontWeights.Bold,
                FontSize=14,
                Foreground=SolidColorBrush(Colors.Orange),
                Margin=Thickness(5, 10, 5, 5)
            )
            Grid.SetRow(section_header, row)
            Grid.SetColumn(section_header, 0)
            Grid.SetColumnSpan(section_header, len(self.data_list) + 1)
            self.content_grid.Children.Add(section_header)
            row += 1
            
            # Get all parameters in this section
            all_params = set()
            for data in self.data_list:
                if section in data:
                    all_params.update(data[section].keys())
            
            # Display parameters
            for param in sorted(all_params):
                if keyword and keyword not in param.lower():
                    continue
                
                self.content_grid.RowDefinitions.Add(RowDefinition(Height=GridLength.Auto))
                
                # Parameter name
                param_label = TextBlock(
                    Text=param + ":",
                    FontWeight=FontWeights.Bold,
                    Foreground=SolidColorBrush(Colors.LightBlue),
                    Margin=Thickness(15, 3, 5, 3),
                    VerticalAlignment=System.Windows.VerticalAlignment.Center
                )
                Grid.SetRow(param_label, row)
                Grid.SetColumn(param_label, 0)
                self.content_grid.Children.Add(param_label)
                
                # Parameter values
                values = []
                for i, data in enumerate(self.data_list):
                    value = data.get(section, {}).get(param, "-")
                    values.append(value)
                    
                    value_block = TextBlock(
                        Text=str(value),
                        Foreground=SolidColorBrush(Colors.White),
                        Background=SolidColorBrush(Color.FromRgb(45, 45, 45)),
                        Margin=Thickness(5, 3, 5, 3),
                        Padding=Thickness(8, 4, 8, 4),
                        Cursor=System.Windows.Input.Cursors.Hand,
                        ToolTip="Click to copy"
                    )
                    
                    # Highlight differences in compare mode
                    if self.compare_mode and len(values) > 1:
                        if len(set(str(v) for v in values[:i+1])) > 1:
                            value_block.Background = SolidColorBrush(Color.FromRgb(80, 40, 40))
                    
                    value_block.MouseLeftButtonDown += self.copy_value
                    Grid.SetRow(value_block, row)
                    Grid.SetColumn(value_block, i + 1)
                    self.content_grid.Children.Add(value_block)
                
                row += 1

    def copy_value(self, sender, args):
        """Copy value to clipboard"""
        original_text = sender.Text.replace("[Copied] ", "")
        Clipboard.SetText(original_text)
        sender.Text = "[Copied] " + original_text
        
        # Reset text after 2 seconds
        timer = System.Windows.Threading.DispatcherTimer()
        timer.Interval = System.TimeSpan(0, 0, 2)
        def reset_text(s, e):
            sender.Text = original_text
            timer.Stop()
        timer.Tick += reset_text
        timer.Start()

    def copy_all(self, sender, args):
        """Copy all data to clipboard"""
        if not self.data_list:
            return
        
        lines = []
        for i, data in enumerate(self.data_list):
            lines.append("=" * 50)
            lines.append("ELEMENT {} DATA".format(i + 1))
            lines.append("=" * 50)
            
            for section, params in data.items():
                lines.append("\n[{}]".format(section))
                lines.append("-" * len(section))
                for param, value in params.items():
                    lines.append("{}: {}".format(param, value))
            lines.append("\n")
        
        Clipboard.SetText("\n".join(lines))
        MessageBox.Show("All data copied to clipboard!", "Success")

    def export_data(self, sender, args):
        """Export data (placeholder for future implementation)"""
        MessageBox.Show("Export functionality can be implemented based on your needs\n(CSV, JSON, Excel, etc.)", "Export")

# ---------- Main execution ----------
def main():
    global window_closed
    
    try:
        # Initial element selection
        ref = uidoc.Selection.PickObject(ObjectType.Element, "Select an element to inspect")
        elem = doc.GetElement(ref.ElementId)
        data = get_comprehensive_data(elem)
        
        # Create window near cursor
        mouse_pos = Cursor.Position
        x = max(50, mouse_pos.X - 400)  # Keep window on screen
        y = max(50, mouse_pos.Y - 300)
        
        window = EnhancedTooltipWindow(x, y)
        
        # Initial data update
        element_info = "Category: {} | ID: {}".format(
            elem.Category.Name if elem.Category else "Unknown",
            get_element_id_value(elem.Id)
        )
        Dispatcher.CurrentDispatcher.Invoke(lambda: window.update_element_data(data, element_info))
        window.Show()
        
        # Continuous selection loop
        while not window_closed:
            try:
                ref = uidoc.Selection.PickObject(ObjectType.Element, "Select another element (ESC to exit)")
                elem = doc.GetElement(ref.ElementId)
                data = get_comprehensive_data(elem)
                
                if data:
                    element_info = "Category: {} | ID: {}".format(
                        elem.Category.Name if elem.Category else "Unknown",
                        get_element_id_value(elem.Id)
                    )
                    Dispatcher.CurrentDispatcher.Invoke(lambda: window.update_element_data(data, element_info))
                    
            except Exception as selection_error:
                # User cancelled selection or other error
                if "cancelled" not in str(selection_error).lower():
                    print("Selection error: {}".format(selection_error))
                break
            
            time.sleep(0.05)  # Small delay to prevent excessive CPU usage
            
    except Exception as main_error:
        MessageBox.Show("❌ Error:\n\n{}".format(str(main_error)), "Enhanced Tooltip Error")
    
    finally:
        if 'window' in locals():
            try:
                window.Close()
            except:
                pass

# Run the main function
if __name__ == "__main__":
    main()