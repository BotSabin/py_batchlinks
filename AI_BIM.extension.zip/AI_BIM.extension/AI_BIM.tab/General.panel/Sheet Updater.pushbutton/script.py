# -*- coding: utf-8 -*-
__title__ = "Update Sheets"
__author__ = "GHASEM ARIYANI"

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")
clr.AddReference("PresentationFramework")
clr.AddReference("WindowsBase")
clr.AddReference("PresentationCore")

from Autodesk.Revit.DB import *
from RevitServices.Persistence import DocumentManager
from pyrevit import revit, script
from System.IO import File
from System.Windows.Markup import XamlReader
from System.Windows import MessageBox

doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()

# Load UI
xaml_path = __file__.replace("script.py", "SheetUpdater.xaml")
xaml_string = File.ReadAllText(xaml_path)
window = XamlReader.Parse(xaml_string)

# Helpers
def get(name):
    return window.FindName(name).Text.strip()

def generate_sheet_name():
    return "{} - {} - {} - {} - {}".format(
        get("ProjectCodeInput"),
        get("LevelInput"),
        get("DisciplineCodeInput"),
        get("TypeInput"),
        get("DescriptionInput")
    )

def apply_to_sheets(sheets):
    generated_name = generate_sheet_name()

    param_map = {
        "Sheet Name": generated_name,
        "Drawn By": get("DrawnByInput"),
        "Checked By": get("CheckedByInput"),
        "Approved By": get("ApprovedByInput"),
        "Designed By": get("DesignedByInput"),
        "Discipline": get("DisciplineInput"),
        "REV.NO": get("RevNoInput"),
        "SH.SIZE": get("SheetSizeInput"),
        "Drawing No": get("DrawingNoInput"),
        "Consultant": get("ConsultantInput"),
        "ARCHITECTURE APPROVED": get("ArchApprovedInput"),
        "STRUCTURE APPROVED": get("StrApprovedInput"),
        "MECHANICAL APPROVED": get("MechApprovedInput"),
        "ELECTRICAL APPROVED": get("ElecApprovedInput")
    }

    updated = 0
    t = Transaction(doc, "Update Sheet Parameters")
    t.Start()
    for sheet in sheets:
        for key, value in param_map.items():
            if value and sheet.LookupParameter(key):
                sheet.LookupParameter(key).Set(value)
                updated += 1
    t.Commit()

    output.print_md("📄 Sheet Name applied: **{}**".format(generated_name))
    output.print_md("✔️ Parameters updated on {} sheets.".format(len(sheets)))
    window.Close()

# Button: All Sheets
def apply_all(sender, args):
    all_sheets = FilteredElementCollector(doc).OfClass(ViewSheet).ToElements()
    apply_to_sheets(all_sheets)

# Button: Current Sheet
def apply_current(sender, args):
    current_view = uidoc.ActiveView
    if isinstance(current_view, ViewSheet):
        apply_to_sheets([current_view])
    else:
        MessageBox.Show("❌ Current view is not a sheet.", "Warning")

# Button: Selected Sheets
def apply_selected(sender, args):
    selected_ids = uidoc.Selection.GetElementIds()
    selected_sheets = [doc.GetElement(id) for id in selected_ids if isinstance(doc.GetElement(id), ViewSheet)]
    if selected_sheets:
        apply_to_sheets(selected_sheets)
    else:
        MessageBox.Show("❌ No sheet(s) selected in project.", "Warning")

# Connect buttons
window.FindName("ApplyAll").Click += apply_all
window.FindName("ApplyCurrent").Click += apply_current
window.FindName("ApplySelected").Click += apply_selected

# Show window
window.ShowDialog()
