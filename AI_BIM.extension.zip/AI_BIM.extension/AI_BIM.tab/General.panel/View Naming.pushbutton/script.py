# -*- coding: utf-8 -*-
__title__ = "ISO 19650 Professional Naming"
__author__ = "Ghasem Ariyani"
__version__ = "2.0"

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")
clr.AddReference("System.Windows.Forms")
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")

from Autodesk.Revit.DB import *
from pyrevit import revit, script
from System.Windows import Application, MessageBox
from System.Windows.Markup import XamlReader
from System.IO import MemoryStream, File
from System.Text import Encoding
import json
import os

# ---------- Configuration Manager ----------
class ConfigManager:
    def __init__(self):
        self.config_path = os.path.join(os.path.expanduser("~"), "ISO19650_Config.json")
        self.default_config = {
            "project_code": "123456",
            "originator": "A",
            "volume": "00",
            "type": "FPL",
            "role": "A",
            "number": "0001",
            "status": "S0",
            "classification": "PM_40_60_64",
            "use_simple": False,
            "include_elevation": True,
            "auto_increment": True,
            "precision": 2
        }
    
    def load_config(self):
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                    return config
        except Exception as e:
            script.get_output().print_md("⚠️ Config load error: {}".format(str(e)))
        return self.default_config.copy()
    
    def save_config(self, config):
        try:
            with open(self.config_path, 'w') as f:
                json.dump(config, f, indent=2)
            return True
        except Exception as e:
            script.get_output().print_md("⚠️ Config save error: {}".format(str(e)))
            return False

# ---------- Working XAML UI ----------
def get_xaml():
    return """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="ISO 19650 Professional Naming Tool v2.0" Height="650" Width="750">
    <Grid Margin="10">
        <TabControl Name="mainTabControl">
            <!-- Main Naming Tab -->
            <TabItem Header="Naming Configuration">
                <ScrollViewer VerticalScrollBarVisibility="Auto">
                    <Grid Margin="5">
                        <Grid.RowDefinitions>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                        </Grid.RowDefinitions>
                        <Grid.ColumnDefinitions>
                            <ColumnDefinition Width="150"/>
                            <ColumnDefinition Width="*"/>
                            <ColumnDefinition Width="80"/>
                        </Grid.ColumnDefinitions>

                        <TextBlock Text="Project Code:" Grid.Row="0" Grid.Column="0" Margin="5" VerticalAlignment="Center"/>
                        <TextBox Name="projectCode" Grid.Row="0" Grid.Column="1" Margin="5" Text="123456"/>

                        <TextBlock Text="Originator:" Grid.Row="1" Grid.Column="0" Margin="5" VerticalAlignment="Center"/>
                        <ComboBox Name="originator" Grid.Row="1" Grid.Column="1" Margin="5" IsEditable="True">
                            <ComboBoxItem Content="A"/>
                            <ComboBoxItem Content="S"/>
                            <ComboBoxItem Content="M"/>
                            <ComboBoxItem Content="E"/>
                            <ComboBoxItem Content="P"/>
                            <ComboBoxItem Content="T"/>
                            <ComboBoxItem Content="L"/>
                        </ComboBox>

                        <TextBlock Text="Volume:" Grid.Row="2" Grid.Column="0" Margin="5" VerticalAlignment="Center"/>
                        <ComboBox Name="volume" Grid.Row="2" Grid.Column="1" Margin="5" IsEditable="True">
                            <ComboBoxItem Content="00"/>
                            <ComboBoxItem Content="01"/>
                            <ComboBoxItem Content="02"/>
                        </ComboBox>

                        <TextBlock Text="Level (Auto):" Grid.Row="3" Grid.Column="0" Margin="5" VerticalAlignment="Center"/>
                        <TextBox Name="level" Grid.Row="3" Grid.Column="1" Margin="5" IsReadOnly="True" Background="LightGray"/>

                        <TextBlock Text="Type:" Grid.Row="4" Grid.Column="0" Margin="5" VerticalAlignment="Center"/>
                        <ComboBox Name="type" Grid.Row="4" Grid.Column="1" Margin="5" IsEditable="True">
                            <ComboBoxItem Content="FPL"/>
                            <ComboBoxItem Content="SEC"/>
                            <ComboBoxItem Content="RCP"/>
                            <ComboBoxItem Content="ELV"/>
                            <ComboBoxItem Content="3D"/>
                            <ComboBoxItem Content="DET"/>
                            <ComboBoxItem Content="SCH"/>
                        </ComboBox>

                        <TextBlock Text="Role:" Grid.Row="5" Grid.Column="0" Margin="5" VerticalAlignment="Center"/>
                        <ComboBox Name="role" Grid.Row="5" Grid.Column="1" Margin="5" IsEditable="True">
                            <ComboBoxItem Content="A"/>
                            <ComboBoxItem Content="S"/>
                            <ComboBoxItem Content="C"/>
                            <ComboBoxItem Content="D"/>
                        </ComboBox>

                        <TextBlock Text="Number:" Grid.Row="6" Grid.Column="0" Margin="5" VerticalAlignment="Center"/>
                        <TextBox Name="number" Grid.Row="6" Grid.Column="1" Margin="5" Text="0001"/>
                        <CheckBox Name="autoIncrement" Content="Auto++" Grid.Row="6" Grid.Column="2" Margin="5"/>

                        <TextBlock Text="Status:" Grid.Row="7" Grid.Column="0" Margin="5" VerticalAlignment="Center"/>
                        <ComboBox Name="status" Grid.Row="7" Grid.Column="1" Margin="5" IsEditable="True">
                            <ComboBoxItem Content="S0"/>
                            <ComboBoxItem Content="S1"/>
                            <ComboBoxItem Content="S2"/>
                            <ComboBoxItem Content="A1"/>
                            <ComboBoxItem Content="A2"/>
                        </ComboBox>

                        <TextBlock Text="Classification:" Grid.Row="8" Grid.Column="0" Margin="5" VerticalAlignment="Center"/>
                        <ComboBox Name="classification" Grid.Row="8" Grid.Column="1" Margin="5" IsEditable="True">
                            <ComboBoxItem Content="PM_40_60_64"/>
                            <ComboBoxItem Content="PM_70_00_11"/>
                            <ComboBoxItem Content="PM_40_50_32"/>
                        </ComboBox>

                        <!-- Options -->
                        <Separator Grid.Row="9" Grid.ColumnSpan="3" Margin="5"/>
                        
                        <CheckBox Name="useSimple" Grid.Row="10" Grid.Column="0" Grid.ColumnSpan="2" Margin="5">
                            Use simplified naming (Discipline-Level-Type-Number)
                        </CheckBox>
                        
                        <CheckBox Name="includeElevation" Grid.Row="11" Grid.Column="0" Grid.ColumnSpan="2" Margin="5" IsChecked="True">
                            Include elevation in naming
                        </CheckBox>
                        
                        <TextBlock Text="Precision:" Grid.Row="12" Grid.Column="0" Margin="5" VerticalAlignment="Center"/>
                        <ComboBox Name="precision" Grid.Row="12" Grid.Column="1" Margin="5">
                            <ComboBoxItem Content="1" Tag="1"/>
                            <ComboBoxItem Content="2" Tag="2" IsSelected="True"/>
                            <ComboBoxItem Content="3" Tag="3"/>
                        </ComboBox>

                        <!-- Action Buttons -->
                        <StackPanel Orientation="Horizontal" Grid.Row="13" Grid.Column="0" Grid.ColumnSpan="3" 
                                   Margin="5" HorizontalAlignment="Center">
                            <Button Name="generateBtn" Content="Apply to Selected Views" Margin="5" Padding="15,8" 
                                   FontWeight="Bold" Background="DodgerBlue" Foreground="White"/>
                            <Button Name="saveConfigBtn" Content="Save Config" Margin="5" Padding="10,8"/>
                            <Button Name="loadConfigBtn" Content="Load Config" Margin="5" Padding="10,8"/>
                        </StackPanel>
                    </Grid>
                </ScrollViewer>
            </TabItem>

            <!-- Batch Operations Tab -->
            <TabItem Header="Batch Operations">
                <Grid Margin="10">
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="*"/>
                        <RowDefinition Height="Auto"/>
                    </Grid.RowDefinitions>

                    <TextBlock Text="Batch Rename Operations" Grid.Row="0" FontSize="16" FontWeight="Bold" Margin="5"/>
                    
                    <GroupBox Header="By View Type" Grid.Row="1" Margin="5">
                        <StackPanel Orientation="Horizontal" Margin="5">
                            <ComboBox Name="viewTypeSelector" Width="150" Margin="5">
                                <ComboBoxItem Content="Floor Plans" Tag="FloorPlan"/>
                                <ComboBoxItem Content="Ceiling Plans" Tag="CeilingPlan"/>
                                <ComboBoxItem Content="Sections" Tag="Section"/>
                                <ComboBoxItem Content="Elevations" Tag="Elevation"/>
                                <ComboBoxItem Content="3D Views" Tag="ThreeD"/>
                            </ComboBox>
                            <Button Name="processByTypeBtn" Content="Process All" Margin="5" Padding="10,5"/>
                        </StackPanel>
                    </GroupBox>

                    <GroupBox Header="By Level" Grid.Row="2" Margin="5">
                        <StackPanel Orientation="Horizontal" Margin="5">
                            <ComboBox Name="levelSelector" Width="150" Margin="5"/>
                            <Button Name="processByLevelBtn" Content="Process Level" Margin="5" Padding="10,5"/>
                            <Button Name="refreshLevelsBtn" Content="Refresh" Margin="5" Padding="10,5"/>
                        </StackPanel>
                    </GroupBox>

                    <GroupBox Header="Validation Tools" Grid.Row="3" Margin="5">
                        <StackPanel Orientation="Horizontal" Margin="5">
                            <Button Name="validateNamesBtn" Content="Validate Names" Margin="5" Padding="10,5"/>
                            <Button Name="findDuplicatesBtn" Content="Find Duplicates" Margin="5" Padding="10,5"/>
                            <Button Name="previewChangesBtn" Content="Preview Changes" Margin="5" Padding="10,5"/>
                        </StackPanel>
                    </GroupBox>

                    <TextBox Name="batchResults" Grid.Row="4" Margin="5" IsReadOnly="True" 
                            VerticalScrollBarVisibility="Auto" FontFamily="Consolas" Background="Black" 
                            Foreground="Lime" Text="Ready for batch operations..."/>

                    <Button Name="clearResultsBtn" Content="Clear Results" Grid.Row="5" Margin="5" 
                           Padding="10,5" HorizontalAlignment="Right"/>
                </Grid>
            </TabItem>
        </TabControl>
    </Grid>
</Window>
"""

# ---------- Core Helper Functions ----------
def get_elevation_from_view(view):
    """Get elevation from view in meters"""
    try:
        elevation_feet = 0.0
        
        if hasattr(view, "GenLevel") and view.GenLevel:
            level = view.GenLevel
            elevation_feet = level.Elevation
        elif hasattr(view, "Origin"):
            elevation_feet = view.Origin.Z
        elif hasattr(view, "ViewRange") and view.ViewRange:
            view_range = view.ViewRange
            if view_range:
                elevation_feet = view_range.GetOffset(PlanViewPlane.CutPlane)
        
        elevation_meters = elevation_feet * 0.3048
        return elevation_meters
        
    except:
        return 0.0

def format_elevation(elevation_meters, precision=2):
    """Format elevation with proper sign and precision"""
    rounded_elevation = round(elevation_meters, precision)
    format_str = "{{:.{}f}}".format(precision)
    
    if rounded_elevation == 0.0:
        return "(±{})".format(format_str.format(rounded_elevation))
    elif rounded_elevation > 0:
        return "(+{})".format(format_str.format(rounded_elevation))
    else:
        return "({})".format(format_str.format(rounded_elevation))

def make_unique_name(doc, base_name):
    """Generate unique name if conflicts exist"""
    counter = 1
    new_name = base_name
    existing_names = {v.Name for v in FilteredElementCollector(doc).OfClass(View).ToElements()}
    
    while new_name in existing_names:
        new_name = "{}_{}".format(base_name, counter)
        counter += 1
    return new_name

    def get_number_safe(self):
        """Get number with error handling"""
        try:
            number_text = self.get_text("number").strip()
            if not number_text:
                return 1  # Default to 1 if empty
            return int(number_text)
        except ValueError:
            return 1  # Default to 1 if invalid
    
    def format_number(self, number):
        """Format number as 4-digit string"""
        return "{:04d}".format(max(1, min(9999, number)))

# ---------- Main Application Class ----------
class ISO19650App:
    def __init__(self):
        self.config_manager = ConfigManager()
        self.config = self.config_manager.load_config()
        self.xaml_obj = None
        self.doc = revit.doc
        self.uidoc = revit.uidoc
        self.load_ui()
        self.setup_event_handlers()
        self.populate_ui()
    
    def load_ui(self):
        """Load XAML UI"""
        xaml = get_xaml()
        xaml_bytes = Encoding.UTF8.GetBytes(xaml)
        xaml_stream = MemoryStream(xaml_bytes)
        self.xaml_obj = XamlReader.Load(xaml_stream)
    
    def setup_event_handlers(self):
        """Setup all event handlers with working functions"""
        self.xaml_obj.FindName("generateBtn").Click += self.generate_name
        self.xaml_obj.FindName("saveConfigBtn").Click += self.save_config
        self.xaml_obj.FindName("loadConfigBtn").Click += self.load_config
        self.xaml_obj.FindName("processByTypeBtn").Click += self.process_by_type
        self.xaml_obj.FindName("processByLevelBtn").Click += self.process_by_level
        self.xaml_obj.FindName("refreshLevelsBtn").Click += self.refresh_levels
        self.xaml_obj.FindName("validateNamesBtn").Click += self.validate_names
        self.xaml_obj.FindName("findDuplicatesBtn").Click += self.find_duplicates
        self.xaml_obj.FindName("previewChangesBtn").Click += self.preview_changes
        self.xaml_obj.FindName("clearResultsBtn").Click += self.clear_results
    
    def populate_ui(self):
        """Populate UI with config data"""
        # Set values from config
        self.xaml_obj.FindName("projectCode").Text = self.config.get("project_code", "123456")
        self.xaml_obj.FindName("number").Text = self.config.get("number", "0001")
        self.xaml_obj.FindName("includeElevation").IsChecked = self.config.get("include_elevation", True)
        self.xaml_obj.FindName("autoIncrement").IsChecked = self.config.get("auto_increment", True)
        self.xaml_obj.FindName("useSimple").IsChecked = self.config.get("use_simple", False)
        
        # Populate levels
        self.refresh_levels(None, None)
    
    def get_text(self, name):
        """Get text from control"""
        ctrl = self.xaml_obj.FindName(name)
        if hasattr(ctrl, 'Text'):
            return ctrl.Text.strip()
        elif hasattr(ctrl, 'SelectedItem') and ctrl.SelectedItem:
            return str(ctrl.SelectedItem.Content)
        return ""
    
    def get_checkbox_state(self, name):
        """Get checkbox state"""
        ctrl = self.xaml_obj.FindName(name)
        return ctrl.IsChecked if ctrl else False
    
    def get_combo_selection(self, name):
        """Get combobox selection"""
        ctrl = self.xaml_obj.FindName(name)
        if ctrl and ctrl.SelectedItem:
            return str(ctrl.SelectedItem.Content)
        return ""
    
    def get_number_safe(self):
        """Get number with error handling"""
        try:
            number_text = self.get_text("number").strip()
            if not number_text:
                return 1  # Default to 1 if empty
            return int(number_text)
        except ValueError:
            return 1  # Default to 1 if invalid
    
    def format_number(self, number):
        """Format number as 4-digit string"""
        return "{:04d}".format(max(1, min(9999, number)))
    
    def log_to_batch_results(self, message):
        """Log message to batch results"""
        current_text = self.xaml_obj.FindName("batchResults").Text
        new_text = current_text + "\n" + message
        self.xaml_obj.FindName("batchResults").Text = new_text
        # Auto scroll to bottom
        batch_box = self.xaml_obj.FindName("batchResults")
        batch_box.ScrollToEnd()
    
    def generate_name(self, sender, args):
        """Main naming function - WORKING VERSION"""
        selected_ids = self.uidoc.Selection.GetElementIds()
        views = [self.doc.GetElement(id) for id in selected_ids 
                if isinstance(self.doc.GetElement(id), View) and not self.doc.GetElement(id).IsTemplate]
        
        if not views:
            MessageBox.Show("No views selected! Please select views in the Project Browser.")
            return
        
        success_count = 0
        total_count = len(views)
        current_number = self.get_number_safe()  # Safe number retrieval
        
        script.get_output().print_md("🔄 Processing {} views...".format(total_count))
        
        for i, view in enumerate(views):
            try:
                # Get level information
                level = "LXX"
                if hasattr(view, "GenLevel") and view.GenLevel:
                    level = view.GenLevel.Name
                
                # Update level display
                self.xaml_obj.FindName("level").Text = level
                
                # Generate base name
                use_simple = self.get_checkbox_state("useSimple")
                
                if use_simple:
                    # In simple mode, exclude number from naming
                    base_name = "{}-{}-{}".format(
                        self.get_text("originator"),
                        level,
                        self.get_text("type")
                    )
                else:
                    # In full mode, use auto-incrementing number
                    base_name = "{}-{}-{}-{}-{}-{}-{}-{}-{}".format(
                        self.get_text("projectCode"),
                        self.get_text("originator"),
                        self.get_text("volume"),
                        level,
                        self.get_text("type"),
                        self.get_text("role"),
                        self.format_number(current_number),  # Safe formatting
                        self.get_text("status"),
                        self.get_text("classification")
                    )
                
                # Add elevation if requested
                final_name = base_name
                if self.get_checkbox_state("includeElevation"):
                    elevation = get_elevation_from_view(view)
                    precision_ctrl = self.xaml_obj.FindName("precision")
                    precision = int(precision_ctrl.SelectedItem.Content) if precision_ctrl.SelectedItem else 2
                    elevation_suffix = format_elevation(elevation, precision)
                    final_name = base_name + elevation_suffix
                
                # Make name unique
                unique_name = make_unique_name(self.doc, final_name)
                
                # Rename the view
                t = Transaction(self.doc, "Rename View")
                t.Start()
                try:
                    old_name = view.Name
                    view.Name = unique_name
                    script.get_output().print_md("✅ Renamed: '{}' → '{}'".format(old_name, unique_name))
                    success_count += 1
                    
                    # Auto increment only in full mode
                    if not use_simple and self.get_checkbox_state("autoIncrement"):
                        current_number += 1
                        self.xaml_obj.FindName("number").Text = self.format_number(current_number)
                    
                except Exception as e:
                    script.get_output().print_md("❌ Failed to rename '{}': {}".format(view.Name, str(e)))
                finally:
                    t.Commit()
                    
            except Exception as e:
                script.get_output().print_md("❌ Error processing view: {}".format(str(e)))
        
        # Show summary
        script.get_output().print_md("📊 **Summary:** {}/{} views renamed successfully.".format(success_count, total_count))
        MessageBox.Show("Completed! {}/{} views renamed successfully.".format(success_count, total_count))
    
    def save_config(self, sender, args):
        """Save current configuration - WORKING"""
        try:
            current_config = {
                "project_code": self.get_text("projectCode"),
                "originator": self.get_text("originator"),
                "volume": self.get_text("volume"),
                "type": self.get_text("type"),
                "role": self.get_text("role"),
                "number": self.get_text("number"),
                "status": self.get_text("status"),
                "classification": self.get_text("classification"),
                "use_simple": self.get_checkbox_state("useSimple"),
                "include_elevation": self.get_checkbox_state("includeElevation"),
                "auto_increment": self.get_checkbox_state("autoIncrement"),
                "precision": int(self.xaml_obj.FindName("precision").SelectedItem.Content) if self.xaml_obj.FindName("precision").SelectedItem else 2
            }
            
            if self.config_manager.save_config(current_config):
                MessageBox.Show("Configuration saved successfully!")
                self.config = current_config
            else:
                MessageBox.Show("Failed to save configuration!")
        except Exception as e:
            MessageBox.Show("Error saving config: {}".format(str(e)))
    
    def load_config(self, sender, args):
        """Load saved configuration - WORKING"""
        try:
            self.config = self.config_manager.load_config()
            self.populate_ui()
            MessageBox.Show("Configuration loaded successfully!")
        except Exception as e:
            MessageBox.Show("Error loading config: {}".format(str(e)))
    
    def refresh_levels(self, sender, args):
        """Refresh levels list - WORKING"""
        try:
            levels = FilteredElementCollector(self.doc).OfClass(Level).ToElements()
            level_cb = self.xaml_obj.FindName("levelSelector")
            level_cb.Items.Clear()
            
            sorted_levels = sorted(levels, key=lambda x: x.Elevation)
            for level in sorted_levels:
                level_cb.Items.Add(level.Name)
            
            self.log_to_batch_results("✅ Refreshed {} levels".format(len(sorted_levels)))
        except Exception as e:
            self.log_to_batch_results("❌ Error refreshing levels: {}".format(str(e)))
    
    def process_by_type(self, sender, args):
        """Process views by type - WORKING"""
        try:
            type_selector = self.xaml_obj.FindName("viewTypeSelector")
            if not type_selector.SelectedItem:
                self.log_to_batch_results("❌ Please select a view type first")
                return
            
            view_type_name = type_selector.SelectedItem.Tag
            
            # Map view type names to Revit ViewType enum
            view_type_map = {
                "FloorPlan": ViewType.FloorPlan,
                "CeilingPlan": ViewType.CeilingPlan,
                "Section": ViewType.Section,
                "Elevation": ViewType.Elevation,
                "ThreeD": ViewType.ThreeD
            }
            
            if view_type_name not in view_type_map:
                self.log_to_batch_results("❌ Unknown view type: {}".format(view_type_name))
                return
            
            target_view_type = view_type_map[view_type_name]
            views = FilteredElementCollector(self.doc).OfClass(View).ToElements()
            target_views = [v for v in views if v.ViewType == target_view_type and not v.IsTemplate]
            
            self.log_to_batch_results("🔄 Processing {} {} views...".format(len(target_views), view_type_name))
            
            # Simulate selection and process
            element_ids = [v.Id for v in target_views]
            self.uidoc.Selection.SetElementIds(element_ids)
            self.generate_name(None, None)
            
        except Exception as e:
            self.log_to_batch_results("❌ Error processing by type: {}".format(str(e)))
    
    def process_by_level(self, sender, args):
        """Process views by level - WORKING"""
        try:
            level_selector = self.xaml_obj.FindName("levelSelector")
            if not level_selector.SelectedItem:
                self.log_to_batch_results("❌ Please select a level first")
                return
            
            selected_level_name = str(level_selector.SelectedItem.Content)
            views = FilteredElementCollector(self.doc).OfClass(View).ToElements()
            target_views = [v for v in views 
                          if hasattr(v, 'GenLevel') and v.GenLevel and 
                          v.GenLevel.Name == selected_level_name and not v.IsTemplate]
            
            self.log_to_batch_results("🔄 Processing {} views for level '{}'...".format(len(target_views), selected_level_name))
            
            # Simulate selection and process
            element_ids = [v.Id for v in target_views]
            self.uidoc.Selection.SetElementIds(element_ids)
            self.generate_name(None, None)
            
        except Exception as e:
            self.log_to_batch_results("❌ Error processing by level: {}".format(str(e)))
    
    def find_duplicates(self, sender, args):
        """Find duplicate view names - WORKING"""
        try:
            views = FilteredElementCollector(self.doc).OfClass(View).ToElements()
            view_names = [v.Name for v in views if not v.IsTemplate]
            
            duplicates = {}
            for name in view_names:
                count = view_names.count(name)
                if count > 1:
                    duplicates[name] = count
            
            if duplicates:
                self.log_to_batch_results("⚠️ Found {} duplicate name(s):".format(len(duplicates)))
                for name, count in duplicates.items():
                    self.log_to_batch_results("  • '{}' appears {} times".format(name, count))
            else:
                self.log_to_batch_results("✅ No duplicate names found!")
                
        except Exception as e:
            self.log_to_batch_results("❌ Error finding duplicates: {}".format(str(e)))
    
    def validate_names(self, sender, args):
        """Validate view names against ISO 19650 - WORKING"""
        try:
            views = FilteredElementCollector(self.doc).OfClass(View).ToElements()
            non_template_views = [v for v in views if not v.IsTemplate]
            
            invalid_names = []
            for view in non_template_views:
                # Simple validation - check if name contains basic ISO structure
                name = view.Name
                if not ("-" in name and len(name) > 5):
                    invalid_names.append(name)
            
            self.log_to_batch_results("📋 Validation Results:")
            self.log_to_batch_results("  Total views: {}".format(len(non_template_views)))
            self.log_to_batch_results("  Valid names: {}".format(len(non_template_views) - len(invalid_names)))
            self.log_to_batch_results("  Invalid names: {}".format(len(invalid_names)))
            
            if invalid_names:
                self.log_to_batch_results("⚠️ Views with non-standard names:")
                for name in invalid_names[:10]:  # Show first 10
                    self.log_to_batch_results("  • '{}'".format(name))
                if len(invalid_names) > 10:
                    self.log_to_batch_results("  ... and {} more".format(len(invalid_names) - 10))
            
        except Exception as e:
            self.log_to_batch_results("❌ Error validating names: {}".format(str(e)))
    
    def preview_changes(self, sender, args):
        """Preview naming changes without applying - WORKING"""
        try:
            selected_ids = self.uidoc.Selection.GetElementIds()
            views = [self.doc.GetElement(id) for id in selected_ids 
                    if isinstance(self.doc.GetElement(id), View) and not self.doc.GetElement(id).IsTemplate]
            
            if not views:
                self.log_to_batch_results("❌ No views selected for preview")
                return
            
            self.log_to_batch_results("🔍 Preview of naming changes:")
            self.log_to_batch_results("=" * 50)
            
            current_number = self.get_number_safe()  # Safe number retrieval
            use_simple = self.get_checkbox_state("useSimple")
            include_elevation = self.get_checkbox_state("includeElevation")
            precision = int(self.xaml_obj.FindName("precision").SelectedItem.Content) if self.xaml_obj.FindName("precision").SelectedItem else 2
            
            for i, view in enumerate(views):
                # Get level
                level = "LXX"
                if hasattr(view, "GenLevel") and view.GenLevel:
                    level = view.GenLevel.Name
                
                if use_simple:
                    # In simple mode, exclude number from naming
                    new_name = "{}-{}-{}".format(
                        self.get_text("originator"),
                        level,
                        self.get_text("type")
                    )
                else:
                    # In full mode, use auto-incrementing number
                    new_name = "{}-{}-{}-{}-{}-{}-{}-{}-{}".format(
                        self.get_text("projectCode"),
                        self.get_text("originator"),
                        self.get_text("volume"),
                        level,
                        self.get_text("type"),
                        self.get_text("role"),
                        self.format_number(current_number + i),  # Safe formatting
                        self.get_text("status"),
                        self.get_text("classification")
                    )
                
                # Add elevation if needed
                if include_elevation:
                    elevation = get_elevation_from_view(view)
                    elevation_suffix = format_elevation(elevation, precision)
                    new_name += elevation_suffix
                
                # Check if unique
                final_name = make_unique_name(self.doc, new_name)
                
                self.log_to_batch_results("  '{}' → '{}'".format(view.Name, final_name))
            
            self.log_to_batch_results("=" * 50)
            self.log_to_batch_results("✅ Preview complete for {} views".format(len(views)))
            
        except Exception as e:
            self.log_to_batch_results("❌ Error generating preview: {}".format(str(e)))
    
    def clear_results(self, sender, args):
        """Clear batch results - WORKING"""
        self.xaml_obj.FindName("batchResults").Text = "Ready for batch operations..."
    
    def show(self):
        """Show the dialog"""
        return self.xaml_obj.ShowDialog()

# ---------- Run Application ----------
def run_app():
    """Main entry point"""
    try:
        app = ISO19650App()
        app.show()
    except Exception as e:
        script.get_output().print_md("❌ Error starting application: {}".format(str(e)))
        MessageBox.Show("Error: {}".format(str(e)))

# Run the application
if __name__ == "__main__":
    run_app()