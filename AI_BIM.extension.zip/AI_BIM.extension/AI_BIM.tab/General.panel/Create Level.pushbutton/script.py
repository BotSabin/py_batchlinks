# -*- coding: utf-8 -*-
import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitServices")

from Autodesk.Revit.DB import (
    Level, Transaction, ViewPlan, ViewFamilyType, ViewFamily,
    FilteredElementCollector
)
from RevitServices.Persistence import DocumentManager
from pyrevit import forms, script

doc = __revit__.ActiveUIDocument.Document
output = script.get_output()
output.set_title("Create Levels with Extended ISO 19650 Naming")

output.print_md("""
## 📘 ISO 19650 Naming Format:
**[ProjectCode]-[DisciplineCode]-[LevelCode]-[LevelName] (Elevation)**

---
### 🔤 Example:
- `P01-A-AL01-Office (+3000)`
- `P01-S-SB01-Parking (-4000)`
- `P01-A-AGF-Lobby (+0)`

---
### 📚 Structure Description:
| Field             | Description                                             |
|------------------|---------------------------------------------------------|
| `ProjectCode`     | Project code (e.g. P01)                                 |
| `DisciplineCode`  | A=Architectural, S=Structural, M=Mechanical, etc.       |
| `LevelCode`       | AL01, SB01, PGF... based on discipline and elevation    |
| `LevelName`       | User-defined tag like Office, Lobby, Parking            |
| `Elevation`       | Elevation in **mm**, shown in parenthesis               |

---
""")

def get_view_family_type(view_family):
    vtypes = FilteredElementCollector(doc).OfClass(ViewFamilyType).ToElements()
    for vt in vtypes:
        if vt.ViewFamily == view_family:
            return vt
    return None

# Input 1: Project Code
project_code = forms.ask_for_string(
    prompt=(
        "Enter Project Code (e.g. P01):\n\n"
        "📘 ISO 19650 Format:\n"
        "[ProjectCode]-[DisciplineCode]-[LevelCode]-[LevelName] (Elevation)\n\n"
        "🧱 Example: P01-A-AL01-Office (+3000)"
    ),
    default="P01"
)
if not project_code:
    script.exit()

# Input 2: Discipline Selection
discipline_map = {
    "Architectural": ("A", "A", ViewFamily.FloorPlan),
    "Structural": ("S", "S", ViewFamily.StructuralPlan),
    "Mechanical": ("M", "M", ViewFamily.FloorPlan),
    "Electrical": ("E", "E", ViewFamily.FloorPlan),
    "Plumbing": ("P", "P", ViewFamily.FloorPlan)
}
discipline_choice = forms.CommandSwitchWindow.show(
    sorted(discipline_map.keys()),
    message="Select the discipline for views:",
    title="Discipline Selection"
)
if not discipline_choice:
    script.exit()

discipline_code, discipline_prefix, view_family = discipline_map[discipline_choice]

# Input 3: Level count
level_count_str = forms.ask_for_string(
    prompt="How many levels to create?",
    default="3"
)
try:
    level_count = int(level_count_str)
except:
    forms.alert("Invalid number.")
    script.exit()

# Input 4: Elevation + Name
elevations = []
level_names = []
for i in range(level_count):
    name = forms.ask_for_string(
        prompt="Enter name for Level {}".format(i + 1),
        default="Level{}".format(i + 1)
    )
    elev_input = forms.ask_for_string(
        prompt="Enter elevation (m) for Level {}".format(i + 1),
        default=str(i * 3)
    )
    try:
        elev = float(elev_input)
    except:
        forms.alert("Invalid elevation.")
        script.exit()
    level_names.append(name)
    elevations.append(elev)

# Sort elevation codes
above = sorted([e for e in elevations if e > 0])
below = sorted([e for e in elevations if e < 0], reverse=True)
above_map = dict((e, i + 1) for i, e in enumerate(above))
below_map = dict((e, i + 1) for i, e in enumerate(below))

# Collect existing Level & View names
existing_levels = FilteredElementCollector(doc).OfClass(Level).ToElements()
existing_level_names = [lvl.Name for lvl in existing_levels]
existing_views = FilteredElementCollector(doc).OfClass(ViewPlan).ToElements()
existing_view_names = [v.Name for v in existing_views]

view_type = get_view_family_type(view_family)

output.print_md("## ✅ Created Levels:\n")

with Transaction(doc, "Create ISO 19650 Levels") as t:
    t.Start()
    for idx, elev in enumerate(elevations):
        elev_ft = elev * 3.28084
        elev_mm = int(elev * 1000)

        # Level Code
        if elev == 0:
            level_code = discipline_prefix + "GF"
        elif elev > 0:
            level_code = "{}L{:02}".format(discipline_prefix, above_map[elev])
        else:
            level_code = "{}B{:02}".format(discipline_prefix, below_map[elev])

        level_tag = level_names[idx].strip().replace(" ", "_")
        view_name = "{}-{}-{}-{} ({:+d})".format(
            project_code,
            discipline_code,
            level_code,
            level_tag,
            elev_mm
        )

        # Level creation
        if level_code not in existing_level_names:
            lvl = Level.Create(doc, elev_ft)
            lvl.Name = level_code
        else:
            lvl = [l for l in existing_levels if l.Name == level_code][0]

        # View creation
        if view_type and view_name not in existing_view_names:
            try:
                view = ViewPlan.Create(doc, view_type.Id, lvl.Id)
                view.Name = view_name
                output.print_md("- ✅ {}".format(view_name))
            except Exception as e:
                output.print_md("- ⚠️ View not created for **{}**: {}".format(view_name, str(e)))
        else:
            output.print_md("- ⚠️ Skipped duplicate or no ViewType: {}".format(view_name))
    t.Commit()
